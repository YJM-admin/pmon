#!/bin/sh

# Detect the host processor, and determine the GCC version.
case $('uname') in
  Linux*)
    case $(uname -m) in
      x86_64)
        if [ -d "/opt/loongson-gnu-toolchain-8.3-x86_64-loongarch64-linux-gnu-rc1.4/" ]; then  
            export PATH=/opt/loongson-gnu-toolchain-8.3-x86_64-loongarch64-linux-gnu-rc1.4/bin:$PATH
        else  
            echo "\033[0;31mNo toolchain, Need GCC 8.3 GNU/Linux rc1.4 version\033[0m" 
            echo "You can obtain the toolchain from http://www.loongnix.cn/zh/toolchain/GNU/" 
            echo "Decompress cmd: tar xvf loongson-gnu-toolchain-8.3-x86_64-loongarch64-linux-gnu-rc1.4.tar.xz  -C /opt/"
            exit 1
        fi
         ;;
      loongarch64)
        GCC_VERSION=$(gcc -v 2>&1 | tail -1 | awk '{print $3}')
        case $GCC_VERSION in
          8.3.*)
            echo Use compiler version: $GCC_VERSION
            ;;
          *)
            echo Only support the version of compiler is GCC8.3 for now.
            exit 1
            ;;
        esac
        ;;
    esac
    ;;
  *)
    echo Only support Linux.
    exit 1
    ;;
esac

needdtb=1
cpuname=$1

case $cpuname in
	ls2k300)
		cd zloader.soc
		make ls2k300
		;;
	ls2k500)
		cd zloader.soc
		make ls2k500
		;;
	ls2k1000)
		cd zloader.soc
		make ls2k1000
		;;
	ls2k1500)
		cp Targets/ls2k/conf/ls_pai.2k1500 Targets/ls2k/conf/ls.2k
		cp Targets/ls2k/conf/ls2k1500.dts Targets/ls2k/conf/loongson.dts
		cd zloader.ls2k
		;;
	ls2k2000)
		cp Targets/ls2k/conf/ls_pai.2k2000 Targets/ls2k/conf/ls.2k
		cp Targets/ls2k/conf/ls2k2000.dts Targets/ls2k/conf/loongson.dts
		cd zloader.ls2k
		;;
	ls3a5000 | ls3a6000 | ls3c5000)
        cp Targets/ls3a5000_7a/conf/$cpuname  Targets/ls3a5000_7a/conf/ls.3a5000_7a
		cd zloader.3a5000_7a
        needdtb=0
		;;
    clean | clear)
        make clean
        exit 1
		;;
    help)
        echo "Compile dependency packages:"
        echo "sudo apt-get install xutils-dev make iasl gawk bison flex build-essential patch"
        exit 1
        ;;
	*)
        echo "\033[0;31mWarning not have cpu type $cpuname!\033[0m" 
		echo "please input cpu type (ls2k300/ls2k500/ls2k1000/ls2k1500/ls2k2000/ls3a5000/ls3a6000/ls3c5000)"
		echo "forexample: ./build.sh ls2k300"
        exit 1
		;;
esac

echo "Build cpu is $cpuname"
		
make cfg
make  all tgt=rom CROSS_COMPILE=loongarch64-linux-gnu- DEBUG=-g

if [ -e "gzrom.bin" ]; then  
  cp gzrom.bin  ../$cpuname.bin

  if [ "$needdtb" -ne 0 ]; then  
      make dtb
      cp gzrom-dtb.bin  ../$cpuname-dtb.bin
  fi
fi
