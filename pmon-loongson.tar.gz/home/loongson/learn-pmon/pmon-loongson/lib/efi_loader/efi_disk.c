// SPDX-License-Identifier: GPL-2.0+
/*
 *  EFI application disk support
 *
 *  Copyright (c) 2016 Alexander Graf
 */

#define LOG_CATEGORY LOGC_EFI

#include <kconfig.h>
#include <efi_loader.h>
#include <part_efi.h>
#include <diskfs.h>

#define MAX_BOOT_DEVICE 0x10
enum efi_disk_direction {
	EFI_DISK_READ,
	EFI_DISK_WRITE,
};

const efi_guid_t efi_block_io_guid = EFI_BLOCK_IO_PROTOCOL_GUID;
const efi_guid_t efi_system_partition_guid = PARTITION_SYSTEM_GUID;

extern DeviceDisk* FindDevice(const char* device_name);
extern int curr_port;
extern unsigned char efi_disk_type = 0;

efi_handle_t raw_disk_handle;
/**
 * struct efi_disk_obj - EFI disk object
 *
 * @header:	EFI object header
 * @ops:	EFI disk I/O protocol interface
 * @dev_index:	device index of block device
 * @media:	block I/O media information
 * @dp:		device path to the block device
 * @part:	partition
 * @volume:	simple file system protocol of the partition
 * @dev:	associated DM device
 */
struct efi_disk_obj {
	struct efi_object header;
	struct efi_block_io ops;
	int dev_index;
	struct efi_block_io_media media;
	struct efi_device_path *dp;
	unsigned int part;
	struct efi_simple_file_system_protocol *volume;
};

/**
 * efi_disk_reset() - reset block device
 *
 * This function implements the Reset service of the EFI_BLOCK_IO_PROTOCOL.
 *
 * As U-Boot's block devices do not have a reset function simply return
 * EFI_SUCCESS.
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * @this:			pointer to the BLOCK_IO_PROTOCOL
 * @extended_verification:	extended verification
 * Return:			status code
 */
static efi_status_t efi_disk_reset(struct efi_block_io *this,
			char extended_verification)
{
	EFI_ENTRY("%p, %x", this, extended_verification);
	return EFI_EXIT(EFI_SUCCESS);
}

/**
 * efi_disk_is_removable() - check if the device is removable media
 * @handle:		efi object handle;
 *
 * Examine the device and determine if the device is a local block device
 * and removable media.
 *
 * Return:		true if removable, false otherwise
 */
bool efi_disk_is_removable(efi_handle_t handle)
{
	struct efi_handler *handler;
	struct efi_block_io *io;
	efi_status_t ret;

	ret = efi_search_protocol(handle, &efi_block_io_guid, &handler);
	if (ret != EFI_SUCCESS)
		return false;

	io = handler->protocol_interface;

	if (!io || !io->media)
		return false;

	return (bool)io->media->removable_media;
}

static efi_status_t efi_disk_rw_blocks(struct efi_block_io *this,
			u32 media_id, u64 lba, unsigned long buffer_size,
			void *buffer, enum efi_disk_direction direction)
{
	struct efi_disk_obj *diskobj;
	unsigned long n;
	unsigned int blksz, blocks;
	block_dev_desc_t *desc;

	EFI_PRINT("blocks=%x lba=%llx blksz=%x dir=%d\n",
		  blocks, lba, blksz, direction);

	diskobj = container_of(this, struct efi_disk_obj, ops);
	blksz = diskobj->media.block_size;
	blocks = buffer_size / blksz;

	desc = diskobj->header.dev->desc;
	/* We only support full block access */
	if (buffer_size & (blksz - 1))
		return EFI_BAD_BUFFER_SIZE;


	if (desc->if_type == IF_TYPE_USB) {
		if (direction == EFI_DISK_READ)
			n = desc->block_read(0, lba, blocks, buffer);
	} else if (desc->if_type == IF_TYPE_NVME) {
		if (direction == EFI_DISK_READ)
			n = desc->block_read(desc->priv, lba, blocks, buffer);
		else
			n = desc->block_write(desc->priv, lba, blocks, buffer);
	} else if (desc->if_type == IF_TYPE_SATA) {
		if (direction == EFI_DISK_READ)
			n = ahci_sata_read(desc->priv, lba, blocks, buffer);
		else
			n = ahci_sata_write(desc->priv, lba, blocks, buffer);
	} else {
		printf("EFI DISK: not supprt this device\n");
	}
	/* fix unrecognized USB drive file type */
	dotik(30000, 0);

	/* We don't do interrupts, so check for timers cooperatively */
	efi_timer_check();

	EFI_PRINT("n=%lx blocks=%x\n", n, blocks);

	/* Fix multiple read disk errors*/
	delay(1000);

	if (n != blocks)
		return EFI_DEVICE_ERROR;

	return EFI_SUCCESS;
}

/**
 * efi_disk_read_blocks() - reads blocks from device
 *
 * This function implements the ReadBlocks service of the EFI_BLOCK_IO_PROTOCOL.
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * @this:			pointer to the BLOCK_IO_PROTOCOL
 * @media_id:			id of the medium to be read from
 * @lba:			starting logical block for reading
 * @buffer_size:		size of the read buffer
 * @buffer:			pointer to the destination buffer
 * Return:			status code
 */
static efi_status_t efi_disk_read_blocks(struct efi_block_io *this,
			u32 media_id, u64 lba, efi_uintn_t buffer_size,
			void *buffer)
{
	void *real_buffer = buffer;
	efi_status_t r;

	if (!this)
		return EFI_INVALID_PARAMETER;
	/* TODO: check for media changes */
	if (media_id != this->media->media_id)
		return EFI_MEDIA_CHANGED;
	if (!this->media->media_present)
		return EFI_NO_MEDIA;
	/* media->io_align is a power of 2 or 0 */
	if (this->media->io_align &&
	    (uintptr_t)buffer & (this->media->io_align - 1))
		return EFI_INVALID_PARAMETER;
	if (lba * this->media->block_size + buffer_size >
	    (this->media->last_block + 1) * this->media->block_size)
		return EFI_INVALID_PARAMETER;

	EFI_PRINT("this: %lx, %x, %llx, %x, %lx\n", this, media_id, lba,
		  buffer_size, buffer);

	r = efi_disk_rw_blocks(this, media_id, lba, buffer_size, real_buffer,
			       EFI_DISK_READ);

	/* Copy from bounce buffer to real buffer if necessary */
	if ((r == EFI_SUCCESS) && (real_buffer != buffer))
		memcpy(buffer, real_buffer, buffer_size);

	return EFI_EXIT(r);
}

/**
 * efi_disk_write_blocks() - writes blocks to device
 *
 * This function implements the WriteBlocks service of the
 * EFI_BLOCK_IO_PROTOCOL.
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * @this:			pointer to the BLOCK_IO_PROTOCOL
 * @media_id:			id of the medium to be written to
 * @lba:			starting logical block for writing
 * @buffer_size:		size of the write buffer
 * @buffer:			pointer to the source buffer
 * Return:			status code
 */
static efi_status_t efi_disk_write_blocks(struct efi_block_io *this,
			u32 media_id, u64 lba, efi_uintn_t buffer_size,
			void *buffer)
{
	void *real_buffer = buffer;
	efi_status_t r;

	if (!this)
		return EFI_INVALID_PARAMETER;
	if (this->media->read_only)
		return EFI_WRITE_PROTECTED;
	/* TODO: check for media changes */
	if (media_id != this->media->media_id)
		return EFI_MEDIA_CHANGED;
	if (!this->media->media_present)
		return EFI_NO_MEDIA;
	/* media->io_align is a power of 2 or 0 */
	if (this->media->io_align &&
	    (uintptr_t)buffer & (this->media->io_align - 1))
		return EFI_INVALID_PARAMETER;
	if (lba * this->media->block_size + buffer_size >
	    (this->media->last_block + 1) * this->media->block_size)
		return EFI_INVALID_PARAMETER;

	EFI_ENTRY("%p, %x, %llx, %zx, %p", this, media_id, lba,
		  buffer_size, buffer);

	/* Populate bounce buffer if necessary */
	if (real_buffer != buffer)
		memcpy(real_buffer, buffer, buffer_size);

	r = efi_disk_rw_blocks(this, media_id, lba, buffer_size, real_buffer,
			       EFI_DISK_WRITE);

	return EFI_EXIT(r);
}

/**
 * efi_disk_flush_blocks() - flushes modified data to the device
 *
 * This function implements the FlushBlocks service of the
 * EFI_BLOCK_IO_PROTOCOL.
 *
 * As we always write synchronously nothing is done here.
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * @this:			pointer to the BLOCK_IO_PROTOCOL
 * Return:			status code
 */
static efi_status_t efi_disk_flush_blocks(struct efi_block_io *this)
{
	EFI_ENTRY("%p", this);
	return EFI_EXIT(EFI_SUCCESS);
}

static const struct efi_block_io block_io_disk_template = {
	.reset = &efi_disk_reset,
	.read_blocks = &efi_disk_read_blocks,
	.write_blocks = &efi_disk_write_blocks,
	.flush_blocks = &efi_disk_flush_blocks,
};

/**
 * efi_fs_from_path() - retrieve simple file system protocol
 *
 * Gets the simple file system protocol for a file device path.
 *
 * The full path provided is split into device part and into a file
 * part. The device part is used to find the handle on which the
 * simple file system protocol is installed.
 *
 * @full_path:	device path including device and file
 * Return:	simple file system protocol
 */
struct efi_simple_file_system_protocol *
efi_fs_from_path(struct efi_device_path *full_path)
{
	struct efi_object *efiobj;
	struct efi_handler *handler;
	struct efi_device_path *device_path;
	struct efi_device_path *file_path;
	efi_status_t ret;

	/* Split the path into a device part and a file part */
	ret = efi_dp_split_file_path(full_path, &device_path, &file_path);
	if (ret != EFI_SUCCESS)
		return NULL;
	efi_free_pool(file_path);

	/* Get the EFI object for the partition */
	efiobj = efi_dp_find_obj(device_path, NULL, NULL);
	efi_free_pool(device_path);
	if (!efiobj)
		return NULL;

	/* Find the simple file system protocol */
	ret = efi_search_protocol(efiobj, &efi_simple_file_system_protocol_guid,
				  &handler);
	if (ret != EFI_SUCCESS)
		return NULL;

	/* Return the simple file system protocol for the partition */
	return handler->protocol_interface;
}

/**
 * efi_fs_exists() - check if a partition bears a file system
 *
 * @desc:	block device descriptor
 * @part:	partition number
 * Return:	1 if a file system exists on the partition
 *		0 otherwise
 */
static int efi_fs_exists(struct blk_desc *desc, int part)
{
	return 1;
}

/**
 * efi_disk_add_dev() - create a handle for a partition or disk
 *
 * @parent:		parent handle
 * @dp_parent:		parent device path
 * @desc:		internal block device
 * @dev_index:		device index for block device
 * @part_info:		partition info
 * @part:		partition
 * @disk:		pointer to receive the created handle
 * Return:		disk object
 */
static efi_status_t efi_disk_add_dev(
				efi_handle_t parent,
				struct efi_device_path *dp_parent,
				DeviceDisk *dev,
				int dev_index,
				struct disk_partition *part_info,
				unsigned int part,
				struct efi_disk_obj **disk)
{
	struct efi_disk_obj *diskobj;
	struct efi_object *handle;
	const efi_guid_t *esp_guid = NULL;
	efi_status_t ret;
	block_dev_desc_t *desc = dev->desc;

	/* Don't add empty devices */
	if (!desc->lba)
		return EFI_NOT_READY;

	diskobj = calloc(1, sizeof(*diskobj));
	if (!diskobj)
		return EFI_OUT_OF_RESOURCES;

	/* Hook up to the device list */
	efi_add_handle(&diskobj->header);

	/* Fill in object data */
	if (part_info) {
		struct efi_device_path *node = efi_dp_part_node(desc, part);
		struct efi_handler *handler;
		void *protocol_interface;

		if (!node) {
			ret = EFI_OUT_OF_RESOURCES;
			goto error;
		}

		/* Parent must expose EFI_BLOCK_IO_PROTOCOL */
		ret = efi_search_protocol(parent, &efi_block_io_guid, &handler);
		if (ret != EFI_SUCCESS)
			goto error;

		/*
		 * Link the partition (child controller) to the block device
		 * (controller).
		 */
		ret = efi_protocol_open(handler, &protocol_interface, NULL,
					&diskobj->header,
					EFI_OPEN_PROTOCOL_BY_CHILD_CONTROLLER);
		if (ret != EFI_SUCCESS)
				goto error;

		diskobj->dp = efi_dp_append_node(dp_parent, node);
		efi_free_pool(node);
		diskobj->media.last_block = part_info->size - 1;
		if (part_info->bootable & PART_EFI_SYSTEM_PARTITION)
			esp_guid = &efi_system_partition_guid;
	} else {
		diskobj->dp = efi_dp_from_part(desc, part);
		diskobj->media.last_block = desc->lba - 1;
	}
	diskobj->part = part;
	diskobj->header.dev = dev;
	/*
	 * Install the device path and the block IO protocol.
	 *
	 * InstallMultipleProtocolInterfaces() checks if the device path is
	 * already installed on an other handle and returns EFI_ALREADY_STARTED
	 * in this case.
	 */
	handle = &diskobj->header;
	ret = efi_install_multiple_protocol_interfaces(
					&handle,
					&efi_guid_device_path, diskobj->dp,
					&efi_block_io_guid, &diskobj->ops,
					/*
					 * esp_guid must be last entry as it
					 * can be NULL. Its interface is NULL.
					 */
					esp_guid, NULL,
					NULL);
	if (ret != EFI_SUCCESS)
		goto error;

#ifdef EFI_SIMPLE_FILE_FS
	/*
	 * On partitions or whole disks without partitions install the
	 * simple file system protocol if a file system is available.
	 */
	if ((part || desc->part_type == PART_TYPE_UNKNOWN) &&
	    efi_fs_exists(desc, part)) {
		diskobj->volume = efi_simple_file_system(desc, part,
							 diskobj->dp);
		ret = efi_add_protocol(&diskobj->header,
				       &efi_simple_file_system_protocol_guid,
				       diskobj->volume);
		if (ret != EFI_SUCCESS)
			return ret;
	}
#endif
	diskobj->ops = block_io_disk_template;
	diskobj->dev_index = dev_index;

	/* Fill in EFI IO Media info (for read/write callbacks) */
	diskobj->media.removable_media = desc->removable;
	diskobj->media.media_present = 1;
	/*
	 * MediaID is just an arbitrary counter.
	 * We have to change it if the medium is removed or changed.
	 */
	diskobj->media.media_id = 1;
	diskobj->media.block_size = desc->blksz;
	diskobj->media.io_align = desc->blksz;
	if (part)
		diskobj->media.logical_partition = 1;
	diskobj->ops.media = &diskobj->media;
	if (disk)
		*disk = diskobj;

	EFI_PRINT("BlockIO: part %u, present %d, logical %d, removable %d"
		  ", last_block %llu\n\n",
		  diskobj->part,
		  diskobj->media.media_present,
		  diskobj->media.logical_partition,
		  diskobj->media.removable_media,
		  diskobj->media.last_block);

	return EFI_SUCCESS;
error:
	efi_delete_handle(&diskobj->header);
	return ret;
}

/*
 * Create a handle for a whole raw disk
 *
 * Create an efi_disk object which is associated with @dev.
 * @return	0 on success, -1 otherwise
 */
static int efi_disk_create_raw(DeviceDisk *dev)
{
	int diskid;
	struct efi_disk_obj *disk;
	efi_status_t ret;

	diskid = dev->desc->dev;
	ret = efi_disk_add_dev(NULL, NULL, dev,
			       diskid, NULL, 0, &disk);
	if (ret != EFI_SUCCESS) {
		if (ret == EFI_NOT_READY)
			log_notice("Disk not ready\n");
		else
			log_err("Adding disk for failed (err=%ld/%#lx)\n", ret, ret);

		return -1;
	}
	raw_disk_handle = &disk->header;
	return 0;
}

/*
 * Create a handle for a disk partition
 *
 *
 * Create an efi_disk object which is associated with @dev.
 *
 * @return	0 on success, -1 otherwise
 */
static int efi_disk_create_part(unsigned int part, DeviceDisk *dev)
{
	int diskid;
	struct disk_partition *info;
	struct efi_handler *handler;
	struct efi_device_path *dp_parent;
	struct efi_disk_obj *disk;
	efi_status_t ret;

	diskid = dev->desc->dev;
	info = get_part_info(part, dev->desc->if_type);
	if (!info){
		printf("Get device part info failed!\n");
		return -1;
	}

	ret = efi_search_protocol(raw_disk_handle, &efi_guid_device_path, &handler);
	if (ret != EFI_SUCCESS)
		return -1;
	dp_parent = (struct efi_device_path *)handler->protocol_interface;

	ret = efi_disk_add_dev(raw_disk_handle, dp_parent, dev, diskid,
			       info, part, &disk);
	if (ret != EFI_SUCCESS) {
		log_err("Adding partition for failed\n");
		return -1;
	}
	return 0;
}

/*
 * Create efi_disk objects for a block device
 *
 * Create efi_disk objects for partitions as well as a raw disk
 * which is associated with @dev.
 * This function is expected to be called at EV_PM_POST_PROBE.
 *
 * @return	0 on success, -1 otherwise
 */
int efi_disk_probe(DeviceDisk *dev)
{
	int ret;
	int part;

	/*
	 * avoid creating duplicated objects now that efi_driver
	 * has already created an efi_disk at this moment.
	 */
	ret = efi_disk_create_raw(dev);
	if (ret)
		return -1;

	for (part = 0; part < dev->dev_fscount; part++) {
		if (dev->part[part]->part_fstype == FS_TYPE_SWAP ||
			dev->part[part]->part_fstype == FS_TYPE_UNKNOWN)
				continue;
		ret = efi_disk_create_part(part, dev);
		if (ret)
			return -1;
	}

	return 0;
}

/*
 * Delete an efi_disk object for a whole raw disk
 *
 * Delete an efi_disk object which is associated with @dev.
 * @return	0 on success, -1 otherwise
 */
static int efi_disk_delete_raw(DeviceDisk *dev)
{
	efi_handle_t handle;
	struct efi_disk_obj *diskobj;

	diskobj = container_of(handle, struct efi_disk_obj, header);
	efi_free_pool(diskobj->dp);

	efi_delete_handle(handle);

	return 0;
}

/*
 * Delete an efi_disk object for a disk partition
 *
 * Delete an efi_disk object which is associated with @dev..
 *
 * @return	0 on success, -1 otherwise
 */
static int efi_disk_delete_part(DeviceDisk *dev)
{
	efi_handle_t handle;
	struct efi_disk_obj *diskobj;

	diskobj = container_of(handle, struct efi_disk_obj, header);

	efi_free_pool(diskobj->dp);
	efi_delete_handle(handle);

	return 0;
}

/*
 * Delete an efi_disk object for a block device
 *
 * Delete an efi_disk object which is associated with @dev.
 *
 * @return	0 on success, -1 otherwise
 */
int efi_disk_remove(void *event)
{
	DeviceDisk *dev;

	efi_disk_delete_raw(dev);
	return efi_disk_delete_part(dev);
}

DeviceDisk *efi_disk_device_init(DeviceDisk **dev)
{
	DeviceDisk *p;
	char *devname = NULL;
	unsigned int dev_num = 0;

	devname = "usb0";
	p = FindDevice(devname);
	if (p != NULL) {
		efi_disk_type |= EFI_DISK_USB;
		dev[dev_num] = p;
		dev[dev_num]->desc = usb_stor_get_dev(0);	//XXX
		dev_num++;
	}

	devname = "nvme0";
	p = FindDevice(devname);
	if (p != NULL) {
		efi_disk_type |= EFI_DISK_NVME;
		dev[dev_num] = p;
		dev[dev_num]->desc = get_nvme_desc();
		dev_num++;
	}

	devname = "wd0";
	p = FindDevice(devname);
	if (p != NULL) {
		efi_disk_type |= EFI_DISK_SATA;
		dev[dev_num] = p;
		dev[dev_num]->desc = sata_dev_desc[curr_port];
		dev_num++;
	}
	return dev_num;
}

/**
 * efi_disks_register() - ensure all block devices are available in UEFI
 *
 * The function probes all block devices. As we store UEFI variables on the
 * EFI system partition this function has to be called before enabling
 * variable services.
 */
efi_status_t efi_disks_register(void)
{
	int ret, i;
	unsigned int dev_num;
	DeviceDisk *dev[MAX_BOOT_DEVICE];

	dev_num = efi_disk_device_init(dev);
	if (!dev) {
		printf("find disk device failed!\n");
		return -1;
	}
	for (i = 0; i < dev_num; i++) {
		if (dev[i]) {
			ret = efi_disk_probe(dev[i]);
			if (ret) {
				printf("disk drvice prob failed!\n");
				return -1;
			}
		}
	}
	return EFI_SUCCESS;
}
