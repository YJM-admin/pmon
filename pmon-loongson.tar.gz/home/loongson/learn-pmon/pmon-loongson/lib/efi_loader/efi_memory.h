#ifndef __EFI_MEMORY_H_
#define __EFI_MEMORY_H__

#include <sys/linux/types.h>
#include <efi_api.h>

struct mem_entry {
	u64 addr;	/* start of memory segment */
	u64 size;	/* size of memory segment */
	u32 type;	/* type of memory segment */
} __attribute__((packed));

#define MEM_RESERVED	0
#define SYSTEM_RAM		1

#define LOW_START 0x200000
#define LEGCY_FW_MEMORY_START 0xF000000
#define LEGCY_FW_MEMORY_SIZE 0x1000000

#define EFI_USED_START_MEM	0xA0000000
#define EFI_USED_END_MEM	0xF0000000

#endif
