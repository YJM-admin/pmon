// SPDX-License-Identifier: GPL-2.0+
/*
 *  EFI setup code
 *
 *  Copyright (c) 2022 loongson.cn et al.
 */

#include <log.h>
#include <kconfig.h>
#include <efi_loader.h>
#include <efi_variable.h>

#define OBJ_LIST_NOT_INITIALIZED 1

efi_status_t efi_obj_list_initialized = OBJ_LIST_NOT_INITIALIZED;

#ifdef CONFIG_EFI_SECURE_BOOT
/**
 * efi_init_secure_boot - initialize secure boot state
 *
 * Return:	status code
 */
static efi_status_t efi_init_secure_boot(void)
{
	efi_guid_t signature_types[] = {
		EFI_CERT_SHA256_GUID,
		EFI_CERT_X509_GUID,
	};
	efi_status_t ret;

	ret = efi_set_variable_int(u"SignatureSupport",
				   &efi_global_variable_guid,
				   EFI_VARIABLE_READ_ONLY |
				   EFI_VARIABLE_BOOTSERVICE_ACCESS |
				   EFI_VARIABLE_RUNTIME_ACCESS,
				   sizeof(signature_types),
				   &signature_types, false);
	if (ret != EFI_SUCCESS)
		printf("EFI: cannot initialize SignatureSupport variable\n");

	return ret;
}
#else
static efi_status_t efi_init_secure_boot(void)
{
	return EFI_SUCCESS;
}
#endif /* CONFIG_EFI_SECURE_BOOT */

/**
 * efi_init_capsule - initialize capsule update state
 *
 * Return:	status code
 */
static efi_status_t efi_init_capsule(void)
{
	efi_status_t ret = EFI_SUCCESS;

	ret = efi_set_variable_int(u"CapsuleMax",
			&efi_guid_capsule_report,
			EFI_VARIABLE_READ_ONLY |
			EFI_VARIABLE_BOOTSERVICE_ACCESS |
			EFI_VARIABLE_RUNTIME_ACCESS,
			22, u"CapsuleFFFF", false);
	if (ret != EFI_SUCCESS)
		printf("EFI: cannot initialize CapsuleMax variable\n");

	return EFI_SUCCESS;
}

/**
 * efi_init_obj_list() - Initialize and populate EFI object list
 *
 * Return:	status code
 */
efi_status_t efi_init_obj_list(void)
{
	efi_status_t ret = EFI_SUCCESS;

	/* Initialize once only */
	if (efi_obj_list_initialized != OBJ_LIST_NOT_INITIALIZED)
		return efi_obj_list_initialized;

	efi_memory_init();

	/* Initialize root node */
	ret = efi_root_node_register();
	if (ret != EFI_SUCCESS)
		goto out;

	/* Initialize EFI driver uclass */
	ret = efi_disks_register();
	if (ret != EFI_SUCCESS)
		goto out;

	ret = efi_console_register();
	if (ret != EFI_SUCCESS)
		goto out;

	/* Initialize variable services */
	ret = efi_init_variables();
	if (ret != EFI_SUCCESS)
		goto out;

	/* Secure boot */
	ret = efi_init_secure_boot();
	if (ret != EFI_SUCCESS)
		goto out;

	/* Indicate supported runtime services */
	ret = efi_init_runtime_supported();
	if (ret != EFI_SUCCESS)
		goto out;

	ret = efi_load_capsule_drivers();
	if (ret != EFI_SUCCESS)
		goto out;

	ret = efi_gop_register();
	if (ret != EFI_SUCCESS)
		goto out;

#ifdef ACPI_SUPPORT
	ret = loongson_acpi_init();
	if (ret != EFI_SUCCESS)
		goto out;
#endif

	ret = efi_init_capsule();
	if (ret != EFI_SUCCESS)
		goto out;
	/* Initialize EFI runtime services */
	ret = efi_reset_system_init();
	if (ret != EFI_SUCCESS)
		goto out;

	if (((readl(EFI_ACPI_PM1_CNT_REG) >> 10) & 0x7) == SLEEP_TYPE_CAPSULE) {
		readl(EFI_ACPI_PM1_CNT_REG) &= (~(0x7 << 10));
		ret = efi_launch_capsules();
		if (ret != EFI_SUCCESS) {
			printf("capsule update error, narmal boot continue.\n");
			return ret;
		}
	}
out:
	efi_obj_list_initialized = ret;
	return ret;
}
