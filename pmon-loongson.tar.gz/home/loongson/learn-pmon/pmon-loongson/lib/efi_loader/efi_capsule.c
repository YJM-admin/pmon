// SPDX-License-Identifier: GPL-2.0+
/*
 *  EFI Capsule
 *
 *  Copyright (c) 2018 Linaro Limited
 *			Author: AKASHI Takahiro
 */

#define LOG_CATEGORY LOGC_EFI

#include <efi_api.h>
#include <efi_loader.h>
#include <efi_variable.h>
#include <linux/kernel.h>
#include <sys/malloc.h>
#include <charset.h>
#include <kconfig.h>

DECLARE_GLOBAL_DATA_PTR;

#define DEFAULT_SG_LIST_HEADS	20
#define MIN_COALESCE_ADDR (1024 * 1024)
#define CAPSULE_TEMP_BUFFER_SIZE	8*1024*1024

const efi_guid_t efi_guid_capsule_report = EFI_CAPSULE_REPORT_GUID;
static const efi_guid_t efi_guid_firmware_management_capsule_id =
		EFI_FIRMWARE_MANAGEMENT_CAPSULE_ID_GUID;
const efi_guid_t efi_guid_firmware_management_protocol =
		EFI_FIRMWARE_MANAGEMENT_PROTOCOL_GUID;
const efi_guid_t gEfiCapsuleVendorGuid = EFI_CAPSULE_VENDOR_GUID;
const char *capsule_variable_array[5] = {"CapsuleUpdateData", "CapsuleUpdateData1",
										  "CapsuleUpdateData2",	"CapsuleUpdateData3",
										  "CapsuleUpdateData4"};
extern char capsule_selftest_update;
int mindex = 0;
/**
 * get_last_capsule - get the last capsule index
 *
 * Retrieve the index of the capsule invoked last time from "CapsuleLast"
 * variable.
 *
 * Return:
 * * > 0	- the last capsule index invoked
 * * 0xffff	- on error, or no capsule invoked yet
 */
static unsigned int get_last_capsule(void)
{
	u16 value16[11]; /* "CapsuleXXXX": non-null-terminated */
	char value[5];
	efi_uintn_t size;
	unsigned long index = 0xffff;
	efi_status_t ret;
	int i;

	size = sizeof(value16);
	ret = efi_get_variable_int(u"CapsuleLast", &efi_guid_capsule_report,
				   NULL, &size, value16, NULL);
	if (ret != EFI_SUCCESS || size != 22 ||
	    u16_strncmp(value16, u"Capsule", 7))
		goto err;
	for (i = 0; i < 4; ++i) {
		u16 c = value16[i + 7];

		if (!c || c > 0x7f)
			goto err;
		value[i] = c;
	}
	value[4] = 0;
	if (strtoul(value, 16, &index))
		index = 0xffff;
err:
	return index;
}

/**
 * set_capsule_result - set a result variable
 * @capsule:		Capsule
 * @return_status:	Return status
 *
 * Create and set a result variable, "CapsuleXXXX", for the capsule,
 * @capsule.
 */
static
void set_capsule_result(int index, struct efi_capsule_header *capsule,
			efi_status_t return_status)
{
	u16 variable_name16[12];
	struct efi_capsule_result_variable_header result;
	struct efi_time time;
	efi_status_t ret;

	efi_create_indexed_name(variable_name16, sizeof(variable_name16),
				"Capsule", index);
	result.variable_total_size = sizeof(result);
	result.capsule_guid = capsule->capsule_guid;
	ret = EFI_CALL((*efi_runtime_services.get_time)(&time, NULL));
	if (ret == EFI_SUCCESS)
		memcpy(&result.capsule_processed, &time, sizeof(time));
	else
		memset(&result.capsule_processed, 0, sizeof(time));
	result.capsule_status = return_status;
	ret = efi_set_variable_int(variable_name16, &efi_guid_capsule_report,
				   EFI_VARIABLE_NON_VOLATILE |
				   EFI_VARIABLE_BOOTSERVICE_ACCESS |
				   EFI_VARIABLE_RUNTIME_ACCESS,
				   sizeof(result), &result, false);
	if (ret != EFI_SUCCESS) {
		printf("Setting %ls failed\n", variable_name16);
		return;
	}

	/* Variable CapsuleLast must not include terminating 0x0000 */
	ret = efi_set_variable_int(u"CapsuleLast", &efi_guid_capsule_report,
				   EFI_VARIABLE_READ_ONLY |
				   EFI_VARIABLE_NON_VOLATILE |
				   EFI_VARIABLE_BOOTSERVICE_ACCESS |
				   EFI_VARIABLE_RUNTIME_ACCESS,
				   22, variable_name16, false);
	if (ret != EFI_SUCCESS)
		printf("Setting %ls failed\n", u"CapsuleLast");
}

/**
 * efi_fmp_find - search for Firmware Management Protocol drivers
 * @image_type:		Image type guid
 * @image_index:	Image Index
 * @instance:		Instance number
 * @handles:		Handles of FMP drivers
 * @no_handles:		Number of handles
 *
 * Search for Firmware Management Protocol drivers, matching the image
 * type, @image_type and the machine instance, @instance, from the list,
 * @handles.
 *
 * Return:
 * * Protocol instance	- on success
 * * NULL		- on failure
 */
static struct efi_firmware_management_protocol *
efi_fmp_find(efi_guid_t *image_type, u8 image_index, u64 instance,
	     efi_handle_t *handles, efi_uintn_t no_handles)
{
	efi_handle_t *handle;
	struct efi_firmware_management_protocol *fmp;
	struct efi_firmware_image_descriptor *image_info, *desc;
	efi_uintn_t info_size, descriptor_size;
	u32 descriptor_version;
	u8 descriptor_count;
	u32 package_version;
	u16 *package_version_name;
	bool found = false;
	int i, j;
	efi_status_t ret;

	for (i = 0, handle = handles; i < no_handles; i++, handle++) {
		ret = EFI_CALL(efi_handle_protocol(
				*handle,
				&efi_guid_firmware_management_protocol,
				(void **)&fmp));
		if (ret != EFI_SUCCESS)
			continue;

			return fmp;
	}

	return NULL;
}

/**
 * efi_remove_auth_hdr - remove authentication data from image
 * @image:	Pointer to pointer to Image
 * @image_size:	Pointer to Image size
 *
 * Remove the authentication data from image if possible.
 * Update @image and @image_size.
 *
 * Return:		status code
 */
static efi_status_t efi_remove_auth_hdr(void **image, efi_uintn_t *image_size)
{
	struct efi_firmware_image_authentication *auth_hdr;
	efi_status_t ret = EFI_INVALID_PARAMETER;

	auth_hdr = (struct efi_firmware_image_authentication *)*image;
	if (*image_size < sizeof(*auth_hdr))
		goto out;

	if (auth_hdr->auth_info.hdr.dwLength <=
	    offsetof(struct win_certificate_uefi_guid, cert_data))
		goto out;

	*image = (uint8_t *)*image + sizeof(auth_hdr->monotonic_count) +
		auth_hdr->auth_info.hdr.dwLength;
	*image_size = *image_size - auth_hdr->auth_info.hdr.dwLength -
		sizeof(auth_hdr->monotonic_count);
	EFI_PRINT("auth_hdr->auth_info.hdr.dwLength: %lx *image_size: %lx\n", auth_hdr->auth_info.hdr.dwLength, *image_size);
	ret = EFI_SUCCESS;
out:
	return ret;
}

#ifdef CAPSULE_AUTHENTICATE
int efi_get_public_key_data(void **pkey, efi_uintn_t *pkey_len)
{
	const void *fdt_blob = gd->fdt_blob;
	const void *blob;
	const char *cnode_name = "capsule-key";
	const char *snode_name = "signature";
	int sig_node;
	int len;

	sig_node = fdt_subnode_offset(fdt_blob, 0, snode_name);
	if (sig_node < 0) {
		printf("Unable to get signature node offset\n");

		return -FDT_ERR_NOTFOUND;
	}

	blob = fdt_getprop(fdt_blob, sig_node, cnode_name, &len);

	if (!blob || len < 0) {
		printf("Unable to get capsule-key value\n");
		*pkey = NULL;
		*pkey_len = 0;

		return -FDT_ERR_NOTFOUND;
	}

	*pkey = (void *)blob;
	*pkey_len = len;

	return 0;
}

efi_status_t efi_capsule_authenticate(const void *capsule, efi_uintn_t capsule_size,
				      void **image, efi_uintn_t *image_size)
{
	u8 *buf;
	int ret;
	void *fdt_pkey, *pkey;
	efi_uintn_t pkey_len;
	unsigned long_t monotonic_count;
	struct efi_signature_store *truststore;
	struct pkcs7_message *capsule_sig;
	struct efi_image_regions *regs;
	struct efi_firmware_image_authentication *auth_hdr;
	efi_status_t status;

	status = EFI_SECURITY_VIOLATION;
	capsule_sig = NULL;
	truststore = NULL;
	regs = NULL;

	/* Sanity checks */
	if (capsule == NULL || capsule_size == 0)
		goto out;

	*image = (uint8_t *)capsule;
	*image_size = capsule_size;
	if (efi_remove_auth_hdr(image, image_size) != EFI_SUCCESS)
		goto out;

	auth_hdr = (struct efi_firmware_image_authentication *)capsule;
	if (guidcmp(&auth_hdr->auth_info.cert_type, &efi_guid_cert_type_pkcs7))
		goto out;

	memcpy(&monotonic_count, &auth_hdr->monotonic_count,
	       sizeof(monotonic_count));

	/* data to be digested */
	regs = calloc(sizeof(*regs) + sizeof(struct image_region) * 2, 1);
	if (!regs)
		goto out;

	regs->max = 2;
	efi_image_region_add(regs, (uint8_t *)*image,
			     (uint8_t *)*image + *image_size, 1);

	efi_image_region_add(regs, (uint8_t *)&monotonic_count,
			     (uint8_t *)&monotonic_count + sizeof(monotonic_count),
			     1);

	capsule_sig = efi_parse_pkcs7_header(auth_hdr->auth_info.cert_data,
					     auth_hdr->auth_info.hdr.dwLength
					     - sizeof(auth_hdr->auth_info),
					     &buf);
	if (IS_ERR(capsule_sig)) {
		debug("Parsing variable's pkcs7 header failed\n");
		capsule_sig = NULL;
		goto out;
	}
	ret = efi_get_public_key_data(&fdt_pkey, &pkey_len);
	if (ret < 0)
		goto out;

	pkey = malloc(pkey_len);
	if (!pkey)
		goto out;

	memcpy(pkey, fdt_pkey, pkey_len);
	truststore = efi_build_signature_store(pkey, pkey_len);
	if (!truststore)
		goto out;

	/* verify signature */
	if (efi_signature_verify(regs, capsule_sig, truststore, NULL)) {
		debug("Verified\n");
	} else {
		debug("Verifying variable's signature failed\n");
		goto out;
	}

	status = EFI_SUCCESS;

out:
	efi_sigstore_free(truststore);
	pkcs7_free_message(capsule_sig);
	free(regs);

	return status;
}

#endif
/**
 * efi_update_capsule() - process information from operating system
 * @capsule_header_array:	Array of virtual address pointers
 * @capsule_count:		Number of pointers in capsule_header_array
 * @scatter_gather_list:	Array of physical address pointers
 *
 * This function implements the UpdateCapsule() runtime service.
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * Return:			status code
 */
efi_status_t efi_update_capsule(
		struct efi_capsule_header **capsule_header_array,
		efi_uintn_t capsule_count,
		u64 scatter_gather_list)
{
	efi_status_t ret;
	unsigned int i;
	struct efi_capsule_header *capsule;

	EFI_ENTRY("%p, %zu, %lx\n", capsule_header_array, capsule_count,
		  scatter_gather_list);

	if (!capsule_count) {
		ret = EFI_INVALID_PARAMETER;
		goto out;
	}

#ifdef CONFIG_EFI_ESRT
	/* Rebuild the ESRT to reflect any updated FW images. */
	ret = efi_esrt_populate();
	if (ret != EFI_SUCCESS)
		log_warning("ESRT update failed\n");
#endif
	ret = efi_set_variable_int(capsule_variable_array[mindex],
			&gEfiCapsuleVendorGuid,
			EFI_VARIABLE_NON_VOLATILE |
			EFI_VARIABLE_BOOTSERVICE_ACCESS |
			EFI_VARIABLE_RUNTIME_ACCESS,
			sizeof(unsigned long),
			&scatter_gather_list, false);
	if (ret != EFI_SUCCESS)
		printf("Setting %ls failed\n", u"CapsuleUpdateData");
	mindex++;
out:
	return EFI_EXIT(ret);
}

/**
 * efi_query_capsule_caps() - check if capsule is supported
 * @capsule_header_array:	Array of virtual pointers
 * @capsule_count:		Number of pointers in capsule_header_array
 * @maximum_capsule_size:	Maximum capsule size
 * @reset_type:			Type CapsuleUpdateDatareset needed for capsule update
 *
 * This function implements the QueryCapsuleCapabilities() runtime service.
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * Return:			status code
 */
efi_status_t efi_query_capsule_caps(
		struct efi_capsule_header **capsule_header_array,
		efi_uintn_t capsule_count,
		u64 *maximum_capsule_size,
		u32 *reset_type)
{
	struct efi_capsule_header *capsule __attribute__((unused));
	unsigned int i;
	efi_status_t ret;

	EFI_ENTRY("%p, %zu, %p, %p\n", capsule_header_array, capsule_count,
		  maximum_capsule_size, reset_type);

	if (!maximum_capsule_size) {
		ret = EFI_INVALID_PARAMETER;
		goto out;
	}

	*maximum_capsule_size = U64_MAX;
	*reset_type = EFI_RESET_WARM;

	ret = EFI_SUCCESS;
	for (i = 0, capsule = *capsule_header_array; i < capsule_count;
	     i++, capsule = *(++capsule_header_array)) {
		/* TODO */
	}
out:
	return EFI_EXIT(ret);
}

/**
 * efi_load_capsule_drivers - initialize capsule drivers
 *
 * Generic FMP drivers backed by DFU
 *
 * Return:	status code
 */
efi_status_t efi_load_capsule_drivers(void)
{
	efi_handle_t handle;
	efi_status_t ret = EFI_SUCCESS;

	handle = NULL;
	ret = EFI_CALL(efi_install_multiple_protocol_interfaces(
				&handle,
				&efi_guid_firmware_management_protocol,
				&efi_fmp_raw, NULL));
	return ret;
}

/**
 * check_run_capsules() - check whether capsule update should run
 *
 * Return:	EFI_SUCCESS if update to run, EFI_NOT_FOUND otherwise
 */
static efi_status_t check_run_capsules(void)
{
	efi_status_t r;
	efi_uintn_t size;
	unsigned long sg_list;


	size = sizeof(unsigned long);
	r = efi_get_variable_int("CapsuleUpdateData",
			&gEfiCapsuleVendorGuid, NULL, &size, &sg_list, NULL);
	if (r != EFI_SUCCESS || size != sizeof(unsigned long))
		return EFI_NOT_FOUND;

	return EFI_SUCCESS;
}

efi_status_t get_sglist_entry(unsigned long **hlist, unsigned long *len)
{
	efi_status_t r;
	efi_uintn_t size, tmp_list_len;
	unsigned long sg_list;
	unsigned long *tmp_list;
	unsigned long *enlarged_list;
	unsigned int temp_index, valid_index = 0;
	unsigned int index = 0;
	char flag;

	tmp_list_len = DEFAULT_SG_LIST_HEADS * sizeof(unsigned long);
	tmp_list = malloc(tmp_list_len);
	if (tmp_list == NULL) {
		printf("Failed to allocate memory\n");
		return EFI_OUT_OF_RESOURCES;
	}

	while(1) {
		size = sizeof(unsigned long);
		r = efi_get_variable_int(capsule_variable_array[index],
				&gEfiCapsuleVendorGuid, NULL, &size, &sg_list, NULL);
		if (r != EFI_SUCCESS) {
			if (r != EFI_NOT_FOUND)
				printf("Unexpected error getting Capsule Update variable. r: %x\n", r);
			break;
		}

		flag = 0;
		for (temp_index = 0; temp_index < valid_index; temp_index++) {
			if (tmp_list[temp_index] == sg_list) {
				flag = 1;
				break;
			}
		}
		if (flag) {
			index++;
			continue;
		}
		if ((valid_index + 1) >= tmp_list_len) {
			enlarged_list = malloc(tmp_list_len * 2);
			if (enlarged_list == NULL) {
				printf("Fail to allocate memory!\n");
				return EFI_OUT_OF_RESOURCES;
			}
			memcpy(enlarged_list, tmp_list, tmp_list_len);
			free(tmp_list);
			tmp_list = enlarged_list;
			tmp_list_len *= 2;
		}

		EFI_PRINT("Get OS capsule sglist addr: %lx\n\n", sg_list);

		tmp_list[valid_index++] = PHYS_TO_UNCACHED(sg_list);
		index++;
	}
	if (valid_index == 0) {
		printf("Do not find SG list in variable\n");
		return EFI_NOT_FOUND;
	}

	*hlist = malloc((valid_index + 1) * sizeof(unsigned long));
	if (*hlist == NULL) {
		printf("Failed to allocate memory\n");
		return EFI_OUT_OF_RESOURCES;
	}
	memcpy(*hlist, tmp_list, (valid_index) * sizeof(unsigned long));
	*len = valid_index;
	free(tmp_list);
	return EFI_SUCCESS;
}

efi_status_t get_capsule_info(struct efi_capsule_block_desc *desc,
		unsigned long *descnum, unsigned long *capsize, unsigned long *capnum)
{
	unsigned long size = 0;
	unsigned long count = 0;
	unsigned long number = 0;
	unsigned long cap_image_size = 0;
	struct efi_capsule_header *cap_head;

	EFI_PRINT("GetCapsuleInfo enter\n");

	if (desc == NULL)
		return EFI_INVALID_PARAMETER;

	while (desc->unions.continue_pointer != (unsigned long) NULL) {
		if (desc->len == 0) {
			desc = (struct efi_capsule_header *)(unsigned long)desc->unions.continue_pointer;
		} else {
			if (desc->len >= (MAX_ADDRESS - size)) {
				printf("ERROR: desc->len(0x%lx) >= (MAX_ADDRESS - size(0x%x))\n", desc->len, size);
				return EFI_OUT_OF_RESOURCES;
			}
			size += (unsigned long)desc->len;
			count++;

			if (cap_image_size == 0) {
				cap_head = PHYS_TO_UNCACHED((struct efi_capsule_header *)((unsigned long)desc->unions.data_block));
				number++;
				cap_image_size = cap_head->capsule_image_size;
			}
			if (cap_image_size < desc->len)
				return EFI_INVALID_PARAMETER;

			cap_image_size = (unsigned long)(cap_image_size - desc->len);
			desc++;
		}
	}
	if (count == 0) {
		printf("ERROR: count == 0\n");
		return EFI_NOT_FOUND;
	}
	if (cap_image_size != 0)
		return EFI_INVALID_PARAMETER;

	if (descnum != NULL && capsize != NULL && capnum != NULL) {
		*descnum = count;
		*capsize = size;
		*capnum = number;
	}
	EFI_PRINT("%d Get info capsize - 0x%x capnum: %lx descnum: %lx\n", __LINE__ , *capsize, *capnum, *descnum);
	return EFI_SUCCESS;
}

char reverse8(char data)
{
    char i;
    char temp = 0;

    for (i = 0; i < 8; i++)
        temp |= ((data >> i) & 0x01) << (7 - i);
    return temp;
}

char reverse32(char data)
{
    char i;
    char temp = 0;
    for (i = 0; i < 32; i++)
        temp |= ((data >> i) & 0x01) << (31 - i);
    return temp;
}

static unsigned cap_crc(char *buf, unsigned int num)
{
	char data;
	unsigned int i, tmp;
	unsigned int crc = 0xffffffff;
	char *addr = buf;

	EFI_PRINT("CRC Start Addr: 0x%lx, capusle_size = 0x%lx\n", addr, num);
	EFI_PRINT("Start 0x100 Data:\n");

	for(tmp = 0; tmp < 0x100; tmp++) {
		EFI_PRINT("%02x ",(char)addr[tmp]);
		if(((tmp + 1) % 16) == 0)
			EFI_PRINT("\n");
	}
	EFI_PRINT("...........\n");

	for (; num > 0; num--) {
		data = *addr++;
		data = reverse8(data);
		crc = crc ^ (data << 24);
		for (i = 0; i < 8; i++) {
			if (crc & 0x80000000)
				crc = (crc << 1) ^ 0x04c11db7;
			else {
				crc <<= 1;
			}
		}
	}
	crc = reverse32(crc);
	crc = crc ^ 0xffffffff;
	EFI_PRINT("CRC:0x%08x\n", crc);
	return crc;
}

/**
  The capsule block descriptors may be fragmented and spread all over memory.
  To simplify the coalescing of capsule blocks, first coalesce all the
  capsule block descriptors low in memory.

  The descriptors passed in can be fragmented throughout memory. Here
  they are relocated into memory to turn them into a contiguous (null
  terminated) array.

  @param PeiServices    pointer to PEI services table
  @param blk_list      pointer to the capsule block descriptors
  @param desc_num number of capsule data block descriptors, whose len is non-zero.
  @param mem_base        base of system memory in which we can work
  @param mem_size        size of the system memory pointed to by mem_base

  @retval NULL    could not relocate the descriptors
  @retval Pointer to the base of the successfully-relocated block descriptors.

**/
struct efi_capsule_block_desc *relocate_desc(struct efi_capsule_block_desc *blk_list,
		unsigned int desc_num, char *mem_base, unsigned int mem_size)
{
	char *reloc_buff;
	unsigned int buff_size;
	unsigned int blk_list_size;
	struct efi_capsule_block_desc *new_blk_list;
	struct efi_capsule_block_desc *cur_desc_head;
	struct efi_capsule_block_desc *tmp_desc;
	struct efi_capsule_block_desc *pre_desc = NULL;

	buff_size = desc_num * sizeof(struct efi_capsule_block_desc);
	new_blk_list  = (struct efi_capsule_block_desc *)mem_base;
	if (mem_size < buff_size) {
		return NULL;
	}

	mem_size -= buff_size;
	mem_base += buff_size;

	tmp_desc = blk_list;
	cur_desc_head = new_blk_list;
	while ((tmp_desc != NULL) && (tmp_desc->unions.continue_pointer != NULL)) {
		if (tmp_desc->len != 0) {
			cur_desc_head->unions.data_block = tmp_desc->unions.data_block;
			cur_desc_head->len = tmp_desc->len;
			cur_desc_head++;
			tmp_desc++;
		} else {
			tmp_desc = (struct efi_capsule_block_desc *)tmp_desc->unions.continue_pointer;
		}
	}
	cur_desc_head->unions.continue_pointer = NULL;
	cur_desc_head->len = 0;
	return new_blk_list;
}

efi_status_t capdata_coalesce(unsigned long *hlist, char **mem_base, int mem_size)
{
	efi_status_t status;
	void *new_cap_base;
	unsigned int size_left;
	char *free_mem_base, *dest_ptr;
	unsigned int desc_num, capsize, capnum;
	unsigned int desc_size, free_mem_size;
	struct efi_capsule_header *cap_header;
	struct efi_capsule_block_desc *cap_desc;
	struct efi_capsule_block_desc *blk_list;
	struct efi_capsule_block_desc *cur_blk_desc;

	unsigned int loops = 0;
	unsigned int cap_image_size = 0;
	unsigned int cap_begain_flag = true;

	cap_desc = (struct efi_capsule_block_desc *)*hlist;

	status = get_capsule_info(cap_desc, &desc_num, &capsize, &capnum);
	if (status != EFI_SUCCESS)
		return status;

	if (!capsize || !capnum || !desc_num)
		return EFI_NOT_FOUND;

	cap_crc(PHYS_TO_UNCACHED(cap_desc->unions.continue_pointer), capsize);

	desc_size  = desc_num * sizeof (struct efi_capsule_block_desc);
	printf("Capsule Memory range from 0x%lx to 0x%lx\n", (unsigned long )*mem_base, (unsigned long )*mem_base + mem_size);
	if ((unsigned long )*mem_base < (unsigned long )MIN_COALESCE_ADDR) {
		if (((unsigned long )*mem_base + mem_size) < (unsigned long )MIN_COALESCE_ADDR) {
			return EFI_BUFFER_TOO_SMALL;
		} else {
			mem_size = mem_size - ((unsigned long ) MIN_COALESCE_ADDR - (unsigned long ) *mem_base);
			*mem_base = (void *) (unsigned long ) MIN_COALESCE_ADDR;
		}
	}

	if (mem_size <= (capsize + desc_size)) {
		printf("ERROR: capsize + desc_size - 0x%x\n", capsize + desc_size);
		return EFI_BUFFER_TOO_SMALL;
	}

	free_mem_base = *mem_base;
	free_mem_size = mem_size;

	blk_list = relocate_desc(cap_desc, desc_num, free_mem_base, free_mem_size);
	if (blk_list == NULL) {
		//
		// Not enough room to relocate the descriptors
		//
		return EFI_BUFFER_TOO_SMALL;
	}

	//
	// Take the top of memory for the capsule. unsigned long align up.
	//
	dest_ptr         = free_mem_base + free_mem_size - capsize;
	dest_ptr         = (char *)(((unsigned long )dest_ptr + sizeof (unsigned long) - 1) & ~(sizeof (unsigned long) - 1));
	free_mem_base     = (char *)blk_list + desc_size;
	free_mem_size     = (unsigned long )dest_ptr - (unsigned long )free_mem_base;
	new_cap_base  = (void *) dest_ptr;

	cur_blk_desc = blk_list;
	while ((cur_blk_desc->len != 0) || (cur_blk_desc->unions.continue_pointer != NULL)) {
		if (cap_begain_flag) {
			cap_begain_flag  = false;
			cap_header     = (struct efi_capsule_header *)(unsigned long )PHYS_TO_UNCACHED(cur_blk_desc->unions.data_block);
			size_left          = cap_header->capsule_image_size;
			cap_image_size += size_left;
		}

		memcpy((void *)dest_ptr, (void *) (unsigned long )PHYS_TO_UNCACHED(cur_blk_desc->unions.data_block), (unsigned long )cur_blk_desc->len);
		EFI_PRINT("Capsule coalesce block no.0x%lX from 0x%lX to 0x%lX with size 0x%lX\n",(unsigned long)loops,
				cur_blk_desc->unions.data_block, (unsigned long)(unsigned long )dest_ptr, cur_blk_desc->len);
		dest_ptr += cur_blk_desc->len;
		size_left -= cur_blk_desc->len;

		if (size_left == 0)
			cap_begain_flag = true;
		//
		//Walk through the block descriptor list.
		//
		cur_blk_desc++;
	}

	*mem_base = (void *)new_cap_base;
	mem_size = (unsigned long )capsize;

	return status;
}

/**
 * efi_capsule_update_firmware - update firmware from capsule
 * @capsule_data:	Capsule
 *
 * Update firmware, using a capsule, @capsule_data. Loading any FMP
 * drivers embedded in a capsule is not supported.
 *
 * Return:		status code
 */
static efi_status_t efi_capsule_update_firmware(
		struct efi_capsule_header *capsule_data)
{
	struct efi_firmware_management_capsule_header *capsule;
	struct efi_firmware_management_capsule_image_header *image;
	size_t capsule_size, image_binary_size;
	void *image_binary, *vendor_code;
	efi_handle_t *handles;
	efi_uintn_t no_handles;
	int item;
	struct efi_firmware_management_protocol *fmp;
	u16 *abort_reason;
	efi_status_t ret = EFI_SUCCESS;

	/* sanity check */
	if (capsule_data->header_size < sizeof(*capsule) ||
	    capsule_data->header_size >= capsule_data->capsule_image_size)
		return EFI_INVALID_PARAMETER;

	capsule = (void *)capsule_data + capsule_data->header_size;
	capsule_size = capsule_data->capsule_image_size
			- capsule_data->header_size;

	if (capsule->version != 0x00000001)
		return EFI_UNSUPPORTED;

	handles = NULL;
	ret = EFI_CALL(efi_locate_handle_buffer(
			BY_PROTOCOL,
			&efi_guid_firmware_management_protocol,
			NULL, &no_handles, (efi_handle_t **)&handles));
	if (ret != EFI_SUCCESS)
		return EFI_UNSUPPORTED;

	/* Payload */
	for (item = capsule->embedded_driver_count;
	     item < capsule->embedded_driver_count
		    + capsule->payload_item_count; item++) {
		/* sanity check */
		if ((capsule->item_offset_list[item] + sizeof(*image)
				 >= capsule_size)) {
			printf("Capsule does not have enough data\n");
			ret = EFI_INVALID_PARAMETER;
			goto out;
		}

		image = (void *)capsule + capsule->item_offset_list[item];

		if (image->version != 0x2) {
			ret = EFI_UNSUPPORTED;
			goto out;
		}

		/* find a device for update firmware */
		fmp = efi_fmp_find(&image->update_image_type_id,
				   image->update_image_index,
				   image->update_hardware_instance,
				   handles, no_handles);
		if (!fmp) {
			printf("FMP driver not found for firmware type %pUs, hardware instance %lld\n",
				&image->update_image_type_id,
				image->update_hardware_instance);
			ret = EFI_UNSUPPORTED;
			goto out;
		}

		image_binary = (void *)image + sizeof(*image);
		image_binary_size = image->update_image_size;
		vendor_code = image_binary + image_binary_size;

		if (!IS_ENABLED(CONFIG_EFI_CAPSULE_AUTHENTICATE)) {
			ret = efi_remove_auth_hdr(&image_binary,
					&image_binary_size);
			if (ret != EFI_SUCCESS)
				goto out;
		}
		abort_reason = NULL;
		EFI_PRINT("image->update_image_index: %lx image_binary: %lx image_binary_size: %lx\n",
				image->update_image_index, image_binary, image_binary_size);
		ret = EFI_CALL(fmp->set_image(fmp, image->update_image_index,
					      image_binary,
					      image_binary_size,
					      vendor_code, NULL,
					      &abort_reason));
		if (ret != EFI_SUCCESS) {
			printf("Firmware update failed: %ls\n",
				abort_reason);
			efi_free_pool(abort_reason);
			goto out;
		}
	}

out:
	efi_free_pool(handles);

	return ret;
}


/**
 * efi_launch_capsule - launch capsules
 *
 * Launch all the capsules in system at boot time.
 * Called by efi init code
 *
 * Return:	status codde
 */
efi_status_t efi_launch_capsules(void)
{
	efi_status_t ret;
	void *capsule_buffer;
	unsigned long sg_list;
	unsigned long list_len;
	unsigned int index, i;
	unsigned long *list_head;
	struct efi_capsule_header *capsule;

	if (check_run_capsules() != EFI_SUCCESS)
		return EFI_SUCCESS;

	ret = get_sglist_entry(&list_head, &list_len);
	if (ret != EFI_SUCCESS || list_head == NULL) {
		printf("Get SG list failed\n");
		return EFI_NOT_FOUND;
	}

	capsule_buffer = malloc(CAPSULE_TEMP_BUFFER_SIZE);
	if (!capsule_buffer) {
		printf("alloc capsule buffer failed!\n");
		return EFI_NOT_FOUND;
	}

	ret = capdata_coalesce(list_head, &capsule_buffer, 8*1024*1024);
	if (ret != EFI_SUCCESS) {
		printf("capsule coalesce failed\n");
		return EFI_NOT_FOUND;
	}

	capsule = (struct efi_capsule_header *)capsule_buffer;
	/* Launch capsules */
	for (i = 0; i < list_len; i++) {
		if (!guidcmp(&capsule->capsule_guid,
					&efi_guid_firmware_management_capsule_id)) {
			ret = efi_capsule_update_firmware(capsule);
			if (ret != EFI_SUCCESS)
				printf("Applying capsule failed.\n");
			else
				EFI_PRINT("Applying capsule succeeded.\n");
		}

		/* create CapsuleXXXX */
		set_capsule_result(index, capsule, ret);
	}

	printf("Reboot after firmware update.\n");

	/* Cold reset is required for loading the new firmware. */
	tgt_reboot();

	while(1);
	/* not reach here */
	return 0;
}
