// SPDX-License-Identifier: GPL-2.0+
/*
 * EFI device path from u-boot device-model mapping
 *
 * (C) Copyright 2017 Rob Clark
 */

#define LOG_CATEGORY LOGC_EFI

#include <part.h>
#include <diskfs.h>
#include <sys/malloc.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <efi_loader.h>
#include <charset.h>

#include "../../sys/dev/usb/usb.h"

#define PART_FORMAT_PCAT	0x1
#define PART_FORMAT_GPT		0x2

extern unsigned char efi_disk_type;
extern int curr_port;
extern block_dev_desc_t *get_nvme_desc();
extern block_dev_desc_t *usb_stor_get_dev(int index);
/*
 * Identifies the partition table type (ie. MBR vs GPT GUID) signature
 */
enum sig_type {
	SIG_TYPE_NONE,
	SIG_TYPE_MBR,
	SIG_TYPE_GUID,

	SIG_TYPE_COUNT			/* Number of signature types */
};

/* template END node: */
const struct efi_device_path END = {
	.type     = DEVICE_PATH_TYPE_END,
	.sub_type = DEVICE_PATH_SUB_TYPE_END,
	.length   = sizeof(END),
};

/* template ROOT node: */
static const struct efi_device_path_vendor ROOT = {
	.dp = {
		.type     = DEVICE_PATH_TYPE_HARDWARE_DEVICE,
		.sub_type = DEVICE_PATH_SUB_TYPE_VENDOR,
		.length   = sizeof(ROOT),
	},
	.guid = EFI_PMON_GUID,
};

static void *dp_alloc(size_t sz)
{
	void *buf;

	if (efi_allocate_pool(EFI_BOOT_SERVICES_DATA, sz, &buf) !=
	    EFI_SUCCESS) {
		debug("EFI: ERROR: out of memory in %s\n", __func__);
		return NULL;
	}

	memset(buf, 0, sz);
	return buf;
}

/*
 * Iterate to next block in device-path, terminating (returning NULL)
 * at /End* node.
 */
struct efi_device_path *efi_dp_next(const struct efi_device_path *dp)
{
	if (dp == NULL)
		return NULL;
	if (dp->type == DEVICE_PATH_TYPE_END)
		return NULL;
	dp = ((void *)dp) + dp->length;
	if (dp->type == DEVICE_PATH_TYPE_END)
		return NULL;
	return (struct efi_device_path *)dp;
}

/*
 * Compare two device-paths, stopping when the shorter of the two hits
 * an End* node. This is useful to, for example, compare a device-path
 * representing a device with one representing a file on the device, or
 * a device with a parent device.
 */
int efi_dp_match(const struct efi_device_path *a,
		 const struct efi_device_path *b)
{
	while (1) {
		int ret;

		ret = memcmp(&a->length, &b->length, sizeof(a->length));
		if (ret)
			return ret;

		ret = memcmp(a, b, a->length);
		if (ret)
			return ret;

		a = efi_dp_next(a);
		b = efi_dp_next(b);

		if (!a || !b)
			return 0;
	}
}

/**
 * efi_dp_shorten() - shorten device-path
 *
 * We can have device paths that start with a USB WWID or a USB Class node,
 * and a few other cases which don't encode the full device path with bus
 * hierarchy:
 *
 * * MESSAGING:USB_WWID
 * * MESSAGING:USB_CLASS
 * * MEDIA:FILE_PATH
 * * MEDIA:HARD_DRIVE
 * * MESSAGING:URI
 *
 * See UEFI spec (section 3.1.2, about short-form device-paths)
 *
 * @dp:		original device-path
 * @Return:	shortened device-path or NULL
 */
struct efi_device_path *efi_dp_shorten(struct efi_device_path *dp)
{
	while (dp) {
		/*
		 * TODO: Add MESSAGING:USB_WWID and MESSAGING:URI..
		 * in practice fallback.efi just uses MEDIA:HARD_DRIVE
		 * so not sure when we would see these other cases.
		 */
		if (EFI_DP_TYPE(dp, MESSAGING_DEVICE, MSG_USB_CLASS) ||
		    EFI_DP_TYPE(dp, MEDIA_DEVICE, HARD_DRIVE_PATH) ||
		    EFI_DP_TYPE(dp, MEDIA_DEVICE, FILE_PATH))
			return dp;

		dp = efi_dp_next(dp);
	}

	return dp;
}

/**
 * find_handle() - find handle by device path and installed protocol
 *
 * If @rem is provided, the handle with the longest partial match is returned.
 *
 * @dp:		device path to search
 * @guid:	GUID of protocol that must be installed on path or NULL
 * @short_path:	use short form device path for matching
 * @rem:	pointer to receive remaining device path
 * Return:	matching handle
 */
static efi_handle_t find_handle(struct efi_device_path *dp,
				const efi_guid_t *guid, bool short_path,
				struct efi_device_path **rem)
{
	efi_handle_t handle, best_handle = NULL;
	efi_uintn_t len, best_len = 0;

	len = efi_dp_instance_size(dp);

	list_for_each_entry(handle, &efi_obj_list, link) {
		struct efi_handler *handler;
		struct efi_device_path *dp_current;
		efi_uintn_t len_current;
		efi_status_t ret;

		if (guid) {
			ret = efi_search_protocol(handle, guid, &handler);
			if (ret != EFI_SUCCESS)
				continue;
		}
		ret = efi_search_protocol(handle, &efi_guid_device_path,
					  &handler);
		if (ret != EFI_SUCCESS)
			continue;
		dp_current = handler->protocol_interface;
		if (short_path) {
			dp_current = efi_dp_shorten(dp_current);
			if (!dp_current)
				continue;
		}
		len_current = efi_dp_instance_size(dp_current);
		if (rem) {
			if (len_current > len)
				continue;
		} else {
			if (len_current != len)
				continue;
		}
		if (memcmp(dp_current, dp, len_current))
			continue;
		if (!rem)
			return handle;

		if (len_current > best_len) {
			best_len = len_current;
			best_handle = handle;
			*rem = (void*)((u8 *)dp + len_current);
		}
	}
	return best_handle;
}

/**
 * efi_dp_find_obj() - find handle by device path
 *
 * If @rem is provided, the handle with the longest partial match is returned.
 *
 * @dp:		device path to search
 * @guid:	GUID of protocol that must be installed on path or NULL
 * @rem:	pointer to receive remaining device path
 * Return:	matching handle
 */
efi_handle_t efi_dp_find_obj(struct efi_device_path *dp,
			     const efi_guid_t *guid,
			     struct efi_device_path **rem)
{
	efi_handle_t handle;

	handle = find_handle(dp, guid, false, rem);
	if (!handle)
		/* Match short form device path */
		handle = find_handle(dp, guid, true, rem);

	return handle;
}

/*
 * Determine the last device path node that is not the end node.
 *
 * @dp		device path
 * Return:	last node before the end node if it exists
 *		otherwise NULL
 */
const struct efi_device_path *efi_dp_last_node(const struct efi_device_path *dp)
{
	struct efi_device_path *ret;

	if (!dp || dp->type == DEVICE_PATH_TYPE_END)
		return NULL;
	while (dp) {
		ret = (struct efi_device_path *)dp;
		dp = efi_dp_next(dp);
	}
	return ret;
}

/* get size of the first device path instance excluding end node */
efi_uintn_t efi_dp_instance_size(const struct efi_device_path *dp)
{
	efi_uintn_t sz = 0;

	if (!dp || dp->type == DEVICE_PATH_TYPE_END)
		return 0;
	while (dp) {
		sz += dp->length;
		dp = efi_dp_next(dp);
	}

	return sz;
}

/* get size of multi-instance device path excluding end node */
efi_uintn_t efi_dp_size(const struct efi_device_path *dp)
{
	const struct efi_device_path *p = dp;

	if (!p)
		return 0;
	while (p->type != DEVICE_PATH_TYPE_END ||
	       p->sub_type != DEVICE_PATH_SUB_TYPE_END)
		p = (void *)p + p->length;

	return (void *)p - (void *)dp;
}

/* copy multi-instance device path */
struct efi_device_path *efi_dp_dup(const struct efi_device_path *dp)
{
	struct efi_device_path *ndp;
	size_t sz = efi_dp_size(dp) + sizeof(END);

	if (!dp)
		return NULL;

	ndp = dp_alloc(sz);
	if (!ndp)
		return NULL;
	memcpy(ndp, dp, sz);

	return ndp;
}

/**
 * efi_dp_append_or_concatenate() - Append or concatenate two device paths.
 *				    Concatenated device path will be separated
 *				    by a sub-type 0xff end node
 *
 * @dp1:	First device path
 * @dp2:	Second device path
 * @concat:	If true the two device paths will be concatenated and separated
 *		by an end of entrire device path sub-type 0xff end node.
 *		If true the second device path will be appended to the first and
 *		terminated by an end node
 *
 * Return:
 * concatenated device path or NULL. Caller must free the returned value
 */
static struct
efi_device_path *efi_dp_append_or_concatenate(const struct efi_device_path *dp1,
					      const struct efi_device_path *dp2,
					      bool concat)
{
	struct efi_device_path *ret;
	size_t end_size = sizeof(END);

	if (concat)
		end_size = 2 * sizeof(END);
	if (!dp1 && !dp2) {
		/* return an end node */
		ret = efi_dp_dup(&END);
	} else if (!dp1) {
		ret = efi_dp_dup(dp2);
	} else if (!dp2) {
		ret = efi_dp_dup(dp1);
	} else {
		/* both dp1 and dp2 are non-null */
		unsigned sz1 = efi_dp_size(dp1);
		unsigned sz2 = efi_dp_size(dp2);
		void *p = dp_alloc(sz1 + sz2 + end_size);
		if (!p)
			return NULL;
		ret = p;
		memcpy(p, dp1, sz1);
		p += sz1;

		if (concat) {
			memcpy(p, &END, sizeof(END));
			p += sizeof(END);
		}

		/* the end node of the second device path has to be retained */
		memcpy(p, dp2, sz2);
		p += sz2;
		memcpy(p, &END, sizeof(END));
	}

	return ret;
}

/**
 * efi_dp_append() - Append a device to an existing device path.
 *
 * @dp1:	First device path
 * @dp2:	Second device path
 *
 * Return:
 * concatenated device path or NULL. Caller must free the returned value
 */
struct efi_device_path *efi_dp_append(const struct efi_device_path *dp1,
				      const struct efi_device_path *dp2)
{
	return efi_dp_append_or_concatenate(dp1, dp2, false);
}

/**
 * efi_dp_concat() - Concatenate 2 device paths. The final device path will
 *                   contain two device paths separated by and end node (0xff).
 *
 * @dp1:	First device path
 * @dp2:	Second device path
 *
 * Return:
 * concatenated device path or NULL. Caller must free the returned value
 */
struct efi_device_path *efi_dp_concat(const struct efi_device_path *dp1,
				      const struct efi_device_path *dp2)
{
	return efi_dp_append_or_concatenate(dp1, dp2, true);
}

struct efi_device_path *efi_dp_append_node(const struct efi_device_path *dp,
					   const struct efi_device_path *node)
{
	struct efi_device_path *ret;

	if (!node && !dp) {
		ret = efi_dp_dup(&END);
	} else if (!node) {
		ret = efi_dp_dup(dp);
	} else if (!dp) {
		size_t sz = node->length;
		void *p = dp_alloc(sz + sizeof(END));
		if (!p)
			return NULL;
		memcpy(p, node, sz);
		memcpy(p + sz, &END, sizeof(END));
		ret = p;
	} else {
		/* both dp and node are non-null */
		size_t sz = efi_dp_size(dp);
		void *p = dp_alloc(sz + node->length + sizeof(END));
		if (!p)
			return NULL;
		memcpy(p, dp, sz);
		memcpy(p + sz, node, node->length);
		memcpy(p + sz + node->length, &END, sizeof(END));
		ret = p;
	}

	return ret;
}

struct efi_device_path *efi_dp_create_device_node(const u8 type,
						  const u8 sub_type,
						  const u16 length)
{
	struct efi_device_path *ret;

	if (length < sizeof(struct efi_device_path))
		return NULL;

	ret = dp_alloc(length);
	if (!ret)
		return ret;
	ret->type = type;
	ret->sub_type = sub_type;
	ret->length = length;
	return ret;
}

struct efi_device_path *efi_dp_append_instance(
		const struct efi_device_path *dp,
		const struct efi_device_path *dpi)
{
	size_t sz, szi;
	struct efi_device_path *p, *ret;

	if (!dpi)
		return NULL;
	if (!dp)
		return efi_dp_dup(dpi);
	sz = efi_dp_size(dp);
	szi = efi_dp_instance_size(dpi);
	p = dp_alloc(sz + szi + 2 * sizeof(END));
	if (!p)
		return NULL;
	ret = p;
	memcpy(p, dp, sz + sizeof(END));
	p = (void *)p + sz;
	p->sub_type = DEVICE_PATH_SUB_TYPE_INSTANCE_END;
	p = (void *)p + sizeof(END);
	memcpy(p, dpi, szi);
	p = (void *)p + szi;
	memcpy(p, &END, sizeof(END));
	return ret;
}

struct efi_device_path *efi_dp_get_next_instance(struct efi_device_path **dp,
						 efi_uintn_t *size)
{
	size_t sz;
	struct efi_device_path *p;

	if (size)
		*size = 0;
	if (!dp || !*dp)
		return NULL;
	sz = efi_dp_instance_size(*dp);
	p = dp_alloc(sz + sizeof(END));
	if (!p)
		return NULL;
	memcpy(p, *dp, sz + sizeof(END));
	*dp = (void *)*dp + sz;
	if ((*dp)->sub_type == DEVICE_PATH_SUB_TYPE_INSTANCE_END)
		*dp = (void *)*dp + sizeof(END);
	else
		*dp = NULL;
	if (size)
		*size = sz + sizeof(END);
	return p;
}

bool efi_dp_is_multi_instance(const struct efi_device_path *dp)
{
	const struct efi_device_path *p = dp;

	if (!p)
		return false;
	while (p->type != DEVICE_PATH_TYPE_END)
		p = (void *)p + p->length;
	return p->sub_type == DEVICE_PATH_SUB_TYPE_INSTANCE_END;
}

/* size of device-path not including END node for device and all parents
 * up to the root device.
 */
static unsigned int dp_size(block_dev_desc_t *desc)
{
	switch (desc->if_type) {
	case IF_TYPE_SATA:
		return sizeof(ROOT) +
			sizeof(struct efi_device_path_atapi);
	case IF_TYPE_NVME:
		return sizeof(ROOT) +
			sizeof(struct efi_device_path_nvme);
	case IF_TYPE_USB:
		return sizeof(ROOT) +
			sizeof(struct efi_device_path_usb_class);
	default:
		/* just skip over unknown classes: */
		return sizeof(ROOT);
	}
}

/*
 * Recursively build a device path.
 *
 * @buf		pointer to the end of the device path
 * @dev		device
 * Return:	pointer to the end of the device path
 */
static void *dp_fill(block_dev_desc_t *desc, void *buf)
{
	switch (desc->if_type) {
	case IF_TYPE_SATA: {
		struct efi_device_path_sata *dp;
		struct efi_device_path_vendor *vdp = buf;

		*vdp = ROOT;
		dp = &vdp[1];
		dp->dp.type     = DEVICE_PATH_TYPE_MESSAGING_DEVICE;
		dp->dp.sub_type = DEVICE_PATH_SUB_TYPE_MSG_SATA;
		dp->dp.length   = sizeof(*dp);
		dp->hba_port = desc->dev;
		/* default 0xffff implies no port multiplier */
		dp->port_multiplier_port = 0xffff;
		dp->logical_unit_number = desc->lun;
		return &dp[1];
		}
	case IF_TYPE_NVME: {
		u32 ns_id;
		struct efi_device_path_nvme *dp;
		struct efi_device_path_vendor *vdp = buf;

		*vdp = ROOT;
		dp = &vdp[1];
		dp->dp.type     = DEVICE_PATH_TYPE_MESSAGING_DEVICE;
		dp->dp.sub_type = DEVICE_PATH_SUB_TYPE_MSG_NVME;
		dp->dp.length = sizeof(*dp);
		nvme_get_namespaces(&ns_id, dp->eui64);
		memcpy(&dp->ns_id, &ns_id, sizeof(ns_id));
		return &dp[1];
					   }
	case IF_TYPE_USB: {
		struct efi_device_path_usb_class *udp;
		struct efi_device_path_vendor *vdp = buf;
		struct usb_device *dev;

		dev = usb_get_dev_index(0);
		*vdp = ROOT;
		udp = &vdp[1];
		udp->dp.type     = DEVICE_PATH_TYPE_MESSAGING_DEVICE;
		udp->dp.sub_type = DEVICE_PATH_SUB_TYPE_MSG_USB_CLASS;
		udp->dp.length   = sizeof(*udp);
		udp->vendor_id   = dev->descriptor.idVendor;
		udp->product_id  = dev->descriptor.idProduct;
		udp->device_class    = dev->descriptor.bDeviceClass;
		udp->device_subclass = dev->descriptor.bDeviceSubClass;
		udp->device_protocol = dev->descriptor.bDeviceProtocol;

		return &udp[1];
	default:
		/* just skip over unknown classes: */
		return buf;
		}
	}
}

static unsigned dp_part_size(block_dev_desc_t *desc, int part)
{
	unsigned dpsize;

	dpsize = dp_size(desc);

	if (part == 0) /* the actual disk, not a partition */
		return dpsize;

	if (desc->part_type == PART_TYPE_ISO)
		dpsize += sizeof(struct efi_device_path_cdrom_path);
	else
		dpsize += sizeof(struct efi_device_path_hard_drive_path);

	return dpsize;
}

/*
 * Create a device node for a block device partition.
 *
 * @buf		buffer to which the device path is written
 * @desc	block device descriptor
 * @part	partition number, 0 identifies a block device
 */
static void *dp_part_node(void *buf, block_dev_desc_t *desc, int part)
{
	struct disk_partition *info;

	info = get_part_info(part, desc->if_type);
	if (!info){
		printf("DevicePath - Get device part info failed!\n");
		return -1;
	}

	if (desc->part_type == PART_TYPE_ISO) {
		struct efi_device_path_cdrom_path *cddp = buf;

		cddp->boot_entry = part;
		cddp->dp.type = DEVICE_PATH_TYPE_MEDIA_DEVICE;
		cddp->dp.sub_type = DEVICE_PATH_SUB_TYPE_CDROM_PATH;
		cddp->dp.length = sizeof(*cddp);
		cddp->partition_start = info->start;
		cddp->partition_size = info->size;

		buf = &cddp[1];
	} else {
		struct efi_device_path_hard_drive_path *hddp = buf;

		hddp->dp.type = DEVICE_PATH_TYPE_MEDIA_DEVICE;
		hddp->dp.sub_type = DEVICE_PATH_SUB_TYPE_HARD_DRIVE_PATH;
		hddp->dp.length = sizeof(*hddp);
		hddp->partition_number = part + 1;
		hddp->partition_start = info->start;
		hddp->partition_end = info->size;
		hddp->partmap_type = 2;

		buf = &hddp[1];
	}

	return buf;
}

/*
 * Create a device path for a block device or one of its partitions.
 *
 * @buf		buffer to which the device path is written
 * @desc	block device descriptor
 * @part	partition number, 0 identifies a block device
 */
static void *dp_part_fill(void *buf, block_dev_desc_t *desc, int part)
{
	buf = dp_fill(desc, buf);

	if (part == 0) /* the actual disk, not a partition */
		return buf;

	return dp_part_node(buf, desc, part);
}

/* Construct a device-path from a partition on a block device: */
struct efi_device_path *efi_dp_from_part(block_dev_desc_t *desc, int part)
{
	void *buf, *start;

	start = buf = dp_alloc(dp_part_size(desc, part) + sizeof(END));
	if (!buf)
		return NULL;

	buf = dp_part_fill(buf, desc, part);

	*((struct efi_device_path *)buf) = END;

	return start;
}

/*
 * Create a device node for a block device partition.
 *
 * @buf		buffer to which the device path is written
 * @desc	block device descriptor
 * @part	partition number, 0 identifies a block device
 */
struct efi_device_path *efi_dp_part_node(block_dev_desc_t *desc, int part)
{
	efi_uintn_t dpsize;
	void *buf;

	if (desc->part_type == PART_TYPE_ISO)
		dpsize = sizeof(struct efi_device_path_cdrom_path);
	else
		dpsize = sizeof(struct efi_device_path_hard_drive_path);
	buf = dp_alloc(dpsize);

	dp_part_node(buf, desc, part);

	return buf;
}

/**
 * path_to_uefi() - convert UTF-8 path to an UEFI style path
 *
 * Convert UTF-8 path to a UEFI style path (i.e. with backslashes as path
 * separators and UTF-16).
 *
 * @src:	source buffer
 * @uefi:	target buffer, possibly unaligned
 */
static void path_to_uefi(void *uefi, const char *src)
{
	u16 *pos = uefi;

	while (*src) {
		s32 code = utf8_get(&src);

		if (code < 0)
			code = '?';
		else if (code == '/')
			code = '\\';
		utf16_put(code, &pos);
	}
	*pos = 0;
}

/**
 * efi_dp_from_file() - create device path for file
 *
 * The function creates a device path from the block descriptor @desc and the
 * partition number @part and appends a device path node created describing the
 * file path @path.
 *
 * If @desc is NULL, the device path will not contain nodes describing the
 * partition.
 * If @path is an empty string "", the device path will not contain a node
 * for the file path.
 *
 * @desc:	block device descriptor or NULL
 * @part:	partition number
 * @path:	file path on partition or ""
 * Return:	device path or NULL in case of an error
 */
struct efi_device_path *efi_dp_from_file(block_dev_desc_t *desc, int part,
		const char *path)
{
	struct efi_device_path_file_path *fp;
	void *buf, *start;
	size_t dpsize = 0, fpsize;

	if (desc)
		dpsize = dp_part_size(desc, part);

	fpsize = sizeof(struct efi_device_path) +
		 2 * (utf8_utf16_strlen(path) + 1);
	if (fpsize > U16_MAX)
		return NULL;

	dpsize += fpsize;

	start = buf = dp_alloc(dpsize + sizeof(END));
	if (!buf)
		return NULL;

	if (desc)
		buf = dp_part_fill(buf, desc, part);

	/* add file-path: */
	if (*path) {
		fp = buf;
		fp->dp.type = DEVICE_PATH_TYPE_MEDIA_DEVICE;
		fp->dp.sub_type = DEVICE_PATH_SUB_TYPE_FILE_PATH;
		fp->dp.length = (u16)fpsize;
		path_to_uefi(fp->str, path);
		buf += fpsize;
	}

	*((struct efi_device_path *)buf) = END;

	return start;
}

struct efi_device_path *efi_dp_from_uart(void)
{
	void *buf, *pos;
	struct efi_device_path_uart *uart;
	size_t dpsize = sizeof(ROOT) + sizeof(*uart) + sizeof(END);

	buf = dp_alloc(dpsize);
	if (!buf)
		return NULL;
	pos = buf;
	memcpy(pos, &ROOT, sizeof(ROOT));
	pos += sizeof(ROOT);
	uart = pos;
	uart->dp.type = DEVICE_PATH_TYPE_MESSAGING_DEVICE;
	uart->dp.sub_type = DEVICE_PATH_SUB_TYPE_MSG_UART;
	uart->dp.length = sizeof(*uart);
	pos += sizeof(*uart);
	memcpy(pos, &END, sizeof(END));

	return buf;
}

/* Construct a device-path for memory-mapped image */
struct efi_device_path *efi_dp_from_mem(uint32_t memory_type,
					uint64_t start_address,
					uint64_t end_address)
{
	struct efi_device_path_memory *mdp;
	void *buf, *start;

	start = buf = dp_alloc(sizeof(*mdp) + sizeof(END));
	if (!buf)
		return NULL;

	mdp = buf;
	mdp->dp.type = DEVICE_PATH_TYPE_HARDWARE_DEVICE;
	mdp->dp.sub_type = DEVICE_PATH_SUB_TYPE_MEMORY;
	mdp->dp.length = sizeof(*mdp);
	mdp->memory_type = memory_type;
	mdp->start_address = start_address;
	mdp->end_address = end_address;
	buf = &mdp[1];

	*((struct efi_device_path *)buf) = END;

	return start;
}

/**
 * efi_dp_split_file_path() - split of relative file path from device path
 *
 * Given a device path indicating a file on a device, separate the device
 * path in two: the device path of the actual device and the file path
 * relative to this device.
 *
 * @full_path:		device path including device and file path
 * @device_path:	path of the device
 * @file_path:		relative path of the file or NULL if there is none
 * Return:		status code
 */
efi_status_t efi_dp_split_file_path(struct efi_device_path *full_path,
				    struct efi_device_path **device_path,
				    struct efi_device_path **file_path)
{
	struct efi_device_path *p, *dp, *fp = NULL;

	*device_path = NULL;
	*file_path = NULL;
	dp = efi_dp_dup(full_path);
	if (!dp)
		return EFI_OUT_OF_RESOURCES;
	p = dp;
	while (!EFI_DP_TYPE(p, MEDIA_DEVICE, FILE_PATH)) {
		p = efi_dp_next(p);
		if (!p)
			goto out;
	}
	fp = efi_dp_dup(p);
	if (!fp)
		return EFI_OUT_OF_RESOURCES;
	p->type = DEVICE_PATH_TYPE_END;
	p->sub_type = DEVICE_PATH_SUB_TYPE_END;
	p->length = sizeof(*p);

out:
	*device_path = dp;
	*file_path = fp;
	return EFI_SUCCESS;
}

/**
 * efi_dp_check_length() - check length of a device path
 *
 * @dp:		pointer to device path
 * @maxlen:	maximum length of the device path
 * Return:
 * * length of the device path if it is less or equal @maxlen
 * * -1 if the device path is longer then @maxlen
 * * -1 if a device path node has a length of less than 4
 * * -EINVAL if maxlen exceeds SSIZE_MAX
 */
ssize_t efi_dp_check_length(const struct efi_device_path *dp,
			    const size_t maxlen)
{
	ssize_t ret = 0;
	u16 len;

	if (maxlen > SSIZE_MAX)
		return -EINVAL;
	for (;;) {
		len = dp->length;
		if (len < 4)
			return -1;
		ret += len;
		if (ret > maxlen)
			return -1;
		if (dp->type == DEVICE_PATH_TYPE_END &&
		    dp->sub_type == DEVICE_PATH_SUB_TYPE_END)
			return ret;
		dp = (const struct efi_device_path *)((const u8 *)dp + len);
	}
}

/**
 * efi_dp_from_lo() - Get the instance of a VenMedia node in a
 *                    multi-instance device path that matches
 *                    a specific GUID. This kind of device paths
 *                    is found in Boot#### options describing an
 *                    initrd location
 *
 * @lo:		EFI_LOAD_OPTION containing a valid device path
 * @guid:	guid to search for
 *
 * Return:
 * device path including the VenMedia node or NULL.
 * Caller must free the returned value.
 */
struct
efi_device_path *efi_dp_from_lo(struct efi_load_option *lo,
				const efi_guid_t *guid)
{
	struct efi_device_path *fp = lo->file_path;
	struct efi_device_path_vendor *vendor;
	int lo_len = lo->file_path_length;

	for (; lo_len >=  sizeof(struct efi_device_path);
	     lo_len -= fp->length, fp = (void *)fp + fp->length) {
		if (lo_len < 0 || efi_dp_check_length(fp, lo_len) < 0)
			break;
		if (fp->type != DEVICE_PATH_TYPE_MEDIA_DEVICE ||
		    fp->sub_type != DEVICE_PATH_SUB_TYPE_VENDOR_PATH)
			continue;

		vendor = (struct efi_device_path_vendor *)fp;
		if (!guidcmp(&vendor->guid, guid))
			return efi_dp_dup(efi_dp_next(fp));
	}
	log_debug("VenMedia(%pUl) not found in %ls\n", &guid, lo->label);

	return NULL;
}

/**
 * search_gpt_dp_node() - search gpt device path node
 *
 * @device_path:	device path
 *
 * Return:	pointer to the gpt device path node
 */
struct efi_device_path *search_gpt_dp_node(struct efi_device_path *device_path)
{
	struct efi_device_path *dp = device_path;

	while (dp) {
		if (dp->type == DEVICE_PATH_TYPE_MEDIA_DEVICE &&
		    dp->sub_type == DEVICE_PATH_SUB_TYPE_HARD_DRIVE_PATH) {
			struct efi_device_path_hard_drive_path *hd_dp =
				(struct efi_device_path_hard_drive_path *)dp;

			if (hd_dp->partmap_type == PART_FORMAT_GPT &&
			    hd_dp->signature_type == SIG_TYPE_GUID)
				return dp;
		}
		dp = efi_dp_next(dp);
	}

	return NULL;
}

/**
 * efi_dp_from_name() - convert PMON device and file path to device path
 *
 * @path:	file path relative to PMON device
 * @device:	pointer to receive device path of the device
 *			eg: /dev/fs/ext3@wd0b/vmlinuz
 *
 * @file:	pointer to receive device path for the file
 * Return:	status code
 */
efi_status_t efi_dp_from_name(const char *path,
		struct efi_device_path **device,
		struct efi_device_path **file)
{
	char *tmp_str;
	unsigned int cur_part = 0;
	char *s;
	char *name_str, *filename;
	char dev_name[0x10];
	DeviceDisk *dev;
	block_dev_desc_t *desc;

	if (!path)
		return EFI_INVALID_PARAMETER;

	tmp_str = strstr(path, "usb");
	if (tmp_str && (efi_disk_type & EFI_DISK_USB)) {
		sprintf(dev_name, "usb%c", *(tmp_str + 3));
		dev = FindDevice(dev_name);
		if (dev == NULL) {
			printf("no usb device\n");
			return EFI_NOT_READY;
		}
		desc = usb_stor_get_dev(0);
		name_str = tmp_str + 6;
		if (dev->dev_fscount > 0)
			cur_part = *(tmp_str + 4) - 'a' + 1;
	}

	tmp_str = NULL;
	tmp_str = strstr(path, "nvme");
	if (tmp_str && (efi_disk_type & EFI_DISK_NVME)) {
		sprintf(dev_name, "nvme%c", *(tmp_str + 4));
		dev = FindDevice(dev_name);
		if (dev == NULL) {
			printf("no nvme device\n");
			return EFI_NOT_READY;
		}
		desc = get_nvme_desc();
		name_str = tmp_str + 7;
		if (dev->dev_fscount > 0)
			cur_part = *(tmp_str + 5) - 'a' + 1;
	}

	tmp_str = NULL;
	tmp_str = strstr(path, "wd");
	if (tmp_str && (efi_disk_type & EFI_DISK_SATA)) {
		sprintf(dev_name, "wd%c", *(tmp_str + 2));
		dev = FindDevice(dev_name);
		if (dev == NULL) {
			printf("no wd device\n");
			return EFI_NOT_READY;
		}
		desc = sata_dev_desc[curr_port];
		name_str = tmp_str + 5;
		if (dev->dev_fscount > 0)
			cur_part = *(tmp_str + 3) - 'a' + 1;
	}

	if (device)
		*device = efi_dp_from_part(desc, cur_part);

	filename = calloc(1, strlen(name_str) + 1);
	if (!filename)
		return EFI_OUT_OF_RESOURCES;

	sprintf(filename, "%s", name_str);
	/* DOS style file path: */
	s = filename;
	while ((s = strchr(s, '/')))
		*s++ = '\\';
	*file = efi_dp_from_file(desc, cur_part, filename);
	free(filename);

	if (!*file)
		return EFI_INVALID_PARAMETER;

	return EFI_SUCCESS;
}
