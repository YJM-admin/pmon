// SPDX-License-Identifier: GPL-2.0+
/*
 * EFI Firmware management protocol
 *
 *  Copyright (c) 2020 Linaro Limited
 *			Author: AKASHI Takahiro
 */

#include <pflash.h>
#include <charset.h>
#include <efi_loader.h>
#include <kconfig.h>
#include <signatures.h>
#include <efi_fw_vol.h>

#define FMP_PAYLOAD_HDR_SIGNATURE	SIGNATURE_32('M', 'S', 'S', '1')
#define EFI_FVH_SIGNATURE SIGNATURE_32 ('_', 'F', 'V', 'H')

extern struct fl_map *tgt_flashmap();
const efi_guid_t mEdkii_firmware_file_guid = EFI_SYSTEM_FIRMWARE_FILE_GUID;

/**
 * struct fmp_payload_header - EDK2 header for the FMP payload
 *
 * This structure describes the header which is preprended to the
 * FMP payload by the edk2 capsule generation scripts.
 *
 * @signature:			Header signature used to identify the header
 * @header_size:		Size of the structure
 * @fw_version:			Firmware versions used
 * @lowest_supported_version:	Lowest supported version
 */
struct fmp_payload_header {
	u32 signature;
	u32 header_size;
	u32 fw_version;
	u32 lowest_supported_version;
};

void set_dfu_alt_info(char *interface, char *devstr)
{
//	env_set("dfu_alt_info", update_info.dfu_string);
}

/* Place holder; not supported */
static
efi_status_t efi_firmware_get_image_unsupported(
	struct efi_firmware_management_protocol *this,
	u8 image_index,
	void *image,
	efi_uintn_t *image_size)
{
	EFI_ENTRY("%p %d %p %p\n", this, image_index, image, image_size);

	return EFI_EXIT(EFI_UNSUPPORTED);
}

/* Place holder; not supported */
static
efi_status_t efi_firmware_check_image_unsupported(
	struct efi_firmware_management_protocol *this,
	u8 image_index,
	const void *image,
	efi_uintn_t *image_size,
	u32 *image_updatable)
{
	EFI_ENTRY("%p %d %p %p %p\n", this, image_index, image, image_size,
		  image_updatable);

	return EFI_EXIT(EFI_UNSUPPORTED);
}

/* Place holder; not supported */
static
efi_status_t efi_firmware_get_package_info_unsupported(
	struct efi_firmware_management_protocol *this,
	u32 *package_version,
	u16 **package_version_name,
	u32 *package_version_name_maxlen,
	u64 *attributes_supported,
	u64 *attributes_setting)
{
	EFI_ENTRY("%p %p %p %p %p %p\n", this, package_version,
		  package_version_name, package_version_name_maxlen,
		  attributes_supported, attributes_setting);

	return EFI_EXIT(EFI_UNSUPPORTED);
}

/* Place holder; not supported */
static
efi_status_t efi_firmware_set_package_info_unsupported(
	struct efi_firmware_management_protocol *this,
	const void *image,
	efi_uintn_t *image_size,
	const void *vendor_code,
	u32 package_version,
	const u16 *package_version_name)
{
	EFI_ENTRY("%p %p %p %p %x %p\n", this, image, image_size, vendor_code,
		  package_version, package_version_name);

	return EFI_EXIT(EFI_UNSUPPORTED);
}

/**
  Check if a block of buffer is erased.

  @param[in] erase_polarity  Erase polarity attribute of the firmware volume
  @param[in] inbuffer       The buffer to be checked
  @param[in] buffer_size     Size of the buffer in bytes

  @retval    TRUE           The block of buffer is erased
  @retval    FALSE          The block of buffer is not erased
**/
char is_buffer_erased(char erase_polarity, void *inbuffer, unsigned int buffer_size)
{
	unsigned int count;
	char erase_byte;
	char *buffer;

	if(erase_polarity == 1) {
		erase_byte = 0xFF;
	} else {
		erase_byte = 0;
	}

	buffer = inbuffer;
	for (count = 0; count < buffer_size; count++) {
		if (buffer[count] != erase_byte) {
			return false;
		}
	}

	return true;
}

/**
  Get FFS buffer pointer by file_name GUID and FileType.

  @param[in]   fd_start          The System Firmware FD image
  @param[in]   fd_size           The size of System Firmware FD image
  @param[in]   file_name         The FileName GUID of FFS to be found
  @param[in]   type             The FileType of FFS to be found
  @param[out]  binary_buffer     The FFS buffer found, including FFS_FILE_HEADER
  @param[out]  binary_buffer_size The size of FFS buffer found, including FFS_FILE_HEADER

  @retval true  The FFS buffer is found.
  @retval false The FFS buffer is not found.
**/
char get_ffs_file(void *fd_start, unsigned int fd_size, efi_guid_t *file_name, char type,
					void **binary_buffer, unsigned int *binary_buffer_size)
{
	unsigned int fv_size;
	EFI_FIRMWARE_VOLUME_HEADER                *fv_header;
	EFI_FIRMWARE_VOLUME_EXT_HEADER            *fv_ext_header;
	EFI_FFS_FILE_HEADER                       *ffs_header;
	unsigned int                              ffs_size;
	unsigned int                              test_len;
	char										found;

	EFI_PRINT("GetFfsByName - FV: 0x%lx - 0x%lx\n", (unsigned long)fd_start, (unsigned long)fd_size);

	found = false;
	fv_header = (EFI_FIRMWARE_VOLUME_HEADER *)fd_start;
	while ((unsigned long)fv_header < (unsigned long)fd_start + fd_size - 1) {
		fv_size = (unsigned long)fd_start + fd_size - (unsigned long)fv_header;

		if (fv_header->Signature != EFI_FVH_SIGNATURE) {
			fv_header = (EFI_FIRMWARE_VOLUME_HEADER *)((unsigned long)fv_header + SIZE_4KB);
			continue;
		}
		EFI_PRINT("checking FV....0x%lx - 0x%x\n", fv_header, fv_header->FvLength);
		found = true;
		if (fv_header->FvLength > fv_size) {
			EFI_PRINT("GetFfsByName - fv_size: 0x%lx, MaxSize - 0x%x\n", (unsigned long)fv_header->FvLength, (unsigned long)fv_size);
			return false;
		}
		fv_size = (unsigned long)fv_header->FvLength;
		if (fv_header->ExtHeaderOffset != 0) {
			fv_ext_header = (EFI_FIRMWARE_VOLUME_EXT_HEADER *)((char *)fv_header + fv_header->ExtHeaderOffset);
			ffs_header = (EFI_FFS_FILE_HEADER *)((char *)fv_ext_header + fv_ext_header->ExtHeaderSize);
		} else {
			ffs_header = (EFI_FFS_FILE_HEADER *)((char *)fv_header + fv_header->HeaderLength);
		}
		ffs_header = (EFI_FFS_FILE_HEADER *)((unsigned long)fv_header + ALIGN_VALUE((unsigned long)ffs_header - (unsigned long)fv_header, 8));

		while ((unsigned long)ffs_header < (unsigned long)fv_header + fv_size - 1) {
			EFI_PRINT("GetFfsByName - FFS: 0x%lx\n", ffs_header);
			test_len = (unsigned long)((unsigned long)fv_header + fv_size - (unsigned long)ffs_header);
			if (test_len > sizeof(EFI_FFS_FILE_HEADER)) {
				test_len = sizeof(EFI_FFS_FILE_HEADER);
			}
			if (is_buffer_erased(1, ffs_header, test_len)) {
				break;
			}

			if (IS_FFS_FILE2(ffs_header)) {
				ffs_size = FFS_FILE2_SIZE(ffs_header);
			} else {
				ffs_size = FFS_FILE_SIZE(ffs_header);
			}

			if (!guidcmp(file_name, &ffs_header->Name) &&
					((type == EFI_FV_FILETYPE_ALL) || (ffs_header->Type == type))) {
				*binary_buffer = ffs_header;
				*binary_buffer_size = ffs_size;
				return true;
			} else {
				EFI_PRINT("GetFfsByName - other FFS type 0x%x, name %g\n", ffs_header->Type, &ffs_header->Name);
			}
			ffs_header = (EFI_FFS_FILE_HEADER *)((unsigned long)ffs_header + ALIGN_VALUE(ffs_size, 8));
		}
		fv_header = (void *)(unsigned long)((unsigned long)fv_header + fv_header->FvLength);
		EFI_PRINT("Next FV....0x%lx - 0x%x\n", fv_header, fv_header->FvLength);
	}

	if (!found) {
		printf("GetFfsByName - NO FV Found\n");
	}
	return false;
}

/**
  Extract the System Firmware image from an authenticated image.

  @param[in]  auth_image      The authenticated capsule image.
  @param[in]  auth_image_size  The size of the authenticated capsule image in bytes.
  @param[out] fw_image     The System Firmware image.
  @param[out] fw_image_size The size of the System Firmware image in bytes.

  @retval true  The System Firmware image is extracted.
  @retval false The System Firmware image is not extracted.
**/
char extract_fw_binary(void *auth_image, unsigned int auth_image_size,
		void **fw_image, unsigned int *fw_image_size)
{
  char result;
  unsigned int file_head_size;

  *fw_image = NULL;
  *fw_image_size = 0;

  result = get_ffs_file(auth_image, auth_image_size, &mEdkii_firmware_file_guid, 0x1, fw_image, fw_image_size);
  if (!result) {
    // no nested FV, just return all data.
    *fw_image = auth_image;
    *fw_image_size = auth_image_size;

    return true;
  }
  if (IS_FFS_FILE2 (*fw_image)) {
    file_head_size = sizeof(EFI_FFS_FILE_HEADER2);
  } else {
    file_head_size = sizeof(EFI_FFS_FILE_HEADER);
  }
  *fw_image = (char *)*fw_image + file_head_size;
  *fw_image_size = *fw_image_size - file_head_size;

  return result;
}

/**
 * efi_firmware_capsule_authenticate - authenticate the capsule if enabled
 * @p_image:		Pointer to new image
 * @p_image_size:	Pointer to size of new image
 *
 * Authenticate the capsule if authentication is enabled.
 * The image pointer and the image size are updated in case of success.
 *
 * Return:		status code
 */
static efi_status_t efi_firmware_capsule_authenticate(const void **p_image,
					       efi_uintn_t *p_image_size)
{
	const void *image = *p_image;
	efi_uintn_t image_size = *p_image_size;
	u32 fmp_hdr_signature;
	struct fmp_payload_header *header;
	void *capsule_payload;
	efi_status_t status;
	efi_uintn_t capsule_payload_size;

	if (IS_ENABLED(CONFIG_EFI_CAPSULE_AUTHENTICATE)) {
		capsule_payload = NULL;
		capsule_payload_size = 0;
		status = efi_capsule_authenticate(image, image_size,
						  &capsule_payload,
						  &capsule_payload_size);

		if (status == EFI_SECURITY_VIOLATION) {
			printf("Capsule authentication check failed. Aborting update\n");
			return status;
		} else if (status != EFI_SUCCESS) {
			return status;
		}

		debug("Capsule authentication successful\n");
		image = capsule_payload;
		image_size = capsule_payload_size;
	} else {
		debug("Capsule authentication disabled. ");
		debug("Updating capsule without authenticating.\n");
	}

	status = extract_fw_binary(image, image_size, &capsule_payload, &capsule_payload_size);
	if (status) {
		image = capsule_payload;
		image_size = capsule_payload_size;
	}

	fmp_hdr_signature = FMP_PAYLOAD_HDR_SIGNATURE;
	header = (void *)image;

	if (!memcmp(&header->signature, &fmp_hdr_signature,
		    sizeof(fmp_hdr_signature))) {
		/*
		 * When building the capsule with the scripts in
		 * edk2, a FMP header is inserted above the capsule
		 * payload. Compensate for this header to get the
		 * actual payload that is to be updated.
		 */
		image += header->header_size;
		image_size -= header->header_size;
	}

	*p_image = image;
	*p_image_size = image_size;
	return EFI_SUCCESS;
}

/**
 * efi_firmware_get_image_info - return information about the current
 *				     firmware image
 * @this:			Protocol instance
 * @image_info_size:		Size of @image_info
 * @image_info:			Image information
 * @descriptor_version:		Pointer to version number
 * @descriptor_count:		Pointer to number of descriptors
 * @descriptor_size:		Pointer to descriptor size
 * @package_version:		Package version
 * @package_version_name:	Package version's name
 *
 * Return information bout the current firmware image in @image_info.
 * @image_info will consist of a number of descriptors.
 * Each descriptor will be created based on "dfu_alt_info" variable.
 *
 * Return		status code
 */
static
efi_status_t efi_firmware_get_image_info(
	struct efi_firmware_management_protocol *this,
	efi_uintn_t *image_info_size,
	struct efi_firmware_image_descriptor *image_info,
	u32 *descriptor_version,
	u8 *descriptor_count,
	efi_uintn_t *descriptor_size,
	u32 *package_version,
	u16 **package_version_name)
{
	efi_status_t ret = EFI_SUCCESS;

	EFI_ENTRY("%p %p %p %p %p %p %p %p\n", this,
		  image_info_size, image_info,
		  descriptor_version, descriptor_count, descriptor_size,
		  package_version, package_version_name);

	if (!image_info_size)
		return EFI_EXIT(EFI_INVALID_PARAMETER);

	if (*image_info_size &&
	    (!image_info || !descriptor_version || !descriptor_count ||
	     !descriptor_size || !package_version || !package_version_name))
		return EFI_EXIT(EFI_INVALID_PARAMETER);

	return EFI_EXIT(ret);
}

/*
 * This FIRMWARE_MANAGEMENT_PROTOCOL driver provides a firmware update
 * method with raw data.
 */

/**
 * efi_firmware_raw_set_image - update the firmware image
 * @this:		Protocol instance
 * @image_index:	Image index number
 * @image:		New image
 * @image_size:		Size of new image
 * @vendor_code:	Vendor-specific update policy
 * @progress:		Function to report the progress of update
 * @abort_reason:	Pointer to string of abort reason
 *
 * Update the firmware to new image, using dfu. The new image should
 * be a single raw image.
 * @vendor_code, @progress and @abort_reason are not supported.
 *
 * Return:		status code
 */
static
efi_status_t efi_firmware_raw_set_image(
	struct efi_firmware_management_protocol *this,
	u8 image_index,
	const void *image,
	efi_uintn_t image_size,
	const void *vendor_code,
	efi_status_t (*progress)(efi_uintn_t completion),
	u16 **abort_reason)
{
	efi_status_t status;
	char *boot_rom_base;

	EFI_ENTRY("%p %d %p %zu %p %p %p\n", this, image_index, image,
		  image_size, vendor_code, progress, abort_reason);

	if (!image)
		return EFI_EXIT(EFI_INVALID_PARAMETER);

	status = efi_firmware_capsule_authenticate(&image, &image_size);
	if (status != EFI_SUCCESS)
		return EFI_EXIT(status);

	boot_rom_base = (char *)(tgt_flashmap()->fl_map_base);

	printf("program flash: %lx update firmware, image_addr: %lx image_size: %lx, please wait a few minute...\n", boot_rom_base, image, image_size);

	efi_flash_program((void *)boot_rom_base, image_size, (void *)image, 0);

	return EFI_EXIT(EFI_SUCCESS);
}

const struct efi_firmware_management_protocol efi_fmp_raw = {
	.get_image_info = efi_firmware_get_image_info,
	.get_image = efi_firmware_get_image_unsupported,
	.set_image = efi_firmware_raw_set_image,
	.check_image = efi_firmware_check_image_unsupported,
	.get_package_info = efi_firmware_get_package_info_unsupported,
	.set_package_info = efi_firmware_set_package_info_unsupported,
};
