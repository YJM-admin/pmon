// SPDX-License-Identifier: GPL-2.0+
/*
 *  EFI application runtime services
 *
 *  Copyright (c) 2016 Alexander Graf
 */

#include <time.h>
#include <pmon.h>
#include <efi_api.h>
#include <efi_loader.h>
#include "efi_memory.h"

/* GUID of the runtime properties table */
static const efi_guid_t efi_rt_properties_table_guid = EFI_RT_PROPERTIES_TABLE_GUID;
static const efi_guid_t efi_caller_id_guid = EFI_RT_PROPERTIES_TABLE_GUID;
extern const efi_guid_t gEfiCapsuleVendorGuid;

struct efi_runtime_mmio_list {
	struct list_head link;
	void **ptr;
	u64 paddr;
	u64 len;
};

/* This list contains all runtime available mmio regions */
LIST_HEAD1(efi_runtime_mmio);

static efi_status_t efi_unimplemented(void);

/*
 * toDO(sjg@chromium.org): These defines and structures should come from the ELF
 * header for each architecture (or a generic header) rather than being repeated
 * here.
 */
#define R_RELATIVE	1027
#define R_MASK		0xffffffffULL
#define IS_RELA		1
#define inl(a) (*(volatile unsigned int*)(a))
#define outl(a,v) (*(volatile unsigned int*)(a) = (v))


struct dyn_sym {
	ulong foo1;
	ulong addr;
	u32 foo2;
	u32 foo3;
};

struct elf_rel {
	ulong *offset;
	ulong info;
};

struct elf_rela {
	ulong *offset;
	ulong info;
	long addend;
};

static struct efi_mem_desc *efi_virtmap;
static efi_uintn_t efi_descriptor_count;
static efi_uintn_t efi_descriptor_size;

/*
 * EFI runtime code lives in two stages. In the first stage, pmon and an EFI
 * payload are running concurrently at the same time. In this mode, we can
 * handle a good number of runtime callbacks
 */

/**
 * efi_init_runtime_supported() - create runtime properties table
 *
 * Create a configuration table specifying which services are available at
 * runtime.
 *
 * Return:	status code
 */
efi_status_t efi_init_runtime_supported(void)
{
	efi_status_t ret;
	struct efi_rt_properties_table *rt_table;

	ret = efi_allocate_pool(EFI_RUNTIME_SERVICES_DATA,
				sizeof(struct efi_rt_properties_table),
				(void **)&rt_table);
	if (ret != EFI_SUCCESS)
		return ret;

	rt_table->version = EFI_RT_PROPERTIES_TABLE_VERSION;
	rt_table->length = sizeof(struct efi_rt_properties_table);
	rt_table->runtime_services_supported =
				EFI_RT_SUPPORTED_GET_TIME	|
				EFI_RT_SUPPORTED_SET_TIME	|
				EFI_RT_SUPPORTED_GET_VARIABLE |
				EFI_RT_SUPPORTED_GET_NEXT_VARIABLE_NAME |
				EFI_RT_SUPPORTED_SET_VIRTUAL_ADDRESS_MAP |
				EFI_RT_SUPPORTED_UPDATE_CAPSULE	|
				EFI_RT_SUPPORTED_QUERY_CAPSULE_CAPABILITIES	|
				EFI_RT_SUPPORTED_QUERY_VARIABLE_INFO	|
				EFI_RT_SUPPORTED_CONVERT_POINTER;

	/*
	 * This value must be synced with efi_runtime_detach_list
	 * as well as efi_runtime_services.
	 */
	rt_table->runtime_services_supported |= EFI_RT_SUPPORTED_RESET_SYSTEM;
	ret = efi_install_configuration_table(&efi_rt_properties_table_guid,
					      rt_table);
	return ret;
}

/**
 * efi_memcpy_runtime() - copy memory area
 *
 * At runtime memcpy() is not available.
 *
 * Overlapping memory areas can be copied safely if src >= dest.
 *
 * @dest:	destination buffer
 * @src:	source buffer
 * @n:		number of bytes to copy
 * Return:	pointer to destination buffer
 */
void efi_memcpy_runtime(void *dest, const void *src, size_t n)
{
	u8 *d = dest;
	const u8 *s = src;

	for (; n; --n)
		*d++ = *s++;
}

/**
 * efi_update_table_header_crc32() - Update crc32 in table header
 *
 * @table:	EFI table
 */
void efi_update_table_header_crc32(struct efi_table_hdr *table)
{
	table->crc32 = 0;
	table->crc32 = crc32(0, (const unsigned char *)table,
			     table->headersize);
}

/**
  Compare the hour, Minute and Second of the from time and the to time.

  Only compare H/M/S in EFI_TIME and ignore other fields here.

  @param from   the first time
  @param to     the second time

  @return  >0   The H/M/S of the from time is later than those of to time
  @return  ==0  The H/M/S of the from time is same as those of to time
  @return  <0   The H/M/S of the from time is earlier than those of to time
**/
int compare_time(struct efi_time *from, struct efi_time *to)
{
  if ((from->hour > to->hour) ||
     ((from->hour == to->hour) && (from->minute > to->minute)) ||
     ((from->hour == to->hour) && (from->minute == to->minute) && (from->second > to->second))) {
    return 1;
  } else if ((from->hour == to->hour) && (from->minute == to->minute) && (from->second == to->second)) {
    return 0;
  } else {
    return -1;
  }
}

/**
  Check if it is a leap year.

  @param    Time   The time to be checked.

  @retval   true   It is a leap year.
  @retval   false  It is NOT a leap year.
**/
char is_leap_year(struct efi_time *time)
{
  if (time->year % 4 == 0) {
    if (time->year % 100 == 0) {
      if (time->year % 400 == 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return true;
    }
  } else {
    return false;
  }
}

/**
  to check if second date is later than first date within 24 hours.

  @param  from   the first date
  @param  to     the second date

  @retval true   from is previous to To within 24 hours.
  @retval false  from is later, or it is previous to To more than 24 hours.
**/
char is_within_oneday(struct efi_time *from, struct efi_time *to)
{
	char adjacent = false;
	const unsigned char rtc_days_in_month[] = {
		31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	if (from->year == to->year) {
		if (from->month == to->month) {
			if ((from->day + 1) == to->day) {
				if ((compare_time(from, to) >= 0)) {
					adjacent = true;
				}
			} else if (from->day == to->day) {
				if ((compare_time(from, to) <= 0)) {
					adjacent = true;
				}
			}
		} else if (((from->month + 1) == to->month) && (to->day == 1)) {
			if ((from->month == 2) && !is_leap_year(from)) {
				if (from->day == 28) {
					if ((compare_time(from, to) >= 0)) {
						adjacent = true;
					}
				}
			} else if (from->day == rtc_days_in_month[from->month - 1]) {
				if ((compare_time(from, to) >= 0)) {
					adjacent = true;
				}
			}
		}
	} else if (((from->year + 1) == to->year) &&
			(from->month == 12) &&
			(from->day   == 31) &&
			(to->month   == 1)  &&
			(to->day     == 1)) {
		if ((compare_time(from, to) >= 0)) {
			adjacent = true;
		}
	}

	return adjacent;
}

/**
  See if field Day of an EFI_TIME is correct.

  @param    Time   Its Day field is to be checked.

  @retval   TRUE   Day field of Time is correct.
  @retval   FALSE  Day field of Time is NOT correct.
**/
char day_valid(struct efi_time *time)
{
	const unsigned char rtc_days_in_month[] = {
		31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	if (time->day < 1 ||
			time->day > rtc_days_in_month[time->month - 1] ||
			(time->month == 2 && (!is_leap_year(time) && time->day > 28))
	   ) {
		return false;
	}

	return true;
}

/**
 * efi_validate_time() - checks if timestamp is valid
 *
 * @time:	timestamp to validate
 * Returns:	0 if timestamp is valid, 1 otherwise
 */
static int efi_validate_time(struct efi_time *time)
{
	if (time->year < 1900 ||
			time->year > 2200 ||
			time->month < 1 ||
			time->month > 12 ||
			(!day_valid(time)) ||
			time->hour > 23 ||
			time->minute > 59 ||
			time->second > 59 ||
			time->nanosecond > 999999999 ||
			(!(time->timezone == EFI_UNSPECIFIED_TIMEZONE || (time->timezone >= -1440 && time->timezone <= 1440))) ||
			((time->daylight & (~(EFI_TIME_ADJUST_DAYLIGHT | EFI_TIME_IN_DAYLIGHT))) != 0)) {
		return EFI_INVALID_PARAMETER;
	}

	return EFI_SUCCESS;
}


efi_status_t rtc_get_time(struct efi_time *time,
		struct efi_time_cap *capabilities)
{
	efi_status_t status;
	ls7a_toy_reg0 rtc_read0;

	memset(time, 0, sizeof(*time));
	if (time == NULL)
		return EFI_INVALID_PARAMETER;

	rtc_read0.data = inl(EFI_TOY_READ0_REG);

	time->second  = rtc_read0.bits.toy_sec;
	time->minute  = rtc_read0.bits.toy_min;
	time->hour    = rtc_read0.bits.toy_hour;
	time->day     = rtc_read0.bits.toy_day;
	time->month   = rtc_read0.bits.toy_month;
	time->year    = (inl(EFI_TOY_READ1_REG) + 1900);

	time->daylight = EFI_TIME_ADJUST_DAYLIGHT;
	time->timezone = EFI_UNSPECIFIED_TIMEZONE;

	if (capabilities) {
		/* Set reasonable dummy values */
		capabilities->resolution = 1;		/* 1 Hz */
		capabilities->accuracy = 100000000;	/* 100 ppm */
		capabilities->sets_to_zero = false;
	}

	return EFI_SUCCESS;
}

/**
 * efi_get_time_runtime() - get current time
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification
 * for details.
 *
 * @time:		pointer to structure to receive current time
 * @capabilities:	pointer to structure to receive RTC properties
 * Returns:		status code
 */
static efi_status_t efi_get_time_runtime(
			struct efi_time *time,
			struct efi_time_cap *capabilities)
{
	rtc_get_time(time, capabilities);
}

/**
 * efi_set_time_runtime() - set current time
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification
 * for details.
 *
 * @time:		pointer to structure to with current time
 * Returns:		status code
 */
static efi_status_t efi_set_time_runtime(struct efi_time *time)
{
	efi_status_t status;
	struct efi_time rtc_time;
	ls7a_toy_reg0   rtc_read0;
	unsigned int  val;

	if (time == NULL)
		return EFI_INVALID_PARAMETER;
	//
	// Make sure that the time fields are valid
	//
	status = efi_validate_time(time);
	if (status)
		return status;

	efi_memcpy_runtime(&rtc_time, time, sizeof(struct efi_time));

	rtc_read0.data = ((rtc_time.month) << 26) | (rtc_time.day << 21) |
		(rtc_time.hour << 16) | (rtc_time.minute << 10) |
		(rtc_time.second << 4);

	outl(EFI_TOY_WRITE0_REG, rtc_read0.data);

	val = (unsigned int)(rtc_time.year - 1900);
	outl(EFI_TOY_WRITE1_REG, val);

	time->daylight = EFI_TIME_ADJUST_DAYLIGHT;
	time->timezone = EFI_UNSPECIFIED_TIMEZONE;

	rtc_read0.data = time->daylight;
	rtc_read0.data = (unsigned int)((rtc_read0.data << 16) | time->timezone);

	status = efi_set_variable_int(u"RTC",
			&efi_caller_id_guid,
			EFI_VARIABLE_BOOTSERVICE_ACCESS |
			EFI_VARIABLE_RUNTIME_ACCESS |
			EFI_VARIABLE_NON_VOLATILE,
			sizeof (rtc_read0.data),
			&rtc_read0.data);

	return status;
}

/**
 * efi_get_waketime_runtime() - get current wakeup time
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification
 * for details.
 *
 * @time:		pointer to structure to receive current time
 * @capabilities:	pointer to structure to receive RTC properties
 * Returns:		status code
 */
static efi_status_t efi_get_waketime_runtime(char *enabled,
		char *pending, struct efi_time *time)
{
	efi_status_t status;
	ls7a_toy_match0 rtc_match0;

	memset(time, 0, sizeof(*time));
	if (time == NULL || enabled == NULL || pending == NULL)
		return EFI_INVALID_PARAMETER;

	rtc_match0.data = inl(EFI_TOY_MATCH0_REG);

	time->year    =  inl(EFI_TOY_READ1_REG);
	time->year    &= ~0x3f;
	time->year    |= rtc_match0.bits.toy_year;
	time->year    += 1900;
	time->month   =  rtc_match0.bits.toy_month;
	time->day     =  rtc_match0.bits.toy_day;
	time->hour    =  rtc_match0.bits.toy_hour;
	time->minute  =  rtc_match0.bits.toy_min;
	time->second  =  rtc_match0.bits.toy_sec;

	*enabled = (inl(EFI_ACPI_ENABLE_REG) >> 10) & 1;
	*pending = false;

	time->daylight = EFI_TIME_ADJUST_DAYLIGHT;
	time->timezone = EFI_UNSPECIFIED_TIMEZONE;

	//
	// Make sure all field values are in correct range
	//
	status = efi_validate_time(time);

	return status;
}

/**
 * efi_set_time_boottime() - set current wakeup time
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification
 * for details.
 *
 * @time:		pointer to structure to with current time
 * Returns:		status code
 */
static efi_status_t efi_set_waketime_runtime(char enable, struct efi_time *time)
{
	efi_status_t status;
	struct efi_time rtc_time;
	ls7a_toy_match0 rtc_match0;
	struct efi_time_cap capabilities;
	unsigned long acpi_enabled;

	if (time == NULL)
		return EFI_INVALID_PARAMETER;

	//
	// Make sure that the time fields are valid
	//
	status = efi_validate_time(time);
	if (status)
		return EFI_INVALID_PARAMETER;

	memset(&rtc_time, 0, sizeof(*time));

	//
	// Just support set alarm time within 24 hours
	//
	rtc_get_time(&rtc_time, &capabilities);
	status = efi_validate_time(&rtc_time);
	if (status)
		return EFI_DEVICE_ERROR;

	if (!is_within_oneday(&rtc_time, time))
		return EFI_INVALID_PARAMETER;

	//
	// Make a local copy of the time and date
	//
	efi_memcpy_runtime(&rtc_time, time, sizeof(struct efi_time));

	//
	// Read ACPI enable register
	//
	acpi_enabled = inl(EFI_ACPI_ENABLE_REG);

	rtc_time.year -= 1900;
	rtc_time.year &= 0x3f;

	rtc_match0.data  = (rtc_time.year << 26) | (rtc_time.month << 22) | (rtc_time.day << 17)
		| (rtc_time.hour << 12) | (rtc_time.minute << 6)| (rtc_time.second);

	//
	// Set RTC alarm time
	//
	outl((EFI_TOY_MATCH0_REG), rtc_match0.data);

	if (enable) {
		acpi_enabled |= (1 << 10);
	} else {
		acpi_enabled &= ~(1 << 10);
	}

	outl(EFI_ACPI_ENABLE_REG, acpi_enabled);

	return EFI_SUCCESS;
}

/**
 * efi_reset_system_boottime() - reset system at runtime
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * @reset_type:		type of reset to perform
 * @reset_status:	status code for the reset
 * @data_size:		size of reset_data
 * @reset_data:		information about the reset
 */
void efi_reset_system_runtime(
			enum efi_reset_type reset_type,
			efi_status_t reset_status,
			unsigned long data_size, void *reset_data)
{
	efi_status_t ret;
	unsigned int size;
	unsigned long capsule_ptr;
	struct efi_event *evt;

	EFI_ENTRY("%d %lx %lx %p", reset_type, reset_status, data_size,
		  reset_data);

	/* Notify reset */
	list_for_each_entry(evt, &efi_events, link) {
		if (evt->group &&
		    !guidcmp(evt->group,
			     &efi_guid_event_group_reset_system)) {
			efi_signal_event(evt);
			break;
		}
	}
	switch (reset_type) {
		case EFI_RESET_WARM:
			size = sizeof(unsigned long);
			ret = efi_get_variable_int("CapsuleUpdateData",
					&gEfiCapsuleVendorGuid, NULL,
					&size, &capsule_ptr, NULL);
			if (ret == EFI_SUCCESS) {
				EFI_PRINT("Is capsule update, S3 reboot!\n");
				flush_cache (DCACHE | ICACHE, NULL);
				suspend_reboot();
			}
			tgt_reboot();
		case EFI_RESET_COLD:
		case EFI_RESET_PLATFORM_SPECIFIC:
			tgt_reboot();
			break;
		case EFI_RESET_SHUTDOWN:
			tgt_poweroff();
		break;
	}

	while (1) { }
}

/**
 * efi_reset_system_init() - initialize the reset driver
 *
 * Boards may override this function to initialize the reset driver.
 */
efi_status_t efi_reset_system_init(void)
{
	return EFI_SUCCESS;
}

/**
 * efi_is_runtime_service_pointer() - check if pointer points to runtime table
 *
 * @p:		pointer to check
 * Return:	true if the pointer points to a service function pointer in the
 *		runtime table
 */
static bool efi_is_runtime_service_pointer(void *p)
{
	return (p >= (void *)&efi_runtime_services.get_time &&
		p <= (void *)&efi_runtime_services.query_variable_info) ||
	       p == (void *)&efi_events.prev ||
	       p == (void *)&efi_events.next;
}

/**
 * efi_runtime_detach() - detach unimplemented runtime functions
 */
void efi_runtime_detach(void)
{
	/* Update CRC32 */
	efi_update_table_header_crc32(&efi_runtime_services.hdr);
}

/**
 * efi_set_virtual_address_map_runtime() - change from physical to virtual
 *					   mapping
 *
 * This function implements the SetVirtualAddressMap() runtime service after
 * it is first called.
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * @memory_map_size:	size of the virtual map
 * @descriptor_size:	size of an entry in the map
 * @descriptor_version:	version of the map entries
 * @virtmap:		virtual address mapping information
 * Return:		status code EFI_UNSUPPORTED
 */
static efi_status_t efi_set_virtual_address_map_runtime(
			efi_uintn_t memory_map_size,
			efi_uintn_t descriptor_size,
			uint32_t descriptor_version,
			struct efi_mem_desc *virtmap)
{
	return EFI_UNSUPPORTED;
}

/**
 * efi_convert_pointer_runtime() - convert from physical to virtual pointer
 *
 * This function implements the ConvertPointer() runtime service after
 * the first call to SetVirtualAddressMap().
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * @debug_disposition:	indicates if pointer may be converted to NULL
 * @address:		pointer to be converted
 * Return:		status code EFI_UNSUPPORTED
 */
static efi_status_t efi_convert_pointer_runtime(
			efi_uintn_t debug_disposition, void **address)
{
	return EFI_UNSUPPORTED;
}

/**
 * efi_convert_pointer() - convert from physical to virtual pointer
 *
 * This function implements the ConvertPointer() runtime service until
 * the first call to SetVirtualAddressMap().
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * @debug_disposition:	indicates if pointer may be converted to NULL
 * @address:		pointer to be converted
 * Return:		status code
 */
efi_status_t efi_convert_pointer(efi_uintn_t debug_disposition, void **address)
{
	efi_physical_addr_t addr;
	efi_uintn_t i;
	efi_status_t ret = EFI_NOT_FOUND;

	if (!efi_virtmap) {
		ret = EFI_UNSUPPORTED;
		goto out;
	}

	if (!address) {
		ret = EFI_INVALID_PARAMETER;
		goto out;
	}
	if (!*address) {
		if (debug_disposition & EFI_OPTIONAL_PTR)
			return EFI_SUCCESS;
		else
			return EFI_INVALID_PARAMETER;
	}

	addr = (uintptr_t)*address;
	for (i = 0; i < efi_descriptor_count; i++) {
		struct efi_mem_desc *map = (void *)efi_virtmap +
					   (efi_descriptor_size * i);

		if (addr >= map->physical_start &&
		    (addr < map->physical_start
			    + (map->num_pages << EFI_PAGE_SHIFT))) {
			*address = (void *)(uintptr_t)
				   (addr + map->virtual_start -
				    map->physical_start);

			ret = EFI_SUCCESS;
			break;
		}
	}

out:
	return ret;
}

/**
 * efi_set_virtual_address_map() - change from physical to virtual mapping
 *
 * This function implements the SetVirtualAddressMap() runtime service.
 *
 * See the Unified Extensible Firmware Interface (UEFI) specification for
 * details.
 *
 * @memory_map_size:	size of the virtual map
 * @descriptor_size:	size of an entry in the map
 * @descriptor_version:	version of the map entries
 * @virtmap:		virtual address mapping information
 * Return:		status code
 */
static efi_status_t efi_set_virtual_address_map(
			efi_uintn_t memory_map_size,
			efi_uintn_t descriptor_size,
			uint32_t descriptor_version,
			struct efi_mem_desc *virtmap)
{
	EFI_ENTRY("%zx %zx %x %p", memory_map_size, descriptor_size,
		  descriptor_version, virtmap);

	efi_at_runtime = 1;
out:
	return EFI_SUCCESS;
}

/*
 * In the second stage, pmon has disappeared. to isolate our runtime code
 * that at this point still exists from the rest, we put it into a special
 * section.
 *
 *        !!WARNING!!
 *
 * This means that we can not rely on any code outside of this file in any
 * function or variable below this line.
 *
 * Please keep everything fully self-contained and annotated with
 * and markers.
 */

/*
 * Relocate the EFI runtime stub to a different place. We need to call this
 * the first time we expose the runtime interface to a user and on set virtual
 * address map calls.
 */

/**
 * efi_unimplemented() - replacement function, returns EFI_UNSUPPORTED
 *
 * This function is used after SetVirtualAddressMap() is called as replacement
 * for services that are not available anymore due to constraints of the pmon
 * implementation.
 *
 * Return:	EFI_UNSUPPORTED
 */
static efi_status_t efi_unimplemented(void)
{
	return EFI_UNSUPPORTED;
}

struct efi_runtime_services efi_runtime_services = {
	.hdr = {
		.signature = EFI_RUNTIME_SERVICES_SIGNATURE,
		.revision = EFI_SPECIFICATION_VERSION,
		.headersize = sizeof(struct efi_runtime_services),
	},
	.get_time = &efi_get_time_runtime,
	.set_time = &efi_set_time_runtime,
	.get_wakeup_time = (void *)&efi_get_waketime_runtime,
	.set_wakeup_time = (void *)&efi_set_waketime_runtime,
	.set_virtual_address_map = &efi_set_virtual_address_map,
	.convert_pointer = efi_convert_pointer,
	.get_variable = efi_get_variable,
	.get_next_variable_name = efi_get_next_variable_name,
	.set_variable = efi_set_variable,
	.get_next_high_mono_count = (void *)&efi_unimplemented,
	.reset_system = &efi_reset_system_runtime,
	.update_capsule = efi_update_capsule,
	.query_capsule_caps = efi_query_capsule_caps,
	.query_variable_info = efi_query_variable_info,
};
