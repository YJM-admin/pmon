#ifndef _BOARD_H
#define _BOARD_H
/* Board Version Number */
extern unsigned int board_ver_num;

enum board_version {
	LS2H_BOARD_OLD	= 0xf,
	LS2H_BOARD_2_2	= 0x4,
};
#endif
