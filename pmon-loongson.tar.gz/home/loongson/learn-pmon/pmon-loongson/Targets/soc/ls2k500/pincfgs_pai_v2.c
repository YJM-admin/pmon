/*
 * This file is for Loongson SOC pin and gpio ctrl
 */
#include "target/pincfgs.h"
#include <pmon.h>
#include <string.h>
pin_cfgs_t default_pin_cfgs[155] = {
	//0:GPIO , 5:main
	{  0, 0},	//0:GPIO0
	{  1, 0},	//0:GPIO1
	{  2, 5},	//5:vga_hsync
	{  3, 5},	//5:vga_vsync
	{  4, 5},	//5:lcd_clk             1:can2_rx   (module)
	{  5, 5},	//5:lcd_vsync           1:can2_tx   (module)
	{  6, 5},	//5:lcd_hsync           1:can3_rx   (module)
	{  7, 5},	//5:lcd_en              1:can3_tx   (module)
	{  8, 5},	//5:lcd_dat_b[0]        1:uart0_tx  (module)
	{  9, 5},	//5:lcd_dat_b[1]        1:uart0_rx  (module)
	{ 10, 5},	//5:lcd_dat_b[2]        1:uart0_rts (module)   uart6_tx
	{ 11, 5},	//5:lcd_dat_b[3]        1:uart0_cts (module)   uart6_rx
	{ 12, 5},	//5:lcd_dat_b[4]        1:uart0_dsr (module)   uart4_rx
	{ 13, 5},	//5:lcd_dat_b[5]        1:uart0_dtr (module)   uart4_tx
	{ 14, 5},	//5:lcd_dat_b[6]        1:uart0_dcd (module)   uart5_rx
	{ 15, 5},	//5:lcd_dat_b[7]        1:uart0_ri  (module)   uart5_tx
	{ 16, 5},	//5:lcd_dat_g[0]        1:uart1_rx  (module)
	{ 17, 5},	//5:lcd_dat_g[1]        1:uart1_tx  (module)
	{ 18, 5},	//5:lcd_dat_g[2]        1:uart1_rts (module)   uart9_tx
	{ 19, 5},	//5:lcd_dat_g[3]        1:uart1_cts (module)   uart9_rx
	{ 20, 5},	//5:lcd_dat_g[4]        1:uart1_dsr (module)   uart7_rx
	{ 21, 5},	//5:lcd_dat_g[5]        1:uart1_dtr (module)   uart7_tx
	{ 22, 5},	//5:lcd_dat_g[6]        1:uart1_dcd (module)   uart8_rx
	{ 23, 5},	//5:lcd_dat_g[7]        1:uart1_ri  (module)   uart8_tx
	{ 24, 5},	//5:lcd_dat_r[0]        3:spi4_clk  (module)
	{ 25, 5},	//5:lcd_dat_r[1]        3:spi4_miso (module)
	{ 26, 5},	//5:lcd_dat_r[2]        3:spi4_mosi (module)
	{ 27, 5},	//5:lcd_dat_r[3]        3:spi4_cs   (module)
	{ 28, 5},	//5:lcd_dat_r[4]        3:spi5_clk  (module)
	{ 29, 5},	//5:lcd_dat_r[5]        3:spi5_miso (module)
	{ 30, 5},	//5:lcd_dat_r[6]        3:spi5_mosi (module)
	{ 31, 5},	//5:lcd_dat_r[7]        3:spi5_cs   (module)
	{ 32, 0},	//5:kb_clk    (module)  3:spi3_clk  (pai)
	{ 33, 0},	//5:kb_dat    (module)  3:spi3_miso (pai)
	{ 34, 5},	//5:ms_clk    (module)  3:spi3_mosi (pai)
	{ 35, 5},	//5:ms_dat    (module)  3:spi3_cs   (pai)
	{ 36, 5},	//5:ac97_datai(module)  3:pix0_scl  (pai)
	{ 37, 5},	//5:ac97_datao(module)  3:pix0_sda  (pai)
	{ 38, 5},	//5:ac97_sync (module)  3:pix1_scl  (pai)
	{ 39, 5},	//5:ac97_reset(module)  3:pix1_sda  (pai)
	{ 40, 5},	//5:spi0_clk
	{ 41, 5},	//5:spi0_miso
	{ 42, 5},	//5:spi0_mosi
	{ 43, 5},	//5:spi0_cs[0]
	{ 44, 5},	//5:spi1_clk	        0:GPIO44
	{ 45, 5},	//5:spi1_miso	        0:GPIO45
	{ 46, 5},	//5:spi1_mosi	        0:GPIO46
	{ 47, 5},	//5:spi1_cs[0]	        0:GPIO47
	{ 48, 1},	//1:gmac1_rx_ctl
	{ 49, 1},	//1:gmac1_rx[0]
	{ 50, 1},	//1:gmac1_rx[1]         3:scl1
	{ 51, 1},	//1:gmac1_rx[2]	        3:sda1
	{ 52, 1},	//1:gmac1_rx[3]
	{ 53, 1},	//1:gmac1_tx_ctl
	{ 54, 1},	//1:gmac1_tx[0]
	{ 55, 1},	//1:gmac1_tx[1]
	{ 56, 1},	//1:gmac1_tx[2]
	{ 57, 1},	//1:gmac1_tx[3]
	{ 58, 1},	//1:gmac1_mdck
	{ 59, 1},	//1:gmac1_mdio
	{ 60, 5},	//5:uart2_tx(pai)
	{ 61, 5},	//5:uart2_rx(pai)
	{ 62, 5},	//5:uart3_tx(pai)       1:pix1_scl(module)
	{ 63, 5},	//5:uart3_rx(pai)       1:pix1_sda(module)
	{ 64, 5},	//5:scl0	            1:nand_rdy[1]	        3:spi0_cs[3]
	{ 65, 5},	//5:sda0	            1:nand_ce[1]	        3:spi0_cs[2]
	{ 66, 5},	//5:can0_rx	            1:nand_rdy[2]	        2:sda2		        3:spi0_cs[1]
	{ 67, 5},	//5:can0_tx	            1:nand_ce[2]	        2:scl2		        3:spi1_cs[3]
	{ 68, 5},	//5:can1_rx	            1:nand_rdy[3]	        2:sda3		        3:spi1_cs[2]
	{ 69, 5},	//5:can1_tx	            1:nand_ce[3]	        2:scl3		        3:spi1_cs[1]
	{ 70, 2},	//5:lpc_ad[0]	        1:nand_d[0]
	{ 71, 2},	//5:lpc_ad[1]	        1:nand_d[1]
	{ 72, 2},	//5:lpc_ad[2]           1:nand_d[2]
	{ 73, 2},	//5:lpc_ad[3]           1:nand_d[3]
	{ 74, 2},	//5:lpc_frame	        1:nand_d[4]
	{ 75, 2},	//5:lpc_serirq	        1:nand_d[5]
	{ 76, 4},	//5:nand_cle            4:pwm0(module)
	{ 77, 4},	//5:nand_ale            4:pwm1(module)
	{ 78, 4},	//5:nand_rd             4:pwm2(module)
	{ 79, 4},	//5:nand_wr             4:pwm3(module)
	{ 80, 4},	//5:nand_ce[0]          4:pwm4(module)
	{ 81, 4},	//5:nand_rdy[0]         4:pwm5(module)
	{ 82, 4},	//5:nand_d[6]           4:pwm6(module)
	{ 83, 0},	//5:nand_d[7]           0:gpio83(module)
	{ 84, 4},	//5:pwm[0](pai)         0:gpio84(module)
	{ 85, 0},	//5:pwm[1](pai)         0:gpio85(module)
	{ 86, 0},	//5:pwm[2](pai)	        0:gpio86(module)
	{ 87, 0},	//5:pwm[3](pai)         0:gpio87(module)
	{ 88, 5},	//5:gmac0_rx_ctl
	{ 89, 5},	//5:gmac0_rx[0]
	{ 90, 5},	//5:gmac0_rx[1]
	{ 91, 5},	//5:gmac0_rx[2]
	{ 92, 5},	//5:gmac0_rx[3]
	{ 93, 5},	//5:gmac0_tx_ctl
	{ 94, 5},	//5:gmac0_tx[0]
	{ 95, 5},	//5:gmac0_tx[1]
	{ 96, 5},	//5:gmac0_tx[2]
	{ 97, 5},	//5:gmac0_tx[3]
	{ 98, 5},	//5:gmac0_mdck
	{ 99, 5},	//5:gmac0_mdio
	{100, 0},	//5:pci_ad[0]           2:lioa[0]               1:pr_int    (pai)
	{101, 0},	//5:pci_ad[1]           2:lioa[1]               1:pr0_clk
	{102, 0},	//5:pci_ad[2]           2:lioa[2]               1:pr0_start
	{103, 0},	//5:pci_ad[3]           2:lioa[3]               1:pr0_ready
	{104, 0},	//5:pci_ad[4]           2:lioa[4]               1:pr0_enable
	{105, 0},	//5:pci_ad[5]           2:lioa[5]               1:pr0_shold
	{106, 0},	//5:pci_ad[6]           2:lioa[6]               1:pr0_data
	{107, 0},	//5:pci_ad[7]           2:lioa[7]               1:pr0_hsync
	{108, 0},	//5:pci_ad[8]           2:lioa[8]               1:pr1_enable
	{109, 0},	//5:pci_ad[9]           2:lioa[9]               1:pr1_shold
	{110, 0},	//5:pci_ad[10]          2:lioa[10]              1:pr1_data
	{111, 0},	//5:pci_ad[11]          2:lioa[11]              1:pr2_clk
	{112, 0},	//5:pci_ad[12]          2:lioa[12]              1:pr2_start
	{113, 0},	//5:pci_ad[13]          2:lioa[13]              1:pr2_ready
	{114, 0},	//5:pci_ad[14]          2:lioa[14]              1:pr2_enable
	{115, 0},	//5:pci_ad[15]          2:lioa[15]              1:pr2_shold
	{116, 3},	//5:pci_ad[16]          2:lio_data[0]           1:pr2_data          3:uart1_rx
	{117, 3},	//5:pci_ad[17]          2:lio_data[1]           1:pr2_hsync         3:uart1_tx
	{118, 0},	//5:pci_ad[18]          2:lio_data[2]           1:pr3_enable        3:uart1_rts
	{119, 0},	//5:pci_ad[19]          2:lio_data[3]           1:pr3_shold         3:uart1_cts
	{120, 3},	//5:pci_ad[20]          2:lio_data[4]           1:pr3_data          3:uart1_dsr
	{121, 3},	//5:pci_ad[21]          2:lio_data[5]           1:pr4_clk           3:uart1_dtr
	{122, 0},	//5:pci_ad[22]          2:lio_data[6]           1:pr4_start         3:uart1_dcd
	{123, 0},	//5:pci_ad[23]          2:lio_data[7]           1:pr4_ready         3:uart1_ri
	{124, 0},	//5:pci_ad[24]          2:lio_data[8]           1:pr4_enable
	{125, 0},	//5:pci_ad[25]          2:lio_data[9]           1:pr4_shold
	{126, 0},	//5:pci_ad[26]          2:lio_data[10]          1:pr4_data
	{127, 0},	//5:pci_ad[27]          2:lio_data[11]          1:pr4_hsync
	{128, 0},	//5:pci_ad[28]          2:lio_data[12]          1:pr5_enable
	{129, 0},	//5:pci_ad[29]          2:lio_data[13]          1:pr5_shold
	{130, 0},	//5:pci_ad[30]          2:lio_data[14]          1:pr5_data
	{131, 0},	//5:pci_ad[31]          2:lio_data[15]          1:pr6_clk
	{132, 0},	//5:pci_cbe[0]          2:lioa[16]              1:pr6_start
	{133, 4},	//5:pci_cbe[1]          2:lioa[17]              1:pr6_ready
	{134, 4},	//5:pci_cbe[2]          2:lioa[18]              1:pr6_enable
	{135, 4},	//5:pci_cbe[3]          2:lioa[19]              1:pr6_shold
	{136, 4},	//5:pci_frame           2:lioa[20]              1:pr6_data
	{137, 0},	//5:pci_irdy            2:lioa[21]              1:pr6_hsync
	{138, 0},	//5:pci_devsel          2:lioa[22]              1:pr7_enable
	{139, 0},	//5:pci_trdy            2:liocsn[0]             1:pr7_shold
	{140, 0},	//5:pci_stop            2:liocsn[1]             1:pr7_data
	{141, 0},	//5:pci_idsel           2:liowrn
	{142, 0},	//5:pci_par             2:liordn
	{143, 4},	//5:pci_perr            4:sdio1_clk (module)
	{144, 4},	//5:pci_serr            4:sdio1_cmd (module)
	{145, 4},	//5:pci_req[0]          4:sdio1_d[0](module)
	{146, 4},	//5:pci_req[1]          4:sdio1_d[1](module)
	{147, 4},	//5:pci_gnt[0]          4:sdio1_d[2](module)
	{148, 4},	//5:pci_gnt[1]          4:sdio1_d[3](module)
	{149, 5},	//5:sdio_clk
	{150, 5},	//5:sdio_cmd
	{151, 5},	//5:sdio_d[0]
	{152, 5},	//5:sdio_d[1]
	{153, 5},	//5:sdio_d[2]
	{154, 5}	//5:sdio_d[3]
};

/* add all pins that you want to cfg. just like this, then call cfg_all_pin_multi() */
pin_cfgs_t can0_pin_cfgs[] = {
	{ 66, 5 },	//5:can0_rx	1:nand_rdy[2]	2:sda2		3:spi0_cs[1]
	{ 67, 5 },	//5:can0_tx	1:nand_ce[2]	2:scl2		3:spi1_cs[3]
};

void ls2k500_gpio_out(int gpio_num, int val)
{
	set_pin_mode(gpio_num, 0);
	uint64_t *addr_dir = LS2K500_GPIO_00_63_DIR + gpio_num / 64 * GPIO_SKIP_64_OFFSET;
	uint64_t *addr_out = LS2K500_GPIO_00_63_OUT + gpio_num / 64 * GPIO_SKIP_64_OFFSET;
	int bit = gpio_num % 64;
	readq(addr_dir) &= ~(1ULL << bit);
	readq(addr_out) = readq(addr_out) & ~(1ULL << bit) | ((unsigned long long)!!val << bit);
}

int ls2k500_gpio_in(int gpio_num)
{
	set_pin_mode(gpio_num, 0);
	uint64_t *addr_dir = LS2K500_GPIO_00_63_DIR + gpio_num / 64 * GPIO_SKIP_64_OFFSET;
	uint64_t *addr_in = LS2K500_GPIO_00_63_IN + gpio_num / 64 * GPIO_SKIP_64_OFFSET;
	int bit = gpio_num % 64;
	readq(addr_dir) |= (1ULL << bit);
	return !!(readq(addr_in) & (1ULL << bit));
}

void ls2k500_gpio_irq_enable(int gpio_num, int val)
{
	uint64_t *addr_irqen = LS2K500_GPIO_IRQ_EN_CFG + gpio_num / 64 * 8;
	int bit = gpio_num % 64;
	readq(addr_irqen) = readq(addr_irqen) & ~(1ULL << bit) | ((unsigned long long)!!val << bit);
}

void ls2k500_gpio_irq_init(int gpio_base, uint64_t mask, uint64_t val)
{
	uint64_t *addr_irqen = LS2K500_GPIO_IRQ_EN_CFG + gpio_base / 64 * 8;
	readq(addr_irqen) = readq(addr_irqen) & mask | val;
}

int cmd_ls2k500_gpio_out(int ac, unsigned char *av[])
{
	if (ac != 3) {
		printf("gpio_out <gpio_num> <output_val>\n");
		return 0;
	}
	ls2k500_gpio_out(strtoul(av[1], NULL, 0), strtoul(av[2], NULL, 0));
	return 0;
}

int cmd_ls2k500_gpio_in(int ac, unsigned char *av[])
{
	if (ac != 2) {
		printf("gpio_in <gpio_num>\n");
		return 0;
	}
	printf("gpio read val: %d\n", ls2k500_gpio_in(strtoul(av[1], NULL, 0)));
	return 0;
}

char pin_set[156] = {0};
int loop_set_pin(int from, int to, int val, int skip)
{
	int i;
	for (i = from; skip && i <= to; i++) {	//check
		if (pin_set[i]) {
			return -1;
		}
	}
	for (i = from; i <= to; i++) {
		set_pin_mode(i, val);
		pin_set[i] = 1;
	}
	return 0;
}

int cfg_func_multi(const char * name, int skip)
{
	int ret = 0;
	if (strstr(name, "can0")) {
		ret = loop_set_pin(66, 67, 5, skip);
	} else if (strstr(name, "can1")) {
		ret = loop_set_pin(68, 69, 5, skip);
	} else if (strstr(name, "can2")) {
		ret = loop_set_pin(133, 134, 4, skip);
	} else if (strstr(name, "can3")) {
		ret = loop_set_pin(135, 136, 4, skip);
	} else if (strstr(name, "gmac0")) {
		ret = loop_set_pin(88, 99, 5, skip);
	} else if (strstr(name, "gmac1")) {
		ret = loop_set_pin(48, 59, 1, skip);
	} else if (strstr(name, "ac97")) {
		ret = loop_set_pin(36, 39, 5, skip);
		readl(LS2K500_GENERAL_CFG0) &= ~(1 << 9);	//disable hda
	} else if (strstr(name, "hda")) {
		ret = loop_set_pin(36, 39, 5, skip);
		readl(LS2K500_GENERAL_CFG0) |= (1 << 9);	//hda pins use ac97
	} else if (strstr(name, "pwm")) {
		ret = loop_set_pin(76, 84, 4, skip);
	} else if (strstr(name, "sdio0")) {
		ret = loop_set_pin(149, 154, 5, skip);
	} else if (strstr(name, "sdio1")) {
		ret = loop_set_pin(143, 148, 4, skip);
	} else if (strstr(name, "serial") || strstr(name, "uart2")) {
		ret = loop_set_pin(60, 61, 5, skip);
	} else if (strstr(name, "uart1")) {
		ret = loop_set_pin(116, 117, 3, skip);
	} else if (strstr(name, "uart3")) {
		ret = loop_set_pin(62, 63, 5, skip);
	} else if (strstr(name, "uart7")) {
		ret = loop_set_pin(120, 121, 3, skip);
	} else if (strstr(name, "spi0")) {
		ret = loop_set_pin(40, 43, 5, skip);
	} else if (strstr(name, "spi1")) {
		ret = loop_set_pin(44, 47, 5, skip);
	} else if (strstr(name, "i2c0")) {
		ret = loop_set_pin(64, 65, 5, skip);
	} else if (strstr(name, "i2c1")) {
		ret = loop_set_pin(70, 71, 2, skip);
	} else if (strstr(name, "i2c2")) {
		ret = loop_set_pin(72, 73, 2, skip);
	} else if (strstr(name, "i2c3")) {
		ret = loop_set_pin(74, 75, 2, skip);
	} else if (strstr(name, "lcd")) {
		ret = loop_set_pin(4, 31, 5, skip);
		ret = loop_set_pin(32, 32, 5,skip);
		ret = loop_set_pin(84, 84, 5,skip);
#define LPC_4M_FLASH
#ifdef LPC_4M_FLASH
		readl(LS2K500_GENERAL_CFG2) &= ~(1 << 5);	// Select 4M LPC flash
#endif
	} else if (strstr(name, "lio")) {
		ret = loop_set_pin(100, 142, 2, skip);
		/* set lio 16bit mode, and set delay to make sure that rdn is morethan 35ns */
		readl(LS2K500_GENERAL_CFG1) |= (1 << 28) | (8 << 23);
	} else {
		printf("unknow device name: %s\n", name);
	}
	if (ret == -1)
		printf("note: conflict for resetting dev: %s\n", name);
	return ret;
}

int cmd_set_dev_pins(int ac, unsigned char *av[])
{
	if (ac != 2) {
		printf("set_dev_pins <dev_name>\n");
		printf("\teg: set_dev_pins uart0/spi1/lio ...\n");
		return 0;
	}
	cfg_func_multi(av[1], 0);
	return 0;
}

static const Cmd Cmds[] =
{
	{"MyCmds"},
	{"gpio_out","",0,"set gpio out put <gpio num> <val>", cmd_ls2k500_gpio_out , 0, 3, CMD_REPEAT},
	{"gpio_in","",0,"set gpio in, and get val", cmd_ls2k500_gpio_in , 0, 2, CMD_REPEAT},
	{"set_dev_pins","",0,"cfg multi for devices", cmd_set_dev_pins , 0, 2, CMD_REPEAT},
	{0,0}
};

static void init_cmd __P((void)) __attribute__ ((constructor));

static void
init_cmd()
{
	cmdlist_expand(Cmds,1);
}
