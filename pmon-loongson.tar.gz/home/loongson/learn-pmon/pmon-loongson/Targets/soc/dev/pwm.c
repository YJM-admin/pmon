#include <pmon.h>
#include <stdio.h>
#include <machine/pio.h>

#ifdef  LOONGARCH_2K300
	unsigned long pwm_base = 0x800000001611b000;
#endif

void
 delay2(unsigned int loops)
 {
     volatile unsigned int counts = loops;
     while (counts--);
 }

static void pwm_control(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , low,full;
	unsigned int val_base;
	unsigned long pwm_base_num;
	unsigned int val;
	if(ac <4)
	{
		printf("pwm_contorl num low full\n");
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0);
	low = (unsigned int)strtoul(av[2], 0, 0);
	full = (unsigned int)strtoul(av[3], 0, 0);

#ifdef  LOONGARCH_2K300
	pwm_base_num = pwm_base+0x10*num;

	val = readl(0x80000000160004a4);
	val |= ((1 << 13) | (1 << 15) | (1 << 17) | (1 << 19));
	val &= ~((1 << 12) | (1 << 14) | (1 << 16) | (1 << 18));
	writel(val, 0x80000000160004a4);
#endif
	val = readl(pwm_base_num+0xc);
	val &= ~(0x7ff);
	writel(val, pwm_base_num+0xc);

	outl(pwm_base_num+0x4, low);
	outl(pwm_base_num+0x8, full);
	
	val = readl(pwm_base_num+0xc);
	val |= 1;
	writel(val, pwm_base_num+0xc);
}
void
delay3(unsigned int loops)
{
	volatile unsigned int counts = loops;
	while (counts--);
}


static void pwm_measure(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , low,full;
	unsigned int val_base;
	unsigned long pwm_base_num;

	if(ac <2)
	{
		printf("pwm_measure num \n");
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0);

#ifdef  LOONGARCH_2K300
    pwm_base_num = pwm_base+0x10*num;
#endif
	readl(pwm_base_num+0xc) &= ~1;
	readl(pwm_base_num+0xc) |= (1 << 3);
	delay2(1000000);
	readl(pwm_base_num+0xc) |= (1 << 8);
	delay2(1000000);
	readl(pwm_base_num+0xc) |= (1 << 0);
	printf("wait pwm pulse\n");
	delay2(300000000);


	low = readl(pwm_base_num+0x4);
	full = readl(pwm_base_num+0x8);
	printf("low is %x\n",low);
	printf("full is %x\n",full);
}


static const Cmd Cmds[] =
{
    {"MyCmds"},
    {"pwm_control", "", 0, "num low full", pwm_control, 0,99, CMD_REPEAT},
    {"pwm_measure", "", 0, "num ", pwm_measure, 0,99, CMD_REPEAT},

};
static void init_cmd __P((void)) __attribute__ ((constructor));

static void
init_cmd()
{
	cmdlist_expand(Cmds, 1);
}
