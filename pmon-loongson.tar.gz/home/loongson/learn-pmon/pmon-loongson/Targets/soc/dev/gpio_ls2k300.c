#include <pmon.h>
#include <stdio.h>
/*ls2k300 gpio test*/
static unsigned long gpio_node_base = 0x8000000016104000;
static unsigned long gpio_dir_base = 0x800;
static unsigned long gpio_out_base = 0x900;
static unsigned long gpio_in_base = 0xa00;
void set_gpio_direction(unsigned long base ,unsigned int gpio, int val,int node)
{
	if(val)
		writeb(0x0,gpio_node_base + gpio_dir_base + gpio);
	else
		writeb(0x1,gpio_node_base + gpio_dir_base + gpio);

}

unsigned int set_gpio_val(unsigned long base ,int gpio,int val,int node)
{
	if(val)
		writeb(0x1,gpio_node_base + gpio_out_base + gpio);
	else
		writeb(0x0,gpio_node_base + gpio_out_base + gpio);	
}

unsigned int get_gpio_val(unsigned long base ,int gpio,int node)
{
	return readb(gpio_node_base + gpio_in_base + gpio);
}

static void gpio_init(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , dir;

	if(ac <3)
	{
		printf("gpio_init error parameter\n");	
		return;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio
	dir = (unsigned int)strtoul(av[2], 0, 0); //gpio
	if((num>105) || (num<0)){
		printf("gpio num error,should be 0~105\n");
		return;
	}
	set_gpio_direction(gpio_node_base , num, dir,1);
}

static void gpio_set(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , val;

	if(ac <3)
	{
		printf("gpio_set error parameter\n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio
	val = (unsigned int)strtoul(av[2], 0, 0); //gpio
	if((num>105) || (num<0)){
		printf("gpio num error,should be 0~105\n");
		return;
	}
	set_gpio_val(gpio_node_base, num, val,1);
	printf("gpio_set %d dir\n",num);
}

static void gpio_get(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , val;

	if(ac <2)
	{
		printf("gpio_init error parameter\n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio
	if((num>105) || (num<0)){
		printf("gpio num error,should be 0~105\n");
		return;
	}
	val = get_gpio_val(gpio_node_base , num,1);
	printf("val is %x\n",val);
}



static const Cmd Cmds[] =
{
    {"MyCmds"},
    {"gpio_init", "", 0, "gpio_init num dir", gpio_init, 0,99, CMD_REPEAT},
    {"gpio_set", "", 0, "gpio_set num val", gpio_set, 0,99, CMD_REPEAT},
    {"gpio_get", "", 0, "gpio_get num", gpio_get, 0,99, CMD_REPEAT},
    {0, 0}
};
static void init_cmd __P((void)) __attribute__ ((constructor));

static void
init_cmd()
{
	cmdlist_expand(Cmds, 1);
}



