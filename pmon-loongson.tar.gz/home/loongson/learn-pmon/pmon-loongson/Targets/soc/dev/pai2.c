void pai2_init(void)
{

#ifdef LCD_EN
	*(volatile int *)0x800000001fe10434 &= ~1;
	*(volatile int *)0x800000001fe10444 |= 1;
	printf("=== lcd _en ===\n");

//enalbe pwm 8
	*(volatile int *)0x800000001fe104b8 |=(1<<18);
	*(volatile int *)0x800000001fe104b8 &= ~(1<<17);
	*(volatile int *)0x800000001fe104b8 &= ~(1<<16);
	*(volatile int *)0x800000001ff5c084 = 150;
	*(volatile int *)0x800000001ff5c088 = 1500;
	*(volatile int *)0x800000001ff5c08c = 1;
	printf("=== enalbe_pwm ===\n");
#endif

// set touchscreen type of irq
	{
		unsigned int val;
		val =*(volatile int *)0x800000001fe11470;
		printf("470=0x%x\n", val);
		val =*(volatile int *)0x800000001fe11474;
		printf("474=0x%x\n", val);

		*(volatile int *)0x800000001fe11470 &= ~(1<<29);	
		*(volatile int *)0x800000001fe11474 |= (1<<29);	
		printf("after write\n");
		val =*(volatile int *)0x800000001fe11470;
		printf("470=0x%x\n", val);
		val =*(volatile int *)0x800000001fe11474;
		printf("474=0x%x\n", val);
	
	}
}
