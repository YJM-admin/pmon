#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#undef _KERNEL
#include <errno.h>
#include <pmon.h>
#include <pflash.h>
#include <target/ls2k300.h>
//#include <target/ls2k300_dma.h>
#include <linux/spi.h>
#include <linux/bitops.h>

char* ls_spi_base_io = LS2K300_SPI0_BASE;

#define SPCR      0x0
#define SPSR      0x1
#define TXFIFO    0x2
#define RXFIFO    0x2
#define SPER      0x3
#define PARAM     0x4
#define SOFTCS    0x5
#define PARAM2    0x6
#define APB_SPCS  0x4

#define RFEMPTY 1

/*LS2K300 SPI registers */ 
#define LS2K300_SPI_CR1	0x00
#define LS2K300_SPI_CR2	0x04
#define LS2K300_SPI_CR3	0x08
#define LS2K300_SPI_CR4	0x0c
#define LS2K300_SPI_IER	0x10
#define LS2K300_SPI_SR1	0x14
#define LS2K300_SPI_SR2	0x18
#define LS2K300_SPI_CFG1	0x20
#define LS2K300_SPI_CFG2	0x24
#define LS2K300_SPI_CFG3	0x28
#define LS2K300_SPI_CRC1	0x30
#define LS2K300_SPI_CRC2	0x34
#define LS2K300_SPI_DR		0x40

/* LS2K300_SPI_CR1 bit fields */
#define SPI_CR1_SPE		0
#define SPI_CR1_CSTART          1
#define SPI_CR1_AUTOSUS		2
#define SPI_CR1_SSREV           8

/* LS2K300_SPI_CR2 bit fields */
#define SPI_CR2_RXFTHLV		0 //[1:0]
#define SPI_CR2_RXDMAEN		7
#define SPI_CR2_TXFTHLV		8 //[9:8]
#define SPI_CR2_TXDMAEN		15

/* LS2K300_SPI_IER bit fields */
#define SPI_IER_RXAIE		0
#define SPI_IER_TXAIE		1
#define SPI_IER_DXAIE		2
#define SPI_IER_RXEIE		4
#define SPI_IER_TXEIE		5
#define SPI_IER_SUSPIE		7
#define SPI_IER_OVRIE		8
#define SPI_IER_UDRIE		9
#define SPI_IER_CRCEIE		10
#define SPI_IER_MODFIE		11
#define SPI_IER_EOTIE		15

/* LS2K300_SPI_SR1 bit fields */
#define SPI_SR1_RXA		0
#define SPI_SR1_TXA		1
#define SPI_SR1_DXA		2
#define SPI_SR1_RXE		4
#define SPI_SR1_TXE		5
#define SPI_SR1_SUSP		7
#define SPI_SR1_OVR		8
#define SPI_SR1_UDR		9
#define SPI_SR1_CRCE		10
#define SPI_SR1_MODF		11
#define SPI_SR1_EOT		15

/* LS2K300_SPI_SR2 bit fields */
#define SPI_SR2_RXFLV		0 //[2:0]
#define SPI_SR2_TXFLV		8 //[10:8]

/* LS2K300_SPI_CFG1 bit fields */
#define SPI_CFG1_CPOL		0
#define SPI_CFG1_CPHA		1
#define SPI_CFG1_LSBFRST	7
#define SPI_CFG1_DSIZE		8 //[12:8]

/* LS2K300_SPI_CFG2 bit fields */
#define SPI_CFG2_BRDEC		0 //[7:0]
#define SPI_CFG2_BRINT		8 //[15:8]

/* LS2K300_SPI_CFG3 bit fields */
#define SPI_CFG3_MSTR		0
#define SPI_CFG3_DIOSWP		1
#define SPI_CFG3_DIE		2
#define SPI_CFG3_DOE		3
#define SPI_CFG3_SSMODE		8 //[9:8]

/* LS2K300_SPI_CRC1 bit fields */
#define SPI_CRC1_CRCEN		0
#define SPI_CRC1_CRCPOLY	1 //[31:1]

/* LS2K300_SPI_CRC2 bit fields */
#define SPI_CRC2_RCRCINI	0
#define SPI_CRC2_TCRCINI	1
#define SPI_CRC2_CRCSIZE	8 //[12:8]

#define SET_SPI_IO(addr,val)		writel(val, ls_spi_base_io + addr)
#define GET_SPI_IO(addr)		readl(ls_spi_base_io + addr)
#define SET_SPI_IO_BYTE(addr,val)	writeb(val, ls_spi_base_io + addr)
#define GET_SPI_IO_BYTE(addr)		readb(ls_spi_base_io + addr)

#define SET_CE_IO(x)									\
do {											\
} while(0)

void iomux_cfg(uint64_t io_base, uint8_t pin_no, uint8_t pin_num, uint8_t mux)
{
   //TIPS!!
   //io_base : sys's io-pads mux config base addr(fixed-addr: CBUS_SB_GPIOCFG0)
   //pin_no  : the no. of the first io-pad need be config as multi-used(the GPIO-NO.)
   //pin_num : the number of all io-pads need be config as multi-used(NOTE!!! the max=16 when pin_no=0/16/32...,
   //                                                                         others the pin_no + pin_num cannot beyond the border of each cfg-reg,
   //                                                                         then the value need be divided by 16-multi and configured more times.)
   //mux     : the iomux value need be config(0-gpio, 1-io1st, 2-io2nd, 3-prime)

   uint64_t cfg_addr;
   uint32_t val, mask_i=0, mask, cfg_value, i, j=0;
   uint32_t zero=0x0, io1st=0x55555555, io2nd=0xaaaaaaaa, prime=0xffffffff;

   cfg_addr = io_base + (pin_no/16)*0x4;
   for (i=0; i<pin_num; i++) {
      mask_i = mask_i | (0x3 << j*2);
      j++;

      if ((i==(pin_num-1)) || (((pin_no+i+1)%16)==0)) {
         if (((pin_no%16)+i) >= 16) {
            mask = mask_i;
         } else {
            mask = mask_i << (pin_no%16)*2;
         }
         mask_i = 0;

         if      (mux == 0) cfg_value = zero ;
         else if (mux == 1) cfg_value = io1st;
         else if (mux == 2) cfg_value = io2nd;
         else               cfg_value = prime;

         val = ((READ_REG32(cfg_addr)) & ~mask)|(cfg_value & mask);
         WRITE_REG32(cfg_addr, val);

         cfg_addr = cfg_addr + 0x4;
         j = 0;
      }
   }
}

void spi_io_initw(void)
{
    printf("spi init---->>>ls_spi_base_io=0x%x\n",ls_spi_base_io);
	/*pin set,master mode and full duplex*/
	//SET_SPI_IO(LS2K300_SPI_CFG3, 0x10d); //MSTR:1 DIOSWP:0 DIE:1 DOE:1 SSMODE:1
	SET_SPI_IO(LS2K300_SPI_CFG3, 0x00d); //MSTR:1 DIOSWP:0 DIE:1 DOE:1 SSMODE:0
	printf("CFG3 val 0x%x\n", GET_SPI_IO(LS2K300_SPI_CFG3));
	/*set clk rate */
	SET_SPI_IO(LS2K300_SPI_CFG2,0x0800); //BRINT:8 BRDEC:0
	/*set transfer format*/
	//SET_SPI_IO(LS2K300_SPI_CFG1,0x780); //CPOL:0 CPHA:0 LSBFRST:1 DSIZE:7
	SET_SPI_IO(LS2K300_SPI_CFG1,0x700); //CPOL:0 CPHA:0 LSBFRST:0 DSIZE:7
}

void slave_spi_io_initw(void)
{
    //printf("spi init---->>>slvae ls_spi_base_io=0x%x\n",ls_spi_base_io);
	/*pin set,slave mode and full duplex*/
	SET_SPI_IO(LS2K300_SPI_CFG3, 0x00c); //MSTR:0 DIOSWP:0 DIE:1 DOE:1 SSMODE:0
	printf("CFG3 val 0x%x\n", GET_SPI_IO(LS2K300_SPI_CFG3));
	/*set clk rate */
	SET_SPI_IO(LS2K300_SPI_CFG2,0x0800); //BRINT:8 BRDEC:0
	/*set transfer format*/
	//SET_SPI_IO(LS2K300_SPI_CFG1,0x780); //CPOL:0 CPHA:0 LSBFRST:1 DSIZE:7
	SET_SPI_IO(LS2K300_SPI_CFG1,0x700); //CPOL:0 CPHA:0 LSBFRST:0 DSIZE:7
}

int send_spi_cmd_io(unsigned char command)
{
	int timeout = 1000;
	unsigned char val;

	SET_SPI_IO(LS2K300_SPI_CR1,(0x1 << SPI_CR1_SPE) | (1 << SPI_CR1_CSTART) | (0x1 << SPI_CR1_AUTOSUS));

	while((((GET_SPI_IO(LS2K300_SPI_SR1) >> 1) & 0x1) == 0) && timeout--);

	if (timeout < 0) {
		printf("wait rxa timeout! sr1 0x%x\n",GET_SPI_IO(LS2K300_SPI_SR1));
		return -1;
	}

	SET_SPI_IO_BYTE(LS2K300_SPI_DR, command);

	timeout = 1000;
	while(((GET_SPI_IO(LS2K300_SPI_SR1) & 0x1) == 0) && timeout--);

	if (timeout < 0) {
		printf("wait rxa timeout! sr1 0x%x\n",GET_SPI_IO(LS2K300_SPI_SR1));
		return -1;
	}
	val = GET_SPI_IO_BYTE(LS2K300_SPI_DR);
	return val;
}

void spi_read_id_io(void)
{
	unsigned char val;

	spi_io_initw();
	/*send 1 bytes*/
	SET_SPI_IO(LS2K300_SPI_CR3, 0x00);

	/*spi disable*/
	SET_SPI_IO(LS2K300_SPI_CR1, (1 << SPI_CR1_SSREV) | (0x1 << SPI_CR1_SPE) | (0x1 << SPI_CR1_AUTOSUS));

	/*spi enable*/
	SET_SPI_IO(LS2K300_SPI_CR1,(0x1 << SPI_CR1_SPE));

	/*READ ID CMD*/
	send_spi_cmd_io(0x90);
	/*address bit [23-0]*/
	send_spi_cmd_io(0x00);
	send_spi_cmd_io(0x00);
	send_spi_cmd_io(0x00);

	/*Manufacturer’s ID*/
	val = send_spi_cmd_io(0x00);
	printf("Device ID:                 %x\n",val);
	/*Device ID*/
	val = send_spi_cmd_io(0);
	printf("Device ID:                 %x\n",val);

	/*spi disable*/
	SET_SPI_IO(LS2K300_SPI_CR1, (1 << SPI_CR1_SSREV) | (0x1 << SPI_CR1_SPE) | (0x1 << SPI_CR1_AUTOSUS));
	//printf("SR1 0x%x\n",GET_SPI_IO(LS2K300_SPI_SR1));
}

void spi_jedec_id_io(void)
{
	unsigned char val;

	spi_io_initw();
	/*send 1 bytes*/
	SET_SPI_IO(LS2K300_SPI_CR3, 0x00);

	/*spi disable*/
	SET_SPI_IO(LS2K300_SPI_CR1, (1 << SPI_CR1_SSREV) | (0x1 << SPI_CR1_SPE) | (0x1 << SPI_CR1_AUTOSUS));

	/*spi enable*/
	SET_SPI_IO(LS2K300_SPI_CR1,(0x1 << SPI_CR1_SPE));

	/*JEDEC ID CMD*/
	send_spi_cmd_io(0x9f);

	/*Manufacturer’s ID*/
	val = send_spi_cmd_io(0x00);
	printf("Manufacturer's ID:         %x\n",val);

	/*Device ID:Memory Type*/
	val = send_spi_cmd_io(0x00);
 	printf("Device ID-memory_type:     %x\n",val);

	/*Device ID:Memory Capacity*/
	val = send_spi_cmd_io(0x00);
	printf("Device ID-memory_capacity: %x\n",val);

	/*spi disable*/
	SET_SPI_IO(LS2K300_SPI_CR1, (1 << SPI_CR1_SSREV) | (0x1 << SPI_CR1_SPE) | (0x1 << SPI_CR1_AUTOSUS));
}


int set_spi_io_base(int ac, unsigned char *av[])
{
	uint32_t bus_num;
	char dev_name[5] = "spi0";
	if(ac != 2) {
		printf("spi_base <spi bus num: 0/1/2...>\n");
		return 0;
	}
	bus_num = (uint32_t)strtoul(av[1], NULL, 0);
	dev_name[3] += bus_num;
	if (bus_num < 2 || bus_num > 3) {
		printf("error spi bus num: %d\n", bus_num);
		return 0;
	} else {
		switch(bus_num) {
			case 2:
				ls_spi_base_io = LS2K300_SPI2_BASE;
                iomux_cfg((CBUS_SB_GPIOCFG0), 64, 4, 3);
                printf("\r\n spi2");
				break;
			case 3:
				ls_spi_base_io = LS2K300_SPI3_BASE;
                iomux_cfg((CBUS_SB_GPIOCFG0), 82, 4, 1);
                printf("\r\n spi3");
				break;
			default:
				ls_spi_base_io = LS2K300_SPI2_BASE;
                iomux_cfg((CBUS_SB_GPIOCFG0), 64, 4, 3);
                printf("\r\n spi2");
                break;
		}
	}
	return 0;
}

int set_spi_io_base_test(int ac, unsigned char *av[])
{
	uint32_t bus_num;
	char dev_name[5] = "spi0";
	if(ac != 2) {
		printf("spi_base <spi bus num: 0/1/2...>\n");
		return 0;
	}
	bus_num = (uint32_t)strtoul(av[1], NULL, 0);
	dev_name[3] += bus_num;
	if (bus_num < 2 || bus_num > 3) {
		printf("error spi bus num: %d\n", bus_num);
		return 0;
	} else {
		switch(bus_num) {
			case 2:
				ls_spi_base_io = LS2K300_SPI2_BASE;
                printf("\r\n spi2");
				break;
			case 3:
				ls_spi_base_io = LS2K300_SPI3_BASE;
                printf("\r\n spi3");
				break;
			default:
				ls_spi_base_io = LS2K300_SPI2_BASE;
                printf("\r\n spi2");
                break;
		}
	}
	return 0;
}

int spi_test(int ac, unsigned char *av[])
{
	unsigned char val, val_master[5] = {0}, val_slave[5] = {0};
	unsigned int i;
	unsigned int mode;
	
	if(ac != 2) {
		printf("spi_test <mode 1:spi2ms/spi3sl 0:spi2sl/spi3ms>\n");
		return 0;
	}
	mode = (uint32_t)strtoul(av[1], NULL, 0);

	if (mode) {
		/*init spi2 as master*/
		ls_spi_base_io = LS2K300_SPI2_BASE ;
		iomux_cfg((CBUS_SB_GPIOCFG0), 64, 4, 3);
	} else {
		/*init spi3 as master*/
		ls_spi_base_io = LS2K300_SPI3_BASE ;
		iomux_cfg((CBUS_SB_GPIOCFG0), 82, 4, 1);
	}
	spi_io_initw();

	if (mode) {
		ls_spi_base_io = LS2K300_SPI3_BASE;
		iomux_cfg((CBUS_SB_GPIOCFG0), 82, 4, 1);
	} else {
		/*init spi2 as slave*/
		ls_spi_base_io = LS2K300_SPI2_BASE;
		iomux_cfg((CBUS_SB_GPIOCFG0), 64, 4, 3);
	}
	/*init spi3 as slave*/
	slave_spi_io_initw();

	//SET_SPI_IO(LS2K300_SPI_CR1,(0x1 << SPI_CR1_SPE) | (1 << SPI_CR1_CSTART));
	SET_SPI_IO(LS2K300_SPI_CR1,(0x1 << SPI_CR1_SPE));
	SET_SPI_IO_BYTE(LS2K300_SPI_DR, 0x11);
	SET_SPI_IO_BYTE(LS2K300_SPI_DR, 0x22);
	SET_SPI_IO_BYTE(LS2K300_SPI_DR, 0x33);
	SET_SPI_IO_BYTE(LS2K300_SPI_DR, 0x44);
	SET_SPI_IO_BYTE(LS2K300_SPI_DR, 0x55);

	for(i = 0; i < 5; i++) {
		ls_spi_base_io = ((mode == 1) ? LS2K300_SPI2_BASE : LS2K300_SPI3_BASE);
		SET_SPI_IO(LS2K300_SPI_CR1,(0x1 << SPI_CR1_SPE) | (1 << SPI_CR1_CSTART) | (0x1 << SPI_CR1_AUTOSUS));
		while(((GET_SPI_IO(LS2K300_SPI_SR1) >> 1) & 0x1) == 0);
		SET_SPI_IO_BYTE(LS2K300_SPI_DR, ((i + 6)) << 4 | (i + 6));
		while(((GET_SPI_IO(LS2K300_SPI_SR1) >> 0) & 0x1) == 0);
		val_master[i] = GET_SPI_IO_BYTE(LS2K300_SPI_DR);
	
		ls_spi_base_io = ((mode == 1) ? LS2K300_SPI3_BASE : LS2K300_SPI2_BASE);
		while(((GET_SPI_IO(LS2K300_SPI_SR1) >> 0) & 0x1) == 0);
		val_slave[i] = GET_SPI_IO_BYTE(LS2K300_SPI_DR);
	}
    i = ((mode == 1) ? 2 : 3);
	printf("spi%d master val",i);
	for(i = 0; i < 5; i++) {
		printf("0x%x ",val_master[i]);
	}
	printf("\n");

    i = ((mode == 1) ? 3 : 2);
	printf("spi%d slave val",i);
	for(i = 0; i < 5; i++) {
		printf("0x%x ",val_slave[i]);
	}
	printf("\n");
	return 0;
}
#if 0
void spi_io_initw_dma(void)
{
    printf("spi init---->>>ls_spi_base_io=0x%x\n",ls_spi_base_io);
	/*pin set,master mode and full duplex*/
	//SET_SPI_IO(LS2K300_SPI_CFG3, 0x10d); //MSTR:1 DIOSWP:0 DIE:1 DOE:1 SSMODE:1
	SET_SPI_IO(LS2K300_SPI_CFG3, 0x00d); //MSTR:1 DIOSWP:0 DIE:1 DOE:1 SSMODE:0
	printf("CFG3 val 0x%x\n", GET_SPI_IO(LS2K300_SPI_CFG3));
	/*set clk rate */
	SET_SPI_IO(LS2K300_SPI_CFG2,0x0800); //BRINT:8 BRDEC:0
	/*set transfer format*/
	//SET_SPI_IO(LS2K300_SPI_CFG1,0x780); //CPOL:0 CPHA:0 LSBFRST:1 DSIZE:7
	SET_SPI_IO(LS2K300_SPI_CFG1,0x700); //CPOL:0 CPHA:0 LSBFRST:0 DSIZE:7

	SET_SPI_IO(LS2K300_SPI_CR3,23); //tsize
	SET_SPI_IO(LS2K300_SPI_CR2,0x8383); //tx rx dma_en  TXFTHLV:0x11  RXFTHLV:0x11
}
void slave_spi_io_initw_dma(void)
{
    //printf("spi init---->>>slvae ls_spi_base_io=0x%x\n",ls_spi_base_io);
	/*pin set,slave mode and full duplex*/
	SET_SPI_IO(LS2K300_SPI_CFG3, 0x00c); //MSTR:0 DIOSWP:0 DIE:1 DOE:1 SSMODE:0
	printf("CFG3 val 0x%x\n", GET_SPI_IO(LS2K300_SPI_CFG3));
	/*set clk rate */
	SET_SPI_IO(LS2K300_SPI_CFG2,0x0800); //BRINT:8 BRDEC:0
	/*set transfer format*/
	//SET_SPI_IO(LS2K300_SPI_CFG1,0x780); //CPOL:0 CPHA:0 LSBFRST:1 DSIZE:7
	SET_SPI_IO(LS2K300_SPI_CFG1,0x700); //CPOL:0 CPHA:0 LSBFRST:0 DSIZE:7
	SET_SPI_IO(LS2K300_SPI_CR3,23); //tsize
	SET_SPI_IO(LS2K300_SPI_CR2,0x8383); //tx rx dma_en  TXFTHLV:0x11  RXFTHLV:0x11
}

unsigned char __attribute__((__aligned__(32))) str_transmit1[24] = "This is spi test! ~0v0~\n";
unsigned char __attribute__((__aligned__(32))) str_transmit2[24] = "Write by hjr @ loongson\n";
unsigned char __attribute__((__aligned__(32))) str_receive1[24];
unsigned char __attribute__((__aligned__(32))) str_receive2[24];

void spi_dma_rx_cfg(int num, uint32_t buf_addr,int size)
{
    DMA_InitTypeDef  DMA_InitStructure;
    uint32_t SPIx_DR_BASE;
    DMA_Channel_TypeDef* DMA1_Channelx;
    
    SPIx_DR_BASE = (SPI_BASE + num * 0x2000 + 0x40);
    switch(num){
      case 0x1: DMA1_Channelx = DMA1_Channel3_BASE; break;
      default:  DMA1_Channelx = DMA1_Channel1_BASE; break;
    }
    // SPI RX
    DMA_DeInit(DMA1_Channelx);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)(SPIx_DR_BASE);
    DMA_InitStructure.DMA_MemoryBaseAddr = ((u32)buf_addr);
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.DMA_BufferSize = size;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channelx, &DMA_InitStructure);
    DMA_Cmd(DMA1_Channelx, ENABLE);
}

void spi_dma_tx_cfg(int num, uint32_t buf_addr,int size)
{
    DMA_InitTypeDef  DMA_InitStructure;
    uint32_t SPIx_DR_BASE;
    DMA_Channel_TypeDef* DMA1_Channelx;
    
    SPIx_DR_BASE = (SPI_BASE + num * 0x2000 + 0x40);
    switch(num){
      case 0x1: DMA1_Channelx = DMA1_Channel4_BASE; break;
      default:  DMA1_Channelx = DMA1_Channel2_BASE; break;
    }
    // SPI TX
    DMA_DeInit(DMA1_Channelx);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)(SPIx_DR_BASE);
    DMA_InitStructure.DMA_MemoryBaseAddr = ((u32)buf_addr);
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = size;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channelx, &DMA_InitStructure);
    DMA_Cmd(DMA1_Channelx, ENABLE);
}

int spi_dma(int ac, unsigned char *av[])
{
	unsigned char val, val_master[5] = {0}, val_slave[5] = {0};
	unsigned int i;
	unsigned int mode;
	int timeout = 1000;
	
	if(ac != 2) {
		printf("spi_test <mode 1:spi2ms/spi3sl 0:spi2sl/spi3ms>\n");
		return 0;
	}
	mode = (uint32_t)strtoul(av[1], NULL, 0);

    uint32_t tlen = (uint32_t)(sizeof(str_receive1)/4);
	if (mode) {
		/*init spi2 as master*/
		ls_spi_base_io = LS2K300_SPI2_BASE ;
		iomux_cfg((CBUS_SB_GPIOCFG0), 64, 4, 3);
	} else {
		/*init spi3 as master*/
		ls_spi_base_io = LS2K300_SPI3_BASE ;
		iomux_cfg((CBUS_SB_GPIOCFG0), 82, 4, 1);
	}
	spi_io_initw_dma();

	if (mode) {
		ls_spi_base_io = LS2K300_SPI3_BASE;
		iomux_cfg((CBUS_SB_GPIOCFG0), 82, 4, 1);
	} else {
		/*init spi2 as slave*/
		ls_spi_base_io = LS2K300_SPI2_BASE;
		iomux_cfg((CBUS_SB_GPIOCFG0), 64, 4, 3);
	}
	/*init spi3 as slave*/
	slave_spi_io_initw_dma();
    spi_dma_tx_cfg(1, str_transmit1,tlen);
	SET_SPI_IO(LS2K300_SPI_CR1,(0x1 << SPI_CR1_SPE));
	while((((GET_SPI_IO(LS2K300_SPI_SR1) >> 4) & 0x3) == 0) && timeout--);
	if (timeout < 0) {
		printf("wait txtfifo empty timeout! sr1 0x%x\n",GET_SPI_IO(LS2K300_SPI_SR1));
		SET_SPI_IO(LS2K300_SPI_CR1,(0x0 << SPI_CR1_SPE));
		return -1;
	}

	ls_spi_base_io = ((mode == 1) ? LS2K300_SPI2_BASE : LS2K300_SPI3_BASE);
	spi_dma_tx_cfg(0, str_transmit2,tlen);
	spi_dma_rx_cfg(1, str_receive2,tlen);
	spi_dma_rx_cfg(0, str_receive1,tlen);
	SET_SPI_IO(LS2K300_SPI_CR1,(0x1 << SPI_CR1_SPE) | (1 << SPI_CR1_CSTART) | (0x1 << SPI_CR1_AUTOSUS));
	while((((GET_SPI_IO(LS2K300_SPI_SR1) >> 4) & 0x3) == 0) && timeout--);
	if (timeout < 0) {
		printf("wait rxfifo or txtfifo empty timeout! sr1 0x%x\n",GET_SPI_IO(LS2K300_SPI_SR1));
		SET_SPI_IO(LS2K300_SPI_CR1,(0x0 << SPI_CR1_SPE));
		return -1;
	}
    str_receive1[tlen*4] = '\0';
    str_receive2[tlen*4] = '\0';

    i = ((mode == 1) ? 2 : 3);
	printf("spi%d master val",i);
	printf("\n");
    printf("%s ",str_receive1);
    i = ((mode == 1) ? 3 : 2);
	printf("spi%d slave val",i);
	printf("\n");
    printf("%s ",str_receive2);
	return 0;
}
#endif

static const Cmd Cmds[] =
{
	{"MyCmds"},
	{"spi_io_base", "", NULL, "set spi base", set_spi_io_base , 0, 99, 1},
	{"spi_io_base_test", "", NULL, "set spi base", set_spi_io_base_test , 0, 99, 1},
	{"spi_io_initw","",0,"spi_io_initw",spi_io_initw,0,99,CMD_REPEAT},
	{"read_flash_id_io","",0,"read_flash_id",spi_read_id_io,0,99,CMD_REPEAT},
	{"spi_id_io","",0,"read_flash_id",spi_jedec_id_io,0,99,CMD_REPEAT},
	{"spi_test", "", NULL, "spi master slave test", spi_test , 0, 99, 1},
//	{"spi_dma", "", NULL, "spi master slave test", spi_dma , 0, 99, 1},
	{0,0}
};

static void init_cmd __P((void)) __attribute__ ((constructor));

static void
init_cmd()
{
	cmdlist_expand(Cmds,1);
}
