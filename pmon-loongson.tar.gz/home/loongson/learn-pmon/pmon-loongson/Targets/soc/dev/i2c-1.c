/*
 * For loongson7a dc controller dvo1 i2c
 * Use gpio to access ch7034 chip
 * */

#include <pmon.h>
#include <stdio.h>
#include "target/ls2k1000.h"
static long long LS2K_I2C_BASE=LS2K1000_I2C1_REG_BASE;//I2C1


#define SCL1	3
#define	SDA1	2

#define SCL0	1
#define	SDA0	0

#define	LOW	0
#define HIGH	1

#define	OUT	0
#define	IN	1

#define CHIP_7034_ADDR	0xea
#define CHIP_9022_ADDR	0x72
#define	LT8618SX_ADR	0x3b


static unsigned long  dc_base = 0;
static unsigned long  gpio_val_base = 0;
static unsigned long  gpio_dir_base = 0;

unsigned char CH7034_VGA_REG_TABLE2[][131][2] = {
      {	//mtfvga
      //IN 800x600,out 800x600,ch7034,bypassmode vga,mode_idx=1
          { 0x03, 0x04 },//page 4
          { 0x52, 0xC3 },
          { 0x5A, 0x06 },
          { 0x5A, 0x04 },
          { 0x5A, 0x06 },
          { 0x52, 0xC1 },
          { 0x52, 0xC3 },
          { 0x5A, 0x04 },

          { 0x03, 0x00 },//page 1
          { 0x07, 0xD9 },
          { 0x08, 0xF1 },
          { 0x09, 0x13 },
          { 0x0A, 0xBE },
          { 0x0B, 0x23 },
          { 0x0C, 0x20 },
          { 0x0D, 0x20 },
          { 0x0E, 0x00 },
          { 0x0F, 0x28 },
          { 0x10, 0x80 },
          { 0x11, 0x12 },
          { 0x12, 0x58 },
          { 0x13, 0x74 },
          { 0x14, 0x00 },
          { 0x15, 0x01 },
          { 0x16, 0x04 },
          { 0x17, 0x00 },
          { 0x18, 0x00 },//mtf modify 888RGB
         // { 0x18, 0x20 },//565RGB
//          { 0x18, 0x02 },//888GRB
          { 0x19, 0xF8 },//freq
          { 0x1A, 0x9B },
          { 0x1B, 0x78 },
          { 0x1C, 0x69 },
          { 0x1D, 0x78 },
          { 0x1E, 0x00 },//output is  progressive
          { 0x1F, 0x23 },
          { 0x20, 0x20 },
          { 0x21, 0x20 },
          { 0x22, 0x00 },
          { 0x23, 0x10 },
          { 0x24, 0x60 },
          { 0x25, 0x12 },
          { 0x26, 0x58 },
          { 0x27, 0x74 },
          { 0x28, 0x00 },
          { 0x29, 0x0A },
          { 0x2A, 0x02 },
          { 0x2B, 0x09 },//vga output format:bypass mode
          { 0x2C, 0x00 },
          { 0x2D, 0x00 },
          { 0x2E, 0x3D },
          { 0x2F, 0x00 },//??
          { 0x32, 0xC0 },//???
          { 0x36, 0x40 },
          { 0x38, 0x47 },
          { 0x3D, 0x86 },
          { 0x3E, 0x00 },
          { 0x40, 0x0E },
          { 0x4B, 0x40 },//pwm control
          { 0x4C, 0x40 },//lvds output channel order register
          { 0x4D, 0x80 },
          { 0x54, 0x80 },//lvds
          { 0x55, 0x28 },//lvds
          { 0x56, 0x80 },//lvds
          { 0x57, 0x00 },//lvds
          { 0x58, 0x01 },//lvds
          { 0x59, 0x04 },//lvds
          { 0x5A, 0x02 },
          { 0x5B, 0xF2 },
          { 0x5C, 0xB9 },
          { 0x5D, 0xD6 },
          { 0x5E, 0x54 },
          { 0x60, 0x00 },
          { 0x61, 0x00 },
          { 0x64, 0x2D },
          { 0x68, 0x44 },
          { 0x6A, 0x40 },
          { 0x6B, 0x00 },
          { 0x6C, 0x10 },
          { 0x6D, 0x00 },
          { 0x6E, 0xA0 },
          { 0x70, 0x98 },
          { 0x74, 0x30 },//scaling control
          { 0x75, 0x80 },//scaling control
          { 0x7E, 0x0F },//de and pwm control
          { 0x7F, 0x00 },//test pattern

          { 0x03, 0x01 },//page 2
          { 0x08, 0x05 },
          { 0x09, 0x04 },//diffen register
          { 0x0B, 0x65 },
          { 0x0C, 0x4A },
          { 0x0D, 0x29 },
          { 0x0F, 0x9C },
          { 0x12, 0xD4 },
          { 0x13, 0x28 },
          { 0x14, 0x83 },
          { 0x15, 0x00 },
          { 0x16, 0x00 },
          { 0x1A, 0x6C },//DAC termination control register
          { 0x1B, 0x00 },
          { 0x1C, 0x00 },
          { 0x1D, 0x00 },
          { 0x23, 0x63 },
          { 0x24, 0xB4 },
          { 0x28, 0x54 },
          { 0x29, 0x60 },
          { 0x41, 0x60 },//lvds
          { 0x63, 0x2D },//DE polarity
          { 0x6B, 0x11 },
          { 0x6C, 0x06 },

          { 0x03, 0x03 },//page3
          { 0x26, 0x00 },
          { 0x28, 0x08 },//output control:DAC output is VGA
          { 0x2A, 0x00 },//output control:HDTV output through scaler

          { 0x03, 0x04 },//page 4
          { 0x10, 0x00 },
          { 0x11, 0x9B },
          { 0x12, 0x78 },
          { 0x13, 0x02 },
          { 0x14, 0x88 },
          { 0x15, 0x70 },
          { 0x20, 0x00 },
          { 0x21, 0x00 },
          { 0x22, 0x00 },
          { 0x23, 0x00 },
          { 0x24, 0x00 },
          { 0x25, 0x00 },
          { 0x26, 0x00 },
          { 0x54, 0xC4 },
          { 0x55, 0x5B },
          { 0x56, 0x4D },
          { 0x60, 0x01 },
          { 0x61, 0x62 },
      },
};
#define  gpioi2c_write(chip, reg, val) 				\
		do { 										\
				data = val; 						\
				i2c_write(chip, reg, 1, &data, 1); 	\
		} while (0)

#define  gpioi2c_read(chip, reg, data) 				\
		do { 										\
				i2c_read(chip, reg, 1, data, 1); 	\
		} while(0);



#define CH7034_REGMAP_LENGTH_VGA (sizeof(CH7034_VGA_REG_TABLE2[0]) / (2*sizeof(unsigned char)))

static void dvo1_gpioi2c_write(int ac, unsigned char *av[])
{
	unsigned char dev_addr = CHIP_7034_ADDR;
	unsigned char data_addr;
	unsigned char data;

	switch (ac) {
	case 3:
		data_addr = strtoul(av[1], NULL, 0);
		data = strtoul(av[2], NULL, 0);

		gpioi2c_write(dev_addr, data_addr, data);
		printf("0x%2x <= 0x%2x \n", data_addr, data);

		break;
	default:
		printf("need 3 param: gw1 3 4");
		break;
	}
}

static void dvo1_gpioi2c_read(int ac, unsigned char *av[])
{
	/* bit0 :1 read, 0 write */
	unsigned char dev_addr = CHIP_7034_ADDR;
	unsigned char data_addr;
	unsigned char ret_val;

	switch (ac) {
	case 2:
		data_addr = strtoul(av[1], NULL, 0);
		gpioi2c_read(dev_addr, data_addr, &ret_val);
		printf("0x%2x : 0x%2x\n", data_addr, ret_val);
		break;
	default:
		printf("need 2 param: gr1 0");
		break;
	}
}

void gpioi2c_config_ch7034()
{
	int count;
	unsigned char dev_addr = CHIP_7034_ADDR;
	unsigned char data_addr;
	unsigned char data;
	unsigned char data2;

	/* get reg base addr */
	//gpioi2c_init();
	ls2k_i2c_init(0, LS2K_I2C_BASE);

	for (count = 0; count < CH7034_REGMAP_LENGTH_VGA; count++)
	{
		data_addr = CH7034_VGA_REG_TABLE2[0][count][0];
		data = CH7034_VGA_REG_TABLE2[0][count][1];

		gpioi2c_write(dev_addr, data_addr, data);
#if DEBUG_CH7034
		gpioi2c_read(dev_addr, data_addr, &data2);

		if (data != data2)
			printf("not eq, data 0x%2x, data2 0x%2x\n\n\n", data, data2);
#endif
	}
}

void gpioi2c_config_sii9022a(void)
{
	unsigned char id0;
	unsigned char id1;
	unsigned char id2;
	unsigned char data;

	unsigned char dev_addr = CHIP_9022_ADDR;

	//gpioi2c_init();
	ls2k_i2c_init(0, LS2K_I2C_BASE);

	gpioi2c_write(dev_addr, 0xc7, 0x00);
	gpioi2c_read(dev_addr, 0x1b, &id0);
	gpioi2c_read(dev_addr, 0x1c, &id1);
	gpioi2c_read(dev_addr, 0x1d, &id2);

	if (id0 != 0xb0 || id1 != 0x2 || id2 != 0x3) {
		printf("id err\n");
		return;
	}

	gpioi2c_read(dev_addr, 0x1e, &data);
	data &= ~(0x3);
	gpioi2c_write(dev_addr, 0x1e, data);

	gpioi2c_read(dev_addr, 0x1a, &data);
	data &= ~(1 << 4);
	data |= (1 << 0);
	gpioi2c_write(dev_addr, 0x1a, data);
	gpioi2c_write(dev_addr, 0x26, 0x40);
}

unsigned char Use_DDRCLK;

static unsigned char	LT8618SXB_PLL[3][3] =
{
	{ 0x00, 0x94, 0xaa },   // < 50MHz
	{ 0x00, 0x94, 0x99 },   // 50 ~ 100M
	{ 0x00, 0x94, 0x88 },   // > 100M
};
#define _DE_Sync_mode_                                  // DE + Hsync + Vsync
//#define _HV_mode_Only_ // only Hsync + Vsync, no DE
//#define _De_mode_Only_ // only DE, no Hsync & Vsync

#define _TTL_BGR_	0x70                                // B0~B7[D0:D7];G0~G7[D8:D15];R0~R7[D16:D23];
//#define _TTL_GBR_	0x60                                // G0~G7[D0:D7];B0~B7[D8:D15];R0~R7[D16:D23];
//#define _TTL_RBG_	0x40                                // R0~R7[D0:D7];B0~B7[D8:D15];G0~G7[D16:D23];
//#define _TTL_BRG_	0x50                                // B0~B7[D0:D7];R0~R7[D8:D15];G0~G7[D16:D23];
//#define _TTL_GRB_	0x30                                // G0~G7[D0:D7];R0~R7[D8:D15];B0~B7[D16:D23];
//#define _TTL_RGB_	0x00                                // R0~R7[D0:D7];G0~G7[D8:D15];B0~B7[D16:D23];


void LT8618SXB_I2C_Write_Byte(unsigned char RegAddr, unsigned char data)
{
    unsigned char dev_addr = LT8618SX_ADR;
	gpioi2c_write(dev_addr, RegAddr, data);
}

unsigned char LT8618SXB_I2C_Read_Byte(unsigned char RegAddr)
{
	unsigned char data;
    unsigned char dev_addr = LT8618SX_ADR;
	gpioi2c_read(dev_addr, RegAddr, &data); 
    return data;
}

void LT8618SXB_TTL_Input_Analog( void )
{
	// TTL mode
	LT8618SXB_I2C_Write_Byte(0xff, 0x81);     // register bank
	LT8618SXB_I2C_Write_Byte(0x02, 0x66);
	LT8618SXB_I2C_Write_Byte(0x0a, 0x06);
	LT8618SXB_I2C_Write_Byte(0x15, 0x06);

	LT8618SXB_I2C_Write_Byte(0x4e, 0xa8);     // for U2

	LT8618SXB_I2C_Write_Byte(0xff, 0x82);
	LT8618SXB_I2C_Write_Byte(0x1b, 0x77);
	LT8618SXB_I2C_Write_Byte(0x1c, 0xEC);     // 25000
}

void LT8618SXB_TTL_Input_Digtal( void )
{
	LT8618SXB_I2C_Write_Byte( 0xff, 0x80 );

#ifdef _HV_mode_Only_
	LT8618SXB_I2C_Write_Byte( 0x0A, 0xa0 );         // bit5=1 : Internal generate DE control logic clock enable
#else
#ifdef _De_mode_Only_
	LT8618SXB_I2C_Write_Byte( 0x0A, 0x90 );         // bit4=1 : Internal generate sync control logic clock enable
#else
	LT8618SXB_I2C_Write_Byte( 0x0A, 0x80 );         // normal
#endif
#endif

	// TTL_Input_Digtal
	LT8618SXB_I2C_Write_Byte( 0xff, 0x82 );         // register bank
	LT8618SXB_I2C_Write_Byte( 0x45, _TTL_BGR_);    //BGR channel swap
	//LT8618SXB_I2C_Write_Byte( 0x45, _TTL_BRG_);    //RGB channel swap

	if( Use_DDRCLK == 1 )
	{
		LT8618SXB_I2C_Write_Byte( 0x4f, 0x80 );     //0x00;  0x40: dclk
	}else
	{
		LT8618SXB_I2C_Write_Byte( 0x4f, 0x40 );     //0x00;  0x40: dclk
	}

	LT8618SXB_I2C_Write_Byte( 0x50, 0x00 );

#ifdef _HV_mode_Only_
	LT8618SXB_I2C_Write_Byte( 0x47, 0x87 );         // bit7=1 : TTL output de from internal generated signal enable
#else

#ifdef _De_mode_Only_
	LT8618SXB_I2C_Write_Byte( 0x47, 0x47 );         // bit6=1 : TTL output sync from internal generated signal enable
#endif

#endif
}
#if 0
void LT8618SXB_Video_Check( void )
{
	unsigned char	temp;
	unsigned char 	vs_pol, hs_pol;
	unsigned short	hfp, hs_width, hbp, h_act, h_tal, v_act, v_tal, vfp, vs_width, vbp;
	unsigned int	CLK_Cnt;

	vs_pol = 0;
	hs_pol = 0;

    delay(200);

	LT8618SXB_I2C_Write_Byte( 0xff, 0x82 ); //video check

	temp = LT8618SXB_I2C_Read_Byte( 0x70 ); //hs vs polarity

	if( temp & 0x02 )
	{
		vs_pol = 1;
	}
	if( temp & 0x01 )
	{
		hs_pol = 1;
	}

	vs_width = LT8618SXB_I2C_Read_Byte( 0x71 );

	hs_width = LT8618SXB_I2C_Read_Byte( 0x72 ) * 0x100 + LT8618SXB_I2C_Read_Byte( 0x73 );

	vbp	   = LT8618SXB_I2C_Read_Byte( 0x74 );
	vfp	   = LT8618SXB_I2C_Read_Byte( 0x75 );

	hbp = LT8618SXB_I2C_Read_Byte( 0x76 ) * 0x100 + LT8618SXB_I2C_Read_Byte( 0x77 );

	hfp = LT8618SXB_I2C_Read_Byte( 0x78 ) * 0x100 + LT8618SXB_I2C_Read_Byte( 0x79 );

	v_tal = LT8618SXB_I2C_Read_Byte( 0x7a ) * 0x100 + LT8618SXB_I2C_Read_Byte( 0x7b );

	h_tal = LT8618SXB_I2C_Read_Byte( 0x7c ) * 0x100 + LT8618SXB_I2C_Read_Byte( 0x7d );

	v_act = LT8618SXB_I2C_Read_Byte( 0x7e ) * 0x100 + LT8618SXB_I2C_Read_Byte( 0x7f );

	h_act = LT8618SXB_I2C_Read_Byte( 0x80 ) * 0x100 + LT8618SXB_I2C_Read_Byte( 0x81 );

	CLK_Cnt = ( LT8618SXB_I2C_Read_Byte( 0x1d ) & 0x0f ) * 0x10000 + LT8618SXB_I2C_Read_Byte( 0x1e ) * 0x100 + LT8618SXB_I2C_Read_Byte( 0x1f );
	// Pixel CLK =	CLK_Cnt * 1000

	printf( "\n\rh_FrontPorch = 0x%x",hfp);

	printf( "\r\nh_SyncWidth = 0x%x",hs_width );

	printf( "\r\nh_BackPorch = 0x%x",hbp );

	printf( "\r\nh_active = 0x%x",h_act );

	printf( "\r\nh_total = 0x%x",h_tal );

	printf( "\r\nv_FrontPorch = 0x%x",vfp );

	printf( "\r\nv_SyncWidth = 0x%x",vs_width );

	printf( "\r\nv_BackPorch = 0x%x",vbp );

	printf( "\r\nv_active = 0x%x",v_act );

	printf( "\r\nv_total = 0x%x" ,v_tal );
}
#endif 
void LT8618SXB_PLL_config( void )
{
	unsigned char	read_val;
	unsigned char	j;
	unsigned char	cali_done;
	unsigned char	cali_val;
	unsigned char	lock;

	//CLK_bound = (u8)Format_Timing[Resolution_Num][Clk_bound_SDR + (u8)( Use_DDRCLK )];
	unsigned char CLK_bound = 1; //Bound_50_100M

	LT8618SXB_I2C_Write_Byte( 0xff, 0x81 );
	LT8618SXB_I2C_Write_Byte( 0x23, 0x40 );
	LT8618SXB_I2C_Write_Byte( 0x24, 0x62 ); //icp set
	LT8618SXB_I2C_Write_Byte( 0x26, 0x55 );

	LT8618SXB_I2C_Write_Byte( 0x25, LT8618SXB_PLL[CLK_bound][0] );
	LT8618SXB_I2C_Write_Byte( 0x2c, LT8618SXB_PLL[CLK_bound][1] );
	LT8618SXB_I2C_Write_Byte( 0x2d, LT8618SXB_PLL[CLK_bound][2] );

	if( Use_DDRCLK ) {
		LT8618SXB_I2C_Write_Byte( 0x4d, 0x04 );
		LT8618SXB_I2C_Write_Byte( 0x27, 0x66 ); //0x60 //ddr 0x66
		LT8618SXB_I2C_Write_Byte( 0x28, 0x88 );
		printf( "PLL DDR\n\r" );
	} else {
		LT8618SXB_I2C_Write_Byte( 0x4d, 0x00 );
		LT8618SXB_I2C_Write_Byte( 0x27, 0x06 ); //0x06												//0x60 //ddr 0x66
		LT8618SXB_I2C_Write_Byte( 0x28, 0x00 ); // 0x88
		printf( "PLL SDR\n\r" );
	}

	LT8618SXB_I2C_Write_Byte( 0x29, 0x04 ); //for U3 for U3 SDR/DDR fixed phase


	LT8618SXB_I2C_Write_Byte( 0xff, 0x81 );

	read_val = LT8618SXB_I2C_Read_Byte( 0x2b );
	LT8618SXB_I2C_Write_Byte( 0x2b, read_val & 0xfd );  // sw_en_txpll_cal_en

	read_val = LT8618SXB_I2C_Read_Byte( 0x2e );
	LT8618SXB_I2C_Write_Byte( 0x2e, read_val & 0xfe );  //sw_en_txpll_iband_set

	LT8618SXB_I2C_Write_Byte( 0xff, 0x82 );
	LT8618SXB_I2C_Write_Byte( 0xde, 0x00 );
	LT8618SXB_I2C_Write_Byte( 0xde, 0xc0 );

	LT8618SXB_I2C_Write_Byte( 0xff, 0x80 );
	LT8618SXB_I2C_Write_Byte( 0x16, 0xf1 );
	LT8618SXB_I2C_Write_Byte( 0x18, 0xdc ); //txpll _sw_rst_n
	LT8618SXB_I2C_Write_Byte( 0x18, 0xfc );
	LT8618SXB_I2C_Write_Byte( 0x16, 0xf3 );

	LT8618SXB_I2C_Write_Byte( 0xff, 0x81 );
	
	if( Use_DDRCLK ) {
		LT8618SXB_I2C_Write_Byte( 0x2a, 0x10 );
		LT8618SXB_I2C_Write_Byte( 0x2a, 0x30 );
	}
	else {
		LT8618SXB_I2C_Write_Byte( 0x2a, 0x00 );
		LT8618SXB_I2C_Write_Byte( 0x2a, 0x20 );
	}


	for( j = 0; j < 0x02; j++ )
	{
		delay( 100 );
		LT8618SXB_I2C_Write_Byte( 0xff, 0x80 );
		LT8618SXB_I2C_Write_Byte( 0x16, 0xe3 ); /* pll lock logic reset */
		LT8618SXB_I2C_Write_Byte( 0x16, 0xf3 );

		LT8618SXB_I2C_Write_Byte( 0xff, 0x82 );
		lock	   = 0x80 & LT8618SXB_I2C_Read_Byte( 0x15 );
		cali_val   = LT8618SXB_I2C_Read_Byte( 0xea );
		cali_done  = 0x80 & LT8618SXB_I2C_Read_Byte( 0xeb );

		if( lock && cali_done && ( cali_val != 0xff ) )
		{
			printf( "TXPLL Lock\n\r" );
			return 0;
		}else
		{
			LT8618SXB_I2C_Write_Byte( 0xff, 0x80 );
			LT8618SXB_I2C_Write_Byte( 0x16, 0xf1 );
			LT8618SXB_I2C_Write_Byte( 0x18, 0xdc ); //txpll _sw_rst_n
			LT8618SXB_I2C_Write_Byte( 0x18, 0xfc );
			LT8618SXB_I2C_Write_Byte( 0x16, 0xf3 );
			printf( "TXPLL Reset\n\r" );
		}
	}

	printf( "TXPLL Unlock\n\r" );
}

// LT8618SXB only supports three color space convert: YUV422, yuv444 and rgb888.
// Color space convert of YUV420 is not supported.
void LT8618SXB_CSC_setting( void )
{
	// color space config
	LT8618SXB_I2C_Write_Byte( 0xff, 0x82 ); // register bank
//	LT8618SXB_I2C_Write_Byte( 0xb9, 0x08 );// YCbCr444 to RGB
//	LT8618SXB_I2C_Write_Byte( 0xb9, 0x18 );// YCbCr422 to RGB

//	LT8618SXB_I2C_Write_Byte( 0xb9, 0x80 );// RGB to YCbCr444
//	LT8618SXB_I2C_Write_Byte( 0xb9, 0xa0 );// RGB to YCbCr422

//	LT8618SXB_I2C_Write_Byte( 0xb9, 0x10 );// YCbCr422 to YCbCr444
//	LT8618SXB_I2C_Write_Byte( 0xb9, 0x20 );// YCbCr444 to YCbCr422

	LT8618SXB_I2C_Write_Byte( 0xb9, 0x00 ); // No csc
}

void LT8618SXB_AVI_setting( void )
{
	//AVI
	unsigned char	AVI_PB0	   = 0x00;
	unsigned char	AVI_PB1	   = 0x00;
	unsigned char	AVI_PB2	   = 0x00;
	unsigned char VIC_Num;
	/********************************************************************************
	   The 0x43 register is checksums,
	   changing the value of the 0x45 or 0x47 register,
	   and the value of the 0x43 register is also changed.
	   0x43, 0x44, 0x45, and 0x47 are the sum of the four register values is 0x6F.
	 *********************************************************************************/

//	VIC_Num = 0x04; // 720P 60; Corresponding to the resolution to be output
	VIC_Num = 0x10;	// 1080P 60
//	VIC_Num = 0x1F;	// 1080P 50
//	VIC_Num = 0x5F;	// 4K30

//================================================================//

	// Please refer to function: void LT8618SXB_CSC_setting( void )


	/****************************************************
	   Because the color space of RGB888 signal is RGB,
	   if lt8618sxb does not do color space convert (no CSC),
	   the color space of output HDMI is RGB.
	 *****************************************************/

	AVI_PB1 = 0x10;                                     // PB1,color space: YUV444 0x70;YUV422 0x30; RGB 0x10

//===============================================================//

//	AVI_PB2 = Format_Timing[Resolution_Num][Pic_Ratio]; // PB2; picture aspect rate
	AVI_PB2 = 0x2A; // PB2; picture aspect rate: 0x2A : 16:9 // Such as : 720P / 1080P / 40K30 / 1600x900
//	AVI_PB2 = 0x19; // PB2; picture aspect rate: 0x19 : 4:3 // Such as : 640x480 / 1024x768 / 1280x1024

	AVI_PB0 = ( ( AVI_PB1 + AVI_PB2 + VIC_Num ) <= 0x6f ) ? ( 0x6f - AVI_PB1 - AVI_PB2 - VIC_Num ) : ( 0x16f - AVI_PB1 - AVI_PB2 - VIC_Num );

	LT8618SXB_I2C_Write_Byte( 0xff, 0x84 );             // register bank
	LT8618SXB_I2C_Write_Byte( 0x43, AVI_PB0 );          // PB0,avi packet checksum
	LT8618SXB_I2C_Write_Byte( 0x44, AVI_PB1 );          // PB1,color space: YUV444 0x70;YUV422 0x30; RGB 0x10
	LT8618SXB_I2C_Write_Byte( 0x45, AVI_PB2 );          // PB2;picture aspect rate: 0x19:4:3 ; 0x2A : 16:9
	LT8618SXB_I2C_Write_Byte( 0x47, VIC_Num );          // PB4;vic ,0x10: 1080P ;  0x04 : 720P

//	LT8618SXB_I2C_Write_Byte(0xff,0x84);
//	8618SXB hdcp1.4 加密的话，要保证hfp + 8410[5:0](rg_island_tr_res) 的个数（video de的下降沿到 最近的一个aude 的间隔），大于58；hdcp1.4 spec中有要求
	LT8618SXB_I2C_Write_Byte( 0x10, 0x2c );             //data iland
	LT8618SXB_I2C_Write_Byte( 0x12, 0x64 );             //act_h_blank

	//VS_IF, 4k 30hz need send VS_IF packet. Please refer to hdmi1.4 spec 8.2.3
	if( VIC_Num == 95 )
	{
//	   LT8618SXB_I2C_Write_Byte(0xff,0x84);
		LT8618SXB_I2C_Write_Byte( 0x3d, 0x2a );         //UD1 infoframe enable

		LT8618SXB_I2C_Write_Byte( 0x74, 0x81 );
		LT8618SXB_I2C_Write_Byte( 0x75, 0x01 );
		LT8618SXB_I2C_Write_Byte( 0x76, 0x05 );
		LT8618SXB_I2C_Write_Byte( 0x77, 0x49 );
		LT8618SXB_I2C_Write_Byte( 0x78, 0x03 );
		LT8618SXB_I2C_Write_Byte( 0x79, 0x0c );
		LT8618SXB_I2C_Write_Byte( 0x7a, 0x00 );
		LT8618SXB_I2C_Write_Byte( 0x7b, 0x20 );
		LT8618SXB_I2C_Write_Byte( 0x7c, 0x01 );
	}else
	{
//	   LT8618SXB_I2C_Write_Byte(0xff,0x84);
		LT8618SXB_I2C_Write_Byte( 0x3d, 0x0a ); //UD1 infoframe disable
	}
}

void LT8618SXB_TX_Phy( void )
{
	// HDMI_TX_Phy
	LT8618SXB_I2C_Write_Byte( 0xff, 0x81 ); // register bank
	LT8618SXB_I2C_Write_Byte( 0x30, 0xea );
	LT8618SXB_I2C_Write_Byte( 0x31, 0x44 );
	LT8618SXB_I2C_Write_Byte( 0x32, 0x4a );
	LT8618SXB_I2C_Write_Byte( 0x33, 0x0b );
	LT8618SXB_I2C_Write_Byte( 0x34, 0x00 );
	LT8618SXB_I2C_Write_Byte( 0x35, 0x00 );
	LT8618SXB_I2C_Write_Byte( 0x36, 0x00 );
	LT8618SXB_I2C_Write_Byte( 0x37, 0x44 );
	LT8618SXB_I2C_Write_Byte( 0x3f, 0x0f );

	LT8618SXB_I2C_Write_Byte( 0x40, 0xa0 ); //0xa0 -- CLK tap0 swing
	LT8618SXB_I2C_Write_Byte( 0x41, 0xa0 ); //0xa0 -- D0 tap0 swing
	LT8618SXB_I2C_Write_Byte( 0x42, 0xa0 ); //0xa0 -- D1 tap0 swing
	LT8618SXB_I2C_Write_Byte( 0x43, 0xa0 ); //0xa0 -- D2 tap0 swing

	LT8618SXB_I2C_Write_Byte( 0x44, 0x0a );
}

unsigned char lt8618sxb_init()
{
	unsigned char vid0,vid1,vid2;

	Use_DDRCLK = 0;

    //gpioi2c_init();
	ls2k_i2c_init(0, LS2K_I2C_BASE);
	
    LT8618SXB_I2C_Write_Byte(0xff, 0x80); // register bank
	LT8618SXB_I2C_Write_Byte(0xee, 0x01); // enable IIC
	
	LT8618SXB_I2C_Write_Byte(0xFF, 0x80);                                             // register bank

	vid0 =  LT8618SXB_I2C_Read_Byte(0x00);
	vid1 =  LT8618SXB_I2C_Read_Byte(0x01);
	vid2 =  LT8618SXB_I2C_Read_Byte(0x02);
	if((vid0 != 0x17)||(vid1 != 0x02)||(vid2 != 0xE2)){
		printf("Not found LT8618SXB \n\r");
		return -1;
	}

	printf("LT8618SXB Chip ID = 0x%02x", vid0);      // 0x17
	printf("%02x", vid1);                                    // 0x02
	printf("%02x\r\n", vid2);                                // 0xE2
	
    // RST_PD_Init
	LT8618SXB_I2C_Write_Byte(0xff, 0x80); // register bank
	LT8618SXB_I2C_Write_Byte(0x11, 0x00); // reset MIPI Rx logic.

	LT8618SXB_I2C_Write_Byte(0x13, 0xf1);
	LT8618SXB_I2C_Write_Byte(0x13, 0xf9); // Reset TTL video process
	
    LT8618SXB_TTL_Input_Analog();
	
    LT8618SXB_TTL_Input_Digtal();
	
    delay(200);
	
//    LT8618SXB_Video_Check( );   // For debug
	
    LT8618SXB_PLL_config( );
	
    // color space config
	//LT8618SXB_CSC_setting( );
	
    //AVI
	LT8618SXB_AVI_setting( );
	
    // HDMI_TX_Phy
	LT8618SXB_TX_Phy( );

	return 0;
}


static const Cmd Cmds[] = {
	{"Misc"},
	{"gr1", "", NULL, "read a data from a CH7034 chip", dvo1_gpioi2c_read, 1, 5, 0},
	{"gw1", "", NULL, "write a data to a CH704 chip", dvo1_gpioi2c_write, 1, 5, 0},
	{"cfg", "", NULL, "write stream data to a CH7034 chip", gpioi2c_config_ch7034, 1, 5, 0},
	{0, 0}
};

static void init_cmd __P((void)) __attribute__ ((constructor));
static void init_cmd()
{
	cmdlist_expand(Cmds, 1);
}
