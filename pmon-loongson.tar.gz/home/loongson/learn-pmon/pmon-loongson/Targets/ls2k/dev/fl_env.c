#include <sys/types.h>
#include <sys/malloc.h>
#include <machine/cpu.h>
#include <machine/pio.h>
#include <pmon.h>
#include <stdlib.h>
#include "target/bonito.h"
#include "pflash.h"
#include "flash.h"
#include "dev/pflash_tgt.h"

#if (NMOD_FLASH_AMD + NMOD_FLASH_INTEL + NMOD_FLASH_SST) == 0
#ifdef HAVE_FLASH
#undef HAVE_FLASH
#endif
#else
#define HAVE_FLASH
#endif

extern unsigned long long  memorysize;
extern unsigned long long  memorysize_high_n[];
extern unsigned char hwethadr[6];
static int nvram_invalid = 0;

static int cksum(void *p, size_t s, int set);
#ifdef HAVE_FLASH
/*
 *  Flash programming support code.
 */

/*
 *  Table of flash devices on target. See pflash_tgt.h.
 */

struct fl_map tgt_fl_map_boot16[]={
	TARGET_FLASH_DEVICES_16
};


struct fl_map *tgt_flashmap()
{
	return tgt_fl_map_boot16;
}

void tgt_flashwrite_disable()
{
}

int tgt_flashwrite_enable()
{
	return(1);
}

void tgt_flashinfo(void *p, size_t *t)
{
	struct fl_map *map;

	map = fl_find_map(p);
	if (map) {
		*t = map->fl_map_size;
	} else {
		*t = 0;
	}
}

void tgt_flashprogram(void *p, int size, void *s, int endian)
{
	unsigned short val;
	unsigned int ret;
	/*close other core*/
	val = inw(PHYS_TO_UNCACHED(0x1fe001d0));
	outw(PHYS_TO_UNCACHED(0x1fe001d0), val & (0x7777 ^ (1 << (BOOTCORE_ID << 2) + 3)));
	ret = inl(PHYS_TO_UNCACHED(0x1fe00420));
	if (ret & 0x100)
		outl(PHYS_TO_UNCACHED(0x1fe00420), (ret & ~0x100));

	printf("Programming flash %llx:%x into %llx\n", s, size, p);
	if (fl_erase_device(p, size, TRUE)) {
		printf("Erase failed!\n");
		return;
	}
	printf("Erase end!\n");
	if (fl_program_device(p, s, size, TRUE)) {
		printf("Programming failed!\n");
	}
	printf("Programming end!\n");
	fl_verify_device(p, s, size, TRUE);
	/*open other core*/
	//if (ret & 0x100)  // ???? open store spd cause reboot
	//	outl(PHYS_TO_UNCACHED(0x1fe00420), ret);
	//outw( PHYS_TO_UNCACHED(0x1fe001d0), val);
}

void efi_flash_program(void *p, int size, void *s, int endian)
{
	unsigned short val;
	unsigned int ret;

	/*close other core*/
	val = inw(PHYS_TO_UNCACHED(0x1fe001d0));
	outw(PHYS_TO_UNCACHED(0x1fe001d0), val & (0x7777 ^ (1 << (BOOTCORE_ID << 2) + 3)));
	ret = inl(PHYS_TO_UNCACHED(0x1fe00420));
	if (ret & 0x100)
		outl(PHYS_TO_UNCACHED(0x1fe00420), (ret & ~0x100));

	if (fl_erase_device(p, size, FALSE)) {
		printf("Erase failed!\n");
		return;
	}
	if (fl_program_device(p, s, size, FALSE)) {
		printf("Programming failed!\n");
	}
	fl_verify_device(p, s, size, FALSE);
	/*open other core*/
	if (ret & 0x100)
		outl(PHYS_TO_UNCACHED(0x1fe00420), ret);
	outw( PHYS_TO_UNCACHED(0x1fe001d0), val);
}

#endif /* PFLASH */

/*************************************************************************/
/*
 *	Target dependent Non volatile memory support code
 *	=================================================
 *
 *
 *  On this target a part of the boot flash memory is used to store
 *  environment. See EV64260.h for mapping details. (offset and size).
 */

/*
 *  Read in environment from NV-ram and set.
 */
void tgt_mapenv(int (*func) __P((char *, char *)))
{
	char *ep;
	char env[512];
	char *nvram;
	int i;
	uint64_t freq;

	/*
	 *  Check integrity of the NVRAM env area. If not in order
	 *  initialize it to empty.
	 */
	printf("in envinit\n");
	nvram = (char *)(tgt_flashmap())->fl_map_base;
	printf("nvram=%08x\n",(unsigned int)nvram);
	if (fl_devident(nvram, NULL) == 0 || cksum(nvram + NVRAM_OFFS, NVRAM_SIZE, 0) != 0) {
		printf("NVRAM is invalid!\n");
		nvram_invalid = 1;
	} else {
		nvram += NVRAM_OFFS;
		ep = nvram+2;;

		while (*ep != 0) {
			char *val = 0, *p = env;
			i = 0;
			while ((*p++ = *ep++) && (ep <= nvram + NVRAM_SIZE - 1) && i++ < 255) {
				if ((*(p - 1) == '=') && (val == NULL)) {
					*(p - 1) = '\0';
					val = p;
				}
			}
			if (ep <= nvram + NVRAM_SIZE - 1 && i < 255) {
				(*func)(env, val);
			} else {
				nvram_invalid = 2;
				break;
			}
		}
	}

	printf("NVRAM@%x\n", (u_int32_t)nvram);
	bcopy(&nvram[ETHER_OFFS], hwethadr, 6);
	sprintf(env, "%02x:%02x:%02x:%02x:%02x:%02x", hwethadr[0], hwethadr[1],
		hwethadr[2], hwethadr[3], hwethadr[4], hwethadr[5]);
	(*func) ("ethaddr", env);

#ifdef GMAC_USE_FLASH_MAC
	unsigned char gmac_num;
	unsigned char gmac_name[8];
	unsigned char flash_mac[12];
	for(gmac_num=0; gmac_num<USE_GMAC_NUM; gmac_num++)
	{
		memset(gmac_name, 0, 8);
		bcopy(&nvram[GMAC_MAC_OFFS + (12*gmac_num)], flash_mac, 12);
		if(strstr(flash_mac, "syn") == 0) {
			memset(flash_mac, 0xff, 12);
		}
		sprintf(gmac_name, "syn%d_mac",gmac_num);
		sprintf(env, "%02x:%02x:%02x:%02x:%02x:%02x",flash_mac[4],flash_mac[5], flash_mac[6], flash_mac[7], flash_mac[8], flash_mac[9]);
		(*func) (gmac_name, env);
	}
#endif

#ifdef no_thank_you
	(*func)("vxWorks", env);
#endif


	sprintf(env, "%d", memorysize / (1024 * 1024));
	(*func)("memsize", env);

	sprintf(env, "%d", (memorysize_high_n[0] - 0x10000000) / (1024 * 1024));
	(*func)("highmemsize", env);
#if	(TOT_NODE_NUM >= 2)
	for (i = 1; i < TOT_NODE_NUM; i++) {
		memset(env, 0, 50);
		sprintf(env, "%d", memorysize_high_n[i] / (1024 * 1024));
		sprintf(&env[20], "memorysize_high_n%d", i);
		(*func)(&env[20], env);
	}
#endif
	freq = tgt_pipefreq(); 
	sprintf(env, "%llu", freq);
	(*func)("cpuclock", env);

	sprintf(env, "%d",VRAM_SIZE);
	(*func)("vramsize", env);

	sprintf(env, "%d",0);

	(*func)("sharevram", env);

	(*func)("systype", SYSTYPE);
}

int tgt_unsetenv(char *name)
{
	char *ep, *np, *sp;
	char *nvram;
	char *nvrambuf;
	char *nvramsecbuf;
	int status;

	if (nvram_invalid)
		return(0);

	/* Use first defined flash device (we probably have only one) */
	nvram = (char *)(tgt_flashmap())->fl_map_base;

	/* Map. Deal with an entire sector even if we only use part of it */
	nvram += NVRAM_OFFS & ~(NVRAM_SECSIZE - 1);
	nvramsecbuf = (char *)malloc(NVRAM_SECSIZE);
	if (nvramsecbuf == 0) {
		printf("Warning! Unable to malloc nvrambuffer!\n");
		return(-1);
	}
	memcpy(nvramsecbuf, nvram, NVRAM_SECSIZE);
	nvrambuf = nvramsecbuf + (NVRAM_OFFS & (NVRAM_SECSIZE - 1));

	ep = nvrambuf + 2;

	status = 0;
	while ((*ep != '\0') && (ep <= nvrambuf + NVRAM_SIZE)) {
		np = name;
		sp = ep;

		while ((*ep == *np) && (*ep != '=') && (*np != '\0')) {
			ep++;
			np++;
		}
		if ((*np == '\0') && ((*ep == '\0') || (*ep == '='))) {
			while (*ep++);
			while (ep <= nvrambuf + NVRAM_SIZE) {
				*sp++ = *ep++;
			}
			if (nvrambuf[2] == '\0') {
				nvrambuf[3] = '\0';
			}
			cksum(nvrambuf, NVRAM_SIZE, 1);
			if (fl_erase_device(nvram, NVRAM_SECSIZE, FALSE)) {
				status = -1;
				break;
			}

			if (fl_program_device(nvram, nvramsecbuf, NVRAM_SECSIZE, FALSE)) {
				status = -1;
				break;
			}
			status = 1;
			break;
		}
		else if (*ep != '\0') {
			while (*ep++ != '\0');
		}
	}

	free(nvramsecbuf);
	return(status);
}

int tgt_setenv(char *name, char *value)
{
	char *ep;
	int envlen;
	char *nvrambuf;
	char *nvramsecbuf;
	char *nvram;

	/* Non permanent vars. */
	if (strcmp(EXPERT, name) == 0) {
		return(1);
	}

	/* Calculate total env mem size requiered */
	envlen = strlen(name);
	if (envlen == 0) {
		return(0);
	}
	if (value != NULL) {
		envlen += strlen(value);
	}
	envlen += 2;	/* '=' + null byte */
	if (envlen > 255) {
		return(0);	/* Are you crazy!? */
	}

	/* Use first defined flash device (we probably have only one) */
	nvram = (char *)(tgt_flashmap())->fl_map_base;

	/* Deal with an entire sector even if we only use part of it */
	nvram += NVRAM_OFFS & ~(NVRAM_SECSIZE - 1);

	/* If NVRAM is found to be uninitialized, reinit it. */
	if (nvram_invalid) {
		nvramsecbuf = (char *)malloc(NVRAM_SECSIZE);
		if (nvramsecbuf == 0) {
			printf("Warning! Unable to malloc nvrambuffer!\n");
			return(-1);
		}
		memcpy(nvramsecbuf, nvram, NVRAM_SECSIZE);
		nvrambuf = nvramsecbuf + (NVRAM_OFFS & (NVRAM_SECSIZE - 1));
		memset(nvrambuf, -1, NVRAM_SIZE);
		nvrambuf[2] = '\0';
		nvrambuf[3] = '\0';
		cksum((void *)nvrambuf, NVRAM_SIZE, 1);
		printf("Warning! NVRAM checksum fail. Reset!\n");
		if (fl_erase_device(nvram, NVRAM_SECSIZE, FALSE)) {
			printf("Error! Nvram erase failed!\n");
			free(nvramsecbuf);
			return(-1);
		}
		if (fl_program_device(nvram, nvramsecbuf, NVRAM_SECSIZE, FALSE)) {
			printf("Error! Nvram init failed!\n");
			free(nvramsecbuf);
			return(-1);
		}
		nvram_invalid = 0;
		free(nvramsecbuf);
	}

	/* Remove any current setting */
	tgt_unsetenv(name);

	/* Find end of evironment strings */
	nvramsecbuf = (char *)malloc(NVRAM_SECSIZE);
	if (nvramsecbuf == 0) {
		printf("Warning! Unable to malloc nvrambuffer!\n");
		return(-1);
	}
	memcpy(nvramsecbuf, nvram, NVRAM_SECSIZE);
	nvrambuf = nvramsecbuf + (NVRAM_OFFS & (NVRAM_SECSIZE - 1));

#ifdef GMAC_USE_FLASH_MAC
	unsigned char gmac_num;
	if (strcmp("syn0_mac", name) == 0) {
		gmac_num = 0;
	} else if (strcmp("syn1_mac", name) == 0) {
		gmac_num = 1;
	} else if (strcmp("syn2_mac", name) == 0) {
		gmac_num = 2;
	} else {
		gmac_num = 0xff;
	}
	if (gmac_num != 0xff) {
	    char *z = value;
	    int j;
	    int32_t k;
		unsigned char flash_env[12];
		unsigned char checksum1,checksum2;
		//Head information syn0~2
		flash_env[0] = 0x73;
		flash_env[1] = 0x79;
		flash_env[2] = 0x6e;
		flash_env[3] = 0x30 + gmac_num;

	    for (j = 0; j < 6; j++) {
			gethex(&k, z, 2);
			flash_env[j+4] = k;
			if(j != 5) {
				z += 2;
				if((*z != '-') && (*z != ':')) { /* Don't get to fancy here :-) */
					printf("Mac addr is error. The format is xx:xx:xx:xx:xx:xx\n");
					return(-1);
				}
			}
			z += 1; 
	    }
		if(flash_env[4]&0x1) {    /* clear multicast bit */
			printf("Illegal MAC address, Error value=0x%02x, Need to clear multicast bit.\n",flash_env[4]);
			return(-1);
		}
		//Two check bytes
		flash_env[10] = (flash_env[4] + flash_env[6] + flash_env[8]) & 0xff; 
		flash_env[11] = (flash_env[5] + flash_env[7] + flash_env[9]) & 0xff; 
		bcopy(flash_env, &nvramsecbuf[GMAC_MAC_OFFS + (12*gmac_num)], 12);
		printf("Mac setting successful, takes effect after restart.\n");
	} else 
#endif
	if (strcmp("ethaddr", name) == 0) {
	    char *s = value;
	    int i;
	    int32_t v;
	    for (i = 0; i < 6; i++) {
		gethex(&v, s, 2);
		hwethadr[i] = v;
		s += 3; /* Don't get to fancy here :-) */
	    }
		bcopy(hwethadr, &nvramsecbuf[ETHER_OFFS], 6);
		printf("Mac setting successful, takes effect after restart.\n");
	}else{ 
		ep = nvrambuf+2;
		if (*ep != '\0') {
			do {
				while (*ep++ != '\0');
			} while (*ep++ != '\0');
			ep--;
		}
		if ((ep + NVRAM_SIZE - ep) < (envlen + 1)) {
			free(nvramsecbuf);
			return(0);	/* Bummer! */
		}

		/*
		 *  Special case heaptop must always be first since it
		 *  can change how memory allocation works.
		 */
		if (strcmp("heaptop", name) == 0) {

			bcopy(nvrambuf+2, nvrambuf+2 + envlen,
					ep - nvrambuf+1);

			ep = nvrambuf+2;
			while (*name != '\0') {
				*ep++ = *name++;
			}
			if (value != NULL) {
				*ep++ = '=';
				while ((*ep++ = *value++) != '\0');
			}
			else {
				*ep++ = '\0';
			}
		} else {
			while (*name != '\0') {
				*ep++ = *name++;
			}
			if (value != NULL) {
				*ep++ = '=';
				while ((*ep++ = *value++) != '\0');
			} else {
				*ep++ = '\0';
			}
			*ep++ = '\0';   /* End of env strings */
		}
	}
	cksum(nvrambuf, NVRAM_SIZE, 1);

	if (fl_erase_device(nvram, NVRAM_SECSIZE, FALSE)) {
		printf("Error! Nvram erase failed!\n");
		free(nvramsecbuf);
		return(0);
	}
	if (fl_program_device(nvram, nvramsecbuf, NVRAM_SECSIZE, FALSE)) {
		printf("Error! Nvram program failed!\n");
		free(nvramsecbuf);
		return(0);
	}
	free(nvramsecbuf);
	return(1);
}

/*
 *  Calculate checksum. If 'set' checksum is calculated and set.
 */
static int cksum(void *p, size_t s, int set)
{
	u_int16_t sum = 0;
	u_int8_t *sp = p;
	int sz = s / 2;

	if (set) {
		*sp = 0;	/* Clear checksum */
		*(sp+1) = 0;	/* Clear checksum */
	}
	while (sz--) {
		sum += (*sp++) << 8;
		sum += *sp++;
	}
	if (set) {
		sum = -sum;
		*(u_int8_t *)p = sum >> 8;
		*((u_int8_t *)p+1) = sum;
	}
	return(sum);
}
