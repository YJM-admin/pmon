
#ifndef _LT8718__H
#define _LT8718__H
#include <sys/linux/types.h>
#define	  TTL_INNPUT			0  // 0:RGB   1:BT1120  2:BT656
#define	  PATTERN_EN			0 // 1: PATTERN  0:VIDEO
#define	  DDR_EN				0 // 0: SDR  1:DDR
//AUX part  (DPCD + I2C)
#define EDID_HEADER_LEN       8

#define	  SwingLevel0  (u8)0x00
#define	  SwingLevel1  (u8)0x01
#define   SwingLevel2  (u8)0x02
#define   SwingLevel3  (u8)0x07
#define   Pre_emphasisLevel0  (u8)0x00
#define   Pre_emphasisLevel1  (u8)0x08
#define   Pre_emphasisLevel2  (u8)0x10
#define   Pre_emphasisLevel3  (u8)0x38

#define   TPS1 (u8)0x01
#define   TPS2 (u8)0x02
#define   MaxSwing (u8)0x01
#define   MaxCounter (u8)0x02
#define   MaxLoop (u8)0x03

typedef enum 
{	
	_1_Lane_ = 1,
	_2_Lane_ = 2,
	_4_Lane_ = 4
} Lane_Num;

typedef enum 
{	
	PerLane162GBps = 0x06,
	PerLane27GBps  = 0x0a,
	PerLane54GBps  = 0x14
} Lane_Rate;


typedef enum 
{	
	RGB_6Bit,
	RGB_8Bit
} Color_Depth;

typedef struct LCD_EDID_PARA
{
  u16 H_Active ;			
  u16 H_Black ;  
  u16 H_Sync_Offset;
  u16 H_Sync_Pulse_Width;
  
  u16 V_Active ;			
  u16 V_Black ;  
  u16 V_Sync_Offset;
  u16 V_Sync_Pulse_Width;
};

typedef struct LT9721_PARA
{
	//LT9721 video parameter	
	u16 H_Total ;			  
	u16 H_Start ;  
	u16 H_Width;
	u16 H_Active;	
	u16 V_Total ;			  
	u16 V_Start ;  
	u16 V_Width;
	u16 V_Active;
	
	u8 resolution;
	Lane_Num lane_num;
	Lane_Rate link_rate;
	Color_Depth color_depth;	
};
#endif
