/*
 * This file is for DS1338 RTC.
 */
#include <sys/linux/types.h>
#include <pmon.h>
#include <stdio.h>
#include <machine/pio.h>
#include "target/ls2k.h"
#include <time.h>
#include <string.h>

#define	DS1338_ADDR	0x68

#define RTC_SCL_CLK	0x271
#define BUS_NO		0x0

int rtc_get_sec(void)
{
	u8 tmp,tmp1;
	u8 buf[1] = {0};
	//0 is the start register.
	if (ls2k_i2c_read(DS1338_ADDR, 0, buf,1)) {
		/*Becuse the RTC API need ture value,we must calculate the ture number.*/
		tmp = buf[0] & 0xf;
		tmp1 = (buf[0] >> 4) * 10;
		tmp += tmp1;
		buf[0] = tmp;
		return buf[0];
	} else
		return 0;
}
int rtc_get_time(u8 *buf)
{
	u8 tmp,tmp1;

	ls2k_i2c_init_host(BUS_NO, RTC_SCL_CLK);
	//0 is the start register.
	if (ls2k_i2c_read(DS1338_ADDR, 0, buf,7)) {
		/*Becuse the RTC API need ture value,we must calculate the ture number.*/
		tmp = buf[0] & 0xf;
		tmp1 = (buf[0] >> 4) * 10;
		tmp += tmp1;
		buf[0] = tmp;

		tmp = buf[1] & 0xf;
		tmp1 = (buf[1] >> 4) * 10;
		tmp += tmp1;
		buf[1] = tmp;

		tmp = buf[2] & 0xf;
		tmp1 = (buf[2] >> 4) * 10;
		tmp += tmp1;
		buf[2] = tmp;

		tmp = buf[4] & 0xf;
		tmp1 = (buf[4] >> 4) * 10;
		tmp += tmp1;
		buf[4] = tmp;

		tmp = buf[5] & 0xf;
		tmp1 = (buf[5] >> 4) * 10;
		tmp += tmp1;
		buf[5] = tmp;

		tmp = buf[6] & 0xf;
		tmp1 = (buf[6] >> 4) * 10;
		tmp += tmp1;
		buf[6] = tmp;
		return 1;
	} else
		return 0;
}
int rtc_set_time(u8 *buf)
{
	u8 tmp,tmp1;

	ls2k_i2c_init_host(BUS_NO, RTC_SCL_CLK);
	/*The RTC API return a number,we must calculate the register value.*/
	tmp = buf[0] % 10;
	tmp1 = ((buf[0] / 10) << 4);
	tmp += tmp1;
	buf[0] = tmp;

	tmp = buf[1] % 10;
	tmp1 = ((buf[1] / 10) << 4);
	tmp += tmp1;
	buf[1] = tmp;

	tmp = buf[2] % 10;
	tmp1 = ((buf[2] / 10) << 4);
	tmp += tmp1;
	buf[2] = tmp;

	tmp = buf[4] % 10;
	tmp1 = ((buf[4] / 10) << 4);
	tmp += tmp1;
	buf[4] = tmp;

	tmp = buf[5] % 10;
	tmp1 = ((buf[5] / 10) << 4);
	tmp += tmp1;
	buf[5] = tmp;

	tmp = buf[6] % 10;
	tmp1 = ((buf[6] / 10) << 4);
	tmp += tmp1;
	buf[6] = tmp;

	delay(1000);
	//0 is the start register.
	if (ls2k_i2c_write(DS1338_ADDR, 0, buf, 7))
		return 1;
	else
		return 0;
}

void cmd_ex_rtc_test(int argc, char *argv[])
{

	u8 buf[8] = {0};
	u8 dev_addr = 0x0;
	int i;
	int busno;

	if(argc != 2){
	    printf("usage: ex_rtc_test busno\n");
	    return 0;
	}

	busno = strtoul(argv[1],0,0);


	ls2k_i2c_init_host(busno, RTC_SCL_CLK);

	ls2k_i2c_read(DS1338_ADDR, dev_addr, buf, 8);

	printf("Read the RTC register!\n");
	for (i =0;i < 8;i++)
		printf("0x%02x ",buf[i]);
	printf("read done\n");

	printf("Write the RTC register!\n");
	ls2k_i2c_write(DS1338_ADDR,dev_addr, buf, 8);

	printf("write done\n");      

}

static const Cmd Cmds[] = {
	{"Misc"},
	{"ex_rtc_test", "", NULL, "test the i2c external rtc is ok?", cmd_ex_rtc_test, 1, 99, 0},
	{0, 0}
};

static void init_cmd __P((void)) __attribute__ ((constructor));
static void init_cmd()
{
	cmdlist_expand(Cmds, 1);
}
