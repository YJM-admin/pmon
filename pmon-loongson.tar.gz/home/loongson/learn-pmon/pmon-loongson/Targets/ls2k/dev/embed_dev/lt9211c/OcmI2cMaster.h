#include	"lt9211_sdk.h"

#ifndef		_OCMI2CMASTER_H
#define		_OCMI2CMASTER_H


extern int Ocm_I2c_Init(void);
extern unsigned char HDMI_ReadI2C_Byte(unsigned char RegAddr);
extern int HDMI_ReadI2C_ByteN(unsigned char RegAddr, unsigned char *p_data, int N);
extern int HDMI_WriteI2C_Byte(unsigned char RegAddr, unsigned char d);
extern int HDMI_WriteI2C_ByteN(unsigned char RegAddr, unsigned char *d,int N);


#endif
