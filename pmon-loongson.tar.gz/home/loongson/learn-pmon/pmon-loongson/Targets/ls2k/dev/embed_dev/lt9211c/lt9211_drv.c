/******************************************************************************
  * @project: LT9211C
  * @file: main.c
  * @author: sxue
  * @company: LONTIUM COPYRIGHT and CONFIDENTIAL
  * @date: 2023.01.29
*******************************************************************************/

#include "lt9211_sdk.h"
#include "lt9211_cfg.h"


void lt9211c_drv_init(void)
{
    Mod_System_Init();
    Mod_LT9211C_Reset();
    LTLog(LOG_INFO, "LT9211C %s %s",__DATE__,__TIME__);
    Mod_ChipID_Read();
    #if (LT9211C_MODE_SEL != PATTERN_OUT)
    Mod_SystemRx_PowerOnInit();
    Mod_SystemTx_PowerOnInit();
    #endif

    while(1) {
        #if (LT9211C_MODE_SEL == PATTERN_OUT)
        Mod_ChipTx_PtnOut();
        #endif
        #if (LT9211C_MODE_SEL == MIPI_REPEATER)
        Mod_MipiRpt_Handler();
        #endif
        #if (LT9211C_MODE_SEL == MIPI_LEVEL_SHIFT)
        Mod_MipiLs_Handler();
        #endif
        #if (LT9211C_MODE_SEL == LVDS_IN_LVDS_OUT)
        Mod_LvdsRx_Handler();
        Mod_LvdsTx_Handler();
        #endif
        #if (LT9211C_MODE_SEL == LVDS_IN_MIPI_OUT)
        Mod_LvdsRx_Handler();
        Mod_MipiTx_Handler();
        #endif
        #if (LT9211C_MODE_SEL == LVDS_IN_TTL_OUT)
        Mod_LvdsRx_Handler();
        Mod_TtlTx_Handler();
        #endif
        #if (LT9211C_MODE_SEL == MIPI_IN_LVDS_OUT)
        Mod_MipiRx_Handler();
        Mod_LvdsTx_Handler();
        #endif
        #if (LT9211C_MODE_SEL == MIPI_IN_MIPI_OUT)
        Mod_MipiRx_Handler();
        Mod_MipiTx_Handler();
        #endif
        #if (LT9211C_MODE_SEL == MIPI_IN_TTL_OUT)
        Mod_MipiRx_Handler();
        Mod_TtlTx_Handler();
        #endif
        #if (LT9211C_MODE_SEL == TTL_IN_LVDS_OUT)
        Mod_TtlRx_Handler();
        if (g_stChipRx.ucRxState == STATE_CHIPRX_FAILED) {
            LTLog(LOG_INFO, "[%s]: chip RX init failed!!!\r\n", __func__);
            break;
        }

        Mod_LvdsTx_Handler();
        if ((g_stChipRx.ucRxState == STATE_CHIPRX_PLAY_BACK)    \
          && g_stChipTx.ucTxState == STATE_CHIPTX_PLAY_BACK) {
            printf("[%s]: chip init done!!!\r\n", __func__);
            break;
        }
        if (g_stChipTx.ucTxState == STATE_CHIPTX_FAILED) {
            printf("[%s]: chip TX init failed!!!\r\n", __func__);
            break;
        }
        #endif
        #if (LT9211C_MODE_SEL == TTL_IN_MIPI_OUT)
        Mod_TtlRx_Handler();
        Mod_MipiTx_Handler();
        #endif
        #if (LT9211C_MODE_SEL == TTL_IN_TTL_OUT)
        Mod_TtlRx_Handler();
        Mod_TtlTx_Handler();
        #endif
    }
}
