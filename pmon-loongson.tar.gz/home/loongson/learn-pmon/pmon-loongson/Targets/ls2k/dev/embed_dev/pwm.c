#include "target/ls2k.h"
#include <pmon.h>
#include <stdio.h>
#include <machine/pio.h>
unsigned long long pwm_base = LS2K_PWM0_REG_BASE;

void
delay3(unsigned int loops)
{
	volatile unsigned int counts = loops;
	while (counts--);
}

static int pwm_init(int num){
    pwm_base = LS2K_PWM0_REG_BASE + num * 0x100;

}
int pwm_disable(){
	unsigned int val;
    
	val = readl(pwm_base+0xc);
	val &= ~1;
        writel(val, pwm_base+0xc);

	return 0;
}


int pwm_enable(){	
        unsigned int val;

        val = readl(pwm_base+0xc);
        val |= 1;
        writel(val, pwm_base+0xc);

        return 0;
}

int pwm_control(unsigned int low, unsigned int full){

	outl(pwm_base+0x4, low);
	outl(pwm_base+0x8, full);

}

static void cmd_pwm_control(ac, av)
    int ac;
    char *av[];
{
	unsigned int num,low,full,val;
	
	if(ac <4)
	{
		printf("pwm_contorl num low full\n");
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0);
	low = (unsigned int)strtoul(av[2], 0, 0);
	full = (unsigned int)strtoul(av[3], 0, 0);

	pwm_init(num);

	val = readl(0x8000000010010440);
        val |= (1 << num);
    	writel(val, 0x8000000010010440);

	pwm_disable();

	pwm_control(low, full);
	pwm_enable();
	
	delay3(200000000);

}



static void cmd_pwm_measure(ac, av)
    int ac;
    char *av[];
{
	unsigned int num, low, full;

	if(ac <2)
	{
		printf("pwm_measure num \n");
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0);

	pwm_init(num);

	readl(pwm_base+0xc) &= ~1;
	readl(pwm_base+0xc) = 0x109;
	printf("wait pwm pulse\n");
	delay3(400000000);


	low = readl(pwm_base+0x4);
	full = readl(pwm_base+0x8);
	printf("low is %x\n",low);
	printf("full is %x\n",full);
}


static const Cmd Cmds[] =
{
    {"MyCmds"},
    {"pwm_control", "", 0, "num low full", cmd_pwm_control, 0,99, CMD_REPEAT},
    {"pwm_measure", "", 0, "num ", cmd_pwm_measure, 0,99, CMD_REPEAT},
    {0,0},

};
static void init_cmd __P((void)) __attribute__ ((constructor));

static void
init_cmd()
{
	cmdlist_expand(Cmds, 1);
}
