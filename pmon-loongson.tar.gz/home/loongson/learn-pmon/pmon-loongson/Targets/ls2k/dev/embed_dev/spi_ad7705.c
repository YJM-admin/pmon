
#include <stdio.h>
//#include "include/fcr.h"
#include <stdlib.h>
#include <ctype.h>
#undef _KERNEL
#include <errno.h>
#include <pmon.h>
#include <types.h>
#include <pflash.h>
#include "target/bonito.h"
#include <linux/bitops.h>
#include <string.h>

#define SPCR      0x0
#define SPSR      0x1
#define TXFIFO    0x2
#define RXFIFO    0x2
#define SPER      0x3
#define PARAM     0x4
#define SOFTCS    0x5
#define PARAM2    0x6

static uint64_t ls_spi_base  = 0;


#define RFEMPTY 1

static void spi_write(unsigned char addr,unsigned char val){

    *(volatile unsigned char *)(UNCACHED_MEMORY_ADDR | (ls_spi_base + addr)) = val;
}
static unsigned char  spi_read(unsigned char addr){
    unsigned char val;

    val = *(volatile unsigned char *)(UNCACHED_MEMORY_ADDR | (ls_spi_base + addr));

    return val;
}
#define spi_set_cs(x)           spi_write(SOFTCS, x)


void spi1_init(){
    ls_spi_base  = (readl(BONITO_PCICFG0_BASE_VA | (23ULL << 11) + 0x10ULL) & 0xfffffff0) | 0x8000000000000000ULL;

    spi_write(SPSR,   0xc0);
    spi_write(PARAM,  0x40);
    spi_write(SPER,   0x05);
    spi_write(PARAM2, 0x01);
    spi_write(SPCR,   0x50);
}

unsigned int ad7705_write_then_read_byte(unsigned char data){
    int timeout = 1000;
    unsigned char val;


    spi_write(TXFIFO, data);
    while((spi_read(SPSR) & RFEMPTY) && timeout--);
    val = spi_read(RXFIFO);

    if(timeout < 0){
        printf("wait rfempty timeout!\n");
        return -1;
    }
    return val;

}

void ad7705_init(unsigned int channel){
    unsigned int i;

    for(i = 0;i < 200;i++){
        ad7705_write_then_read_byte(0xff);
    }
    delay(1);

    switch(channel){
        case 0:
            ad7705_write_then_read_byte(0x20);
            ad7705_write_then_read_byte(0x0f);
            ad7705_write_then_read_byte(0x10);
            ad7705_write_then_read_byte(0x44);
            break;
        case 1:
            ad7705_write_then_read_byte(0x21);
            ad7705_write_then_read_byte(0x0f);
            ad7705_write_then_read_byte(0x11);
            ad7705_write_then_read_byte(0x44);
            break;
        default:
            break;
    }

    for(i = 0;i < 200;i++){
        ad7705_write_then_read_byte(0xff);
    }
    delay(1);

}
void get_ad7705_data(int argc,char *argv[]){
    int i,j;
    unsigned int channel;
    unsigned int temp;
    unsigned char temph;
    unsigned char templ;
    float val;
    unsigned int num[10];
    channel = strtoul(argv[1], 0, 0);

    spi1_init();
    spi_set_cs(0x01);

    for(i = 0;i < 10;i++){
        ad7705_init(channel);
        ad7705_write_then_read_byte(0x38 | channel);
        delay(20);
        temph = ad7705_write_then_read_byte(0x00);
        templ = ad7705_write_then_read_byte(0x00);
        num[i] = ((temph & 0xff) << 8) | (templ & 0xff);
    }
    spi_set_cs(0x11);

    for(i = 0;i < 10;i++){
        for(j = 0;j < 9 - i;j++){
            if(num[j] > num[j+1]){
                temp = num[j];
                num[j] = num[j + 1];
                num[j + 1] = temp;
            }
        }
    }
    for(i = 0 + 1; i< 10 - 1; i++){
        temp += num[i];
    }
    temp /= 8;

    printf("temp = 0x%x\n", temp);
    val = 2.5 * temp / 65536 / 120 * 250;


   temp = val * 100;
   printf("val = %d\n", temp);
   delay(100);

/*
    num[0] = (int)val;
    num[1] = ((int)(val * 10)) % 10;
    num[2] = ((int)(val * 100)) % 10;
*/


}

#define nr_strtol strtoul
#define nr_strtoll strtoull
#define DIV_ROUND_UP(n, d) (((n) + (d) - 1) / (d))

int fls_ls(int x)
{
        int r = 32;

        if (!x)
                return 0;
        if (!(x & 0xffff0000u)) {
                x <<= 16;
                r -= 16;
        }
        if (!(x & 0xff000000u)) {
                x <<= 8;
                r -= 8;
        }
        if (!(x & 0xf0000000u)) {
                x <<= 4;
                r -= 4;
        }
        if (!(x & 0xc0000000u)) {
                x <<= 2;
                r -= 2;
        }
        if (!(x & 0x80000000u)) {
                x <<= 1;
                r -= 1;
        }
        return r;
}


#define	SPI_CPHA	0x01			/* clock phase */
#define	SPI_CPOL	0x02			/* clock polarity */
int spi_init_test(int ac, char **av)
{
	int spinum;
	unsigned int clk,mode;
	unsigned int cs,dev,func;
	unsigned int div,div_tmp;
	const char rdiv[12] = {0, 1, 4, 2, 3, 5, 6, 7, 8, 9, 10, 11};
	unsigned int bit;
	unsigned char spcr, sper, spsr,val;

	if(ac <5)
	{
		printf("spi_init spi_num clk cs mode\n");
		return -1;
	}


	spinum = nr_strtol(av[1], 0, 0);

	if(spinum == 0)
		ls_spi_base = 0x800000001fe001f0;
	if(spinum > 0){
		switch(spinum)
		{
		   case 1:
			   dev = 23;
			   func= 0;
			   break;
		   case 2:
			   dev = 7;
			   func= 1;
			   break;
		   case 3:
			   dev = 22;
			   func= 0;
			   break;

		}
		ls_spi_base  = (readl(BONITO_PCICFG0_BASE_VA | (dev << 11) | (func << 8)+ 0x10ULL) & 0xfffffff0) | 0x8000000000000000ULL;
	}

	printf("ls_spi_base is 0x%llx\n",ls_spi_base);

	clk = nr_strtol(av[2], 0, 0);
	cs = nr_strtol(av[3], 0, 0);
	mode = nr_strtol(av[4], 0, 0);

	if(clk ==0)
	{
		printf("clk input error\n");
		return -1;
	}

	div = DIV_ROUND_UP(100000000,clk);
	bit = fls_ls(div) - 1;

	if ((1<<bit) == div)
              bit--;
        div_tmp = rdiv[bit];

	spcr = div_tmp & 3;
        sper = (div_tmp >> 2) & 3;

	spi_write(SPSR,   0xc0);
	spi_write(PARAM,  0x40);
	spi_write(SPER,   0x05);
	spi_write(PARAM2, 0x01);
	spi_write(SPCR,   0x50);

	val = spi_read(SPCR);
	val &= ~0xc;
	if (mode & SPI_CPOL)
             val |= 8;
        if (mode & SPI_CPHA)
             val |= 4;

	spi_write(SPCR, (val & ~3) | spcr);

	val = spi_read(SPER);
	spi_write(SPER, (val & ~3) | sper);

	val = 0x01<<cs;
	spi_set_cs(val);

	return 0;
}



int spi_wr(int ac, char **av)
{

    int timeout = 1000;
    unsigned char val,val1;

    if(ac <2)
     {
	printf("spi_wr data\n");
	return -1;
     }

     val = nr_strtol(av[1], 0, 0);

    spi_write(TXFIFO, val);
    while((spi_read(SPSR) & RFEMPTY) && timeout--);
    val1 = spi_read(RXFIFO);

    printf("RXFIFO is 0x%x after TX 0x%x\n",val1,val);
    return 0;
}

int spi_rd(int ac, char **av)
{

    int timeout = 1000;
    unsigned char val,val1;

    val1 = spi_read(RXFIFO);

    printf("RXFIFO is 0x%x\n",val1);
    return 0;
}


static const Cmd Cmds[] =
{
    {"MyCmds"},
    {"get_ad7705_data", "", 0, "get_ad7705_data()", get_ad7705_data, 0,99, CMD_REPEAT},
    {"spi_init", "", 0, "spi_num clk cs mode", spi_init_test, 0,99, CMD_REPEAT},
    {"spi_rd", "", 0, "null", spi_rd, 0,99, CMD_REPEAT},
    {"spi_wr", "", 0, "data", spi_wr, 0,99, CMD_REPEAT},
};
static void init_cmd __P((void)) __attribute__ ((constructor));

static void
init_cmd()
{
	cmdlist_expand(Cmds, 1);
}
