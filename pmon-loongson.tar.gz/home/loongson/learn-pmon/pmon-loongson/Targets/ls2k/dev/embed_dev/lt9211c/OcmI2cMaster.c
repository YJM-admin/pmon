/******************************************************************************
  * @project: LT9211C
  * @file: OcmI2cMaster.c
  * @author: sxue
  * @company: LONTIUM COPYRIGHT and CONFIDENTIAL
  * @date: 2023.01.29
/******************************************************************************/

#include "lt9211_sdk.h"

#include "pmon.h"


int ucAck;
int ucI2cAddr = 0x2d;   /* 0x2d(7bit address) */

/* defined in i2c-ls.c */
extern unsigned long long i2c_base_addr;
extern void ls_i2c_init(void);
extern int ls_i2c_read_seq_rand(unsigned char dev_addr, unsigned int data_addr, unsigned char *buf, int count);
extern int ls_i2c_write_seq(unsigned char dev_addr, unsigned int data_addr, unsigned char *buf, int count);

int Ocm_I2c_Init(void)
{
    ls2k_i2c_init_host(1, 0x271);

    return 0;
}

unsigned char HDMI_ReadI2C_Byte(unsigned char RegAddr)
{
    unsigned char data = 0;

    Ocm_Timer0_Delay1ms(10);
    ls2k_i2c_read(ucI2cAddr, RegAddr, &data, 1);

    return data;
}

int HDMI_ReadI2C_ByteN(unsigned char RegAddr, unsigned char *p_data, int N)
{
    return ls2k_i2c_read(ucI2cAddr, RegAddr, p_data, N);
}

int HDMI_WriteI2C_Byte(unsigned char RegAddr, unsigned char d)
{
    Ocm_Timer0_Delay1ms(10);
    return ls2k_i2c_write(ucI2cAddr, RegAddr, &d, 1);
}

int HDMI_WriteI2C_ByteN(unsigned char RegAddr, unsigned char *d,int N)
{
    return ls2k_i2c_write(ucI2cAddr, RegAddr, d, N);
}

