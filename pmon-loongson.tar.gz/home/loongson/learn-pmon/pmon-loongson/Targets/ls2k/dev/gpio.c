#include <pmon.h>
#include <stdio.h>

static unsigned long gpio_node_base = 0x800000001fe00500;
static unsigned long gpio_brige_base = 0x80000000100e0800;

void set_gpio_direction(unsigned long base ,unsigned int gpio, int val,int node)
{
	unsigned int val_base;
	unsigned long val_base_q;
	if(node){
	val_base = readl(base+4);
	val_base &= ~(1 << gpio);
	writel(val_base,base+4);

	val_base = readl(base);
	if (val == 1)
		val_base |= (1 << gpio);
	else
		val_base &= ~(1 << gpio);
	 writel(val_base,base);
	}else{
			
		val_base_q = readb(base+gpio);
	    if (val == 1)
		val_base_q |= (1ULL );
	    else
		val_base_q &= ~(1ULL);

	 	writeb(val_base_q,base+gpio);
	}
}

unsigned int set_gpio_val(unsigned long base ,int gpio,int val,int node)
{
	
	unsigned int val_base;
	unsigned long val_base_q;
	if(node){
 		val_base = readl(base);
		if (val == 1)
		val_base |= (1 << gpio);
		else
		val_base &= ~(1 << gpio);

	 	writel(val_base,base);
	}else{
		val_base_q = readb(base+gpio);
		if (val == 1)
		val_base_q |= (1ULL);
		else
		val_base_q &= ~(1ULL);

	 	writeb(val_base_q,base+gpio);
	}
}

unsigned int get_gpio_val(unsigned long base ,int gpio,int node)
{
	
	unsigned int val_base;
	unsigned long val_base_q;
	if(node){
		val_base = readl(base);
		return (val_base & 1<<gpio) ? 1: 0; 
	}else{
		val_base_q = readb(base+gpio);
		return (val_base_q & 1) ? 1: 0; 
	}
}

static void gpio_node_init(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , dir;

	if(ac <3)
	{
		printf("gpio_node_init num dir\n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio
	dir = (unsigned int)strtoul(av[2], 0, 0); //gpio
	
	set_gpio_direction(gpio_node_base , num, dir,1);
}

static void gpio_node_set(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , val;

	if(ac <3)
	{
		printf("gpio_node_set num val\n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio
	val = (unsigned int)strtoul(av[2], 0, 0); //gpio

	set_gpio_val(gpio_node_base+8, num, val,1);
}

static void gpio_node_get(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , val;

	if(ac <2)
	{
		printf("gpio_node_init num \n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio

	val = get_gpio_val(gpio_node_base+0xc , num,1);
	printf("val is %x\n",val);
}

static void gpio_brige_init(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , dir;

	if(ac <3)
	{
		printf("gpio_node_init num dir\n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio
	dir = (unsigned int)strtoul(av[2], 0, 0); //gpio

	set_gpio_direction(gpio_brige_base , num, dir,0);
}

static void gpio_brige_set(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , val;

	if(ac <3)
	{
		printf("gpio_node_set num val\n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio
	val = (unsigned int)strtoul(av[2], 0, 0); //gpio

	set_gpio_val(gpio_brige_base+0x100, num, val,0);
}

static void gpio_brige_get(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , val;

	if(ac <2)
	{
		printf("gpio_node_init num \n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio

	val = get_gpio_val(gpio_brige_base+0x200 , num,0);
	printf("val is %x\n",val);
}


static void gpio_node_irq_set(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , edge,level,val,offset;
	 unsigned long gpio_node_irq_base = 0x800000001fe01420;
	unsigned int val_base;

	if(ac <4)
	{
		printf("gpio_node_irq_set num edge level\n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio
	edge = (unsigned int)strtoul(av[2], 0, 0); //gpio
	level = (unsigned int)strtoul(av[3], 0, 0); //gpio


 	val_base = readl(gpio_node_base+0x10);

	if (level == 1)
	  val_base |= (1 << num);
	else
	  val_base &= ~(1 << num);

	  writel(val_base,gpio_node_base+0x10);

 	  val_base = readl(gpio_node_base+0x14);
	  val_base |= (1 << num);
	  writel(val_base,gpio_node_base+0x14);

	  offset = num%8;

	 val_base = readl(gpio_node_irq_base+0x14);

	if (edge == 1)
	  val_base |= (1 << offset);
	else
	  val_base &= ~(1 << offset);

	  writel(val_base,gpio_node_irq_base+0x14);
}

static void gpio_node_irq_status(ac, av)
    int ac;
    char *av[];
{
	unsigned int num , edge,level,val,offset;
	 unsigned long gpio_node_irq_base = 0x800000001fe01420;
	unsigned int val_base;

	if(ac <2)
	{
		printf("gpio_node_irq_status num\n");	
		return -1;
	}

	num = (unsigned int)strtoul(av[1], 0, 0); //gpio
	  offset = num%8;

	 val_base = readl(gpio_node_irq_base);

	 printf("irq status is %x\n",(val_base & (1<<offset)));
}


static const Cmd Cmds[] =
{
    {"MyCmds"},
    {"gpio_node_init", "", 0, "gpio_node_init num dir", gpio_node_init, 0,99, CMD_REPEAT},
    {"gpio_node_set", "", 0, "gpio_node_set num val", gpio_node_set, 0,99, CMD_REPEAT},
    {"gpio_node_get", "", 0, "gpio_node_get num", gpio_node_get, 0,99, CMD_REPEAT},
    {"gpio_brige_init", "", 0, "gpio_node_init num dir", gpio_brige_init, 0,99, CMD_REPEAT},
    {"gpio_brige_set", "", 0, "gpio_node_set num val", gpio_brige_set, 0,99, CMD_REPEAT},
    {"gpio_brige_get", "", 0, "gpio_node_get num", gpio_brige_get, 0,99, CMD_REPEAT},
    {"gpio_node_irq_set", "", 0, "gpio_node_irq_set num edge level", gpio_node_irq_set, 0,99, CMD_REPEAT},
    {"gpio_node_irq_status", "", 0, "gpio_node_irq_status num", gpio_node_irq_status, 0,99, CMD_REPEAT},
    {0, 0}
};
static void init_cmd __P((void)) __attribute__ ((constructor));

static void
init_cmd()
{
	cmdlist_expand(Cmds, 1);
}



