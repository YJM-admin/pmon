#include <pmon.h>
#include <stdio.h>
#include  "lt8718.h"

#define I2CADR	0x66
static struct LCD_EDID_PARA LCD_info;
static struct LT9721_PARA g_Lt9721_info;
static int TX_HPD = 0;
static u8 i2c_val = 1;
static u8 SRC_CAP[15];
static u8 LaneCount = 0x00;
static u8 LaneRate = 0x00;
static u8 LoopCounter = 0;
static u8 IterationCounter = 0;
static u8 TPS1Count = 0;

static void HDMI_WriteI2C_Byte(unsigned char reg_addr, unsigned char data)
{
    gpioi2c_write(I2CADR, reg_addr, data, i2c_val);
}

static unsigned char HDMI_ReadI2C_Byte(unsigned char reg_addr)
{
    unsigned char p_data = 0;
    gpioi2c_read(I2CADR, reg_addr, &p_data, i2c_val);
    return p_data;
}

volatile u8 SinkEdid[256];
const u8 SourceEdid[256]=
{
    /***************************1920x1080*****************************************/
    0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x00,0x4C,0x2D,0x59,0x06,0x00,0x00,0x00,0x00,
    0x2D,0x13,0x01,0x03,0x80,0x10,0x09,0x78,0x0A,0xEE,0x91,0xA3,0x54,0x4C,0x99,0x26,
    0x0F,0x50,0x54,0xBD,0xEF,0x80,0x71,0x4F,0x81,0x00,0x81,0x40,0x81,0x80,0x95,0x00,
    0x95,0x0F,0xB3,0x00,0xA9,0x40,0x02,0x3A,0x80,0x18,0x71,0x38,0x2D,0x40,0x58,0x2C,
    0x45,0x00,0xA0,0x5A,0x00,0x00,0x00,0x1E,0x66,0x21,0x50,0xB0,0x51,0x00,0x1B,0x30,
    0x40,0x70,0x36,0x00,0xA0,0x5A,0x00,0x00,0x00,0x1E,0x00,0x00,0x00,0xFD,0x00,0x18,
    0x4B,0x1A,0x51,0x17,0x00,0x0A,0x20,0x20,0x20,0x20,0x20,0x20,0x00,0x00,0x00,0xFC,
    0x00,0x53,0x41,0x4D,0x53,0x55,0x4E,0x47,0x0A,0x20,0x20,0x20,0x20,0x20,0x01,0x3A,
    0x02,0x03,0x23,0xF1,0x4B,0x90,0x1F,0x04,0x13,0x05,0x14,0x03,0x12,0x20,0x21,0x22,
    0x23,0x09,0x07,0x07,0x83,0x01,0x00,0x00,0xE2,0x00,0x0F,0x67,0x03,0x0C,0x00,0x20,
    0x00,0xB8,0x2D,0x01,0x1D,0x00,0x72,0x51,0xD0,0x1E,0x20,0x6E,0x28,0x55,0x00,0xA0,
    0x5A,0x00,0x00,0x00,0x1E,0x01,0x1D,0x00,0xBC,0x52,0xD0,0x1E,0x20,0xB8,0x28,0x55,
    0x40,0xA0,0x5A,0x00,0x00,0x00,0x1E,0x01,0x1D,0x80,0x18,0x71,0x1C,0x16,0x20,0x58,
    0x2C,0x25,0x00,0xA0,0x5A,0x00,0x00,0x00,0x9E,0x01,0x1D,0x80,0xD0,0x72,0x1C,0x16,
    0x20,0x10,0x2C,0x25,0x80,0xA0,0x5A,0x00,0x00,0x00,0x9E,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFD,
};

//SYNC + 4bit command + 20 bit address + length +( data ) + STOP
/*Bit3 (msb of the request command indicate if I2C or native Aux)
  SYNC-->command3:0|ADDR19:16-->ADDR15:8-->ADDR7:0-->LEN7:0-->(DATA0:-7:0-->....)-->STOP
  Request command: Bit3       Bit2         Bit1                                              Bit0   
  --> (DP/I2C : NA/MOT (during transmit MOT set, when done clr): NA/Write_Status_Update_Request : Read/Write)
  Reply command: Bit3   Bit2 |  Bit1   Bit0    (bit3~2 used for I2C-over-AUX,bit1~0 used for Native Aux)
  00=ACK   01=NACK   10=DEFER     example: 10 00, I2C defer+Aux ack


  DP, native Aux  transaction   1001/1000,     Read /write
  I2C-over-AUX  transaction   0101/0100     I2C Read/I2C write            (0*00, 0*01, 0*10 used, 0*11 reserved)

  native Aux Request transaction syntax:  (DP capability, status, control function are directly mapped to 20-bit address space)
  Aux Request:SYNC-->command3:0|ADDR19:16-->ADDR15:8-->ADDR7:0-->LEN7:0-->(DATA0:-7:0-->....)STOP
  Aux Reply:SYNC<--command3:0|0000 <--(DATA0:-7:0<--....)STOP

  I2C-over-AUX  transaction : 
  SYNC-->command3:0|ADDR19:16-->ADDR15:8-->ADDR7:0-->LEN7:0-->(DATA0:-7:0-->....)-->STOP
  command part: 0+1 (when I2C not end with current AUX transaction)+(00write/01read/11write_Write_Status_Update_Request)
 */
void WriteFuntion(u8 Number, u8 Data[5])
{
    u8 i;
	u8 count = 0;
Again:
    //step1: select reg bank	
    HDMI_WriteI2C_Byte(0xff,0x80);
    //step2: AUX_CH softmode enable
    HDMI_WriteI2C_Byte(0x2a,0x01);   
    //step3:command, address, length, data,  write these into TX buffer
    for(i=0; i<Number; i++)
    {
		HDMI_WriteI2C_Byte(0x2b,Data[i]);
    }
    //step4:AUX_CH send enable, AUX TX PHY  开始发送Request
    //HDMI_WriteI2C_Byte(0x2a,0x03);
    HDMI_WriteI2C_Byte(0x2c,0x00);
    delay(2000);
    //step5:get auxrx_int	interrupt, the reply done.     How to check auxrx_int	interrupt?
    if(HDMI_ReadI2C_Byte(0x2b)!=0x00) {
		goto Again;
    }
}

#define I2C_OFFSET 0x00

/*
   I2C                                                
   Data flow  sink device -->LT9721:802b -->RAM:SinkEdid--> 8029
 */
void EdidRead(void)
{
    u16 k;
    u8 i, j, edidfile;
	//4bit command 1/4/5(MOT set|0 read/) + 20bit address 00050 + 8bit length 00/03/0f + data
	u8 Aux_EDID_ADDR[3] = {0x40,0x00,0x50};	//0100 write with addr 0x50  MOT  0101 = 5 read, 0100 = 4 write	 0001 = 1 read
	u8 Aux_W_I2C_OFFSET[5] = {0x40,0x00,0x50,0x00,I2C_OFFSET};   //write  with addr 0x50 and one byte date 0x00 (EDID offset) request
	u8 Aux_R_EDID[4] = {0x50,0x00,0x50,0x0f};		// length should be (LEN7:0 + 1),here 0x0f means 16 bytes
	u8 Aux_I2C_STOP[3] = {0x10,0x00,0x50};			//when read data done, clr MOT bit
													
    //AUX cmd should be 1->2->3->x->5   write ->read ->read done
    WriteFuntion(sizeof(Aux_EDID_ADDR),Aux_EDID_ADDR);
    WriteFuntion(sizeof(Aux_W_I2C_OFFSET),Aux_W_I2C_OFFSET);	  //write 00 in 0xa0
    WriteFuntion(sizeof(Aux_R_EDID),Aux_R_EDID);
    printf("edid header \n");
    for(i=0; i<EDID_HEADER_LEN; i++)
    {
		SinkEdid[i]=HDMI_ReadI2C_Byte(0x2b);
    }
    WriteFuntion(0x03,Aux_I2C_STOP);

    //todu judge EDID header   802b
    if ((0x00 == SinkEdid[0]) && (0xff == SinkEdid[1])&& (0xff == SinkEdid[2]) && (0xff == SinkEdid[3]) 
	    && (0xff == SinkEdid[4])&& (0xff == SinkEdid[5]) && (0xff == SinkEdid[6])&& (0x00 == SinkEdid[7]))
    {
		//continue with correct  EDID header  
		printf("correct edid \n");
		//I2C add ==> offset==> read 256 bytes==>done
		WriteFuntion(sizeof(Aux_EDID_ADDR),Aux_EDID_ADDR);	
		WriteFuntion(sizeof(Aux_W_I2C_OFFSET),Aux_W_I2C_OFFSET);	
		for(j=0; j<16; j++)
		{
			WriteFuntion(sizeof(Aux_R_EDID),Aux_R_EDID);
			delay(5000);
			for(i=0; i<16; i++)
			{
				SinkEdid[16*j+i]=HDMI_ReadI2C_Byte(0x2b);
			}	
		}	
		WriteFuntion(sizeof(Aux_I2C_STOP) ,Aux_I2C_STOP);
		edidfile = 1;
    } else {
		printf("read edid error, use fixed edid \n");
		edidfile = 0;
    }
	HDMI_WriteI2C_Byte(0xff,0x80);
	HDMI_WriteI2C_Byte(0x2a,0x00);//Disable aux-ch SoftMode	
	
	HDMI_WriteI2C_Byte(0xff,0x80);
	HDMI_WriteI2C_Byte(0x28,0x05);//clear the address of EDID shadow    //edid shadow address is 8027	
	HDMI_WriteI2C_Byte(0x28,0x01);//Write EDID Enable	
	
	for(k=0; k<256; k++)
	{
		if(edidfile) {
			HDMI_WriteI2C_Byte(0x29,SinkEdid[k]);  
		} else {
			HDMI_WriteI2C_Byte(0x29,SourceEdid[i]);
		}
	}
	HDMI_WriteI2C_Byte(0x28,0x02);//Read EDID shadow Enable
}

static void ParameterInit(void)
{
    //MSA   1080P   H active: H blank: H offset: H width:     V active: V blank: V offset: V width 
    //1080P 1920:160:46:30:  1080:32:2:4    2_Lane   2.7GBps   8Bit  CHIMEI_N133HSE-EA1
    //1366*768   1366:160:48:32      768:22:3:6      1_Lane   2.7GBps       6Bit PANDA
    //1080P 1920:280:88:44:  1080:45:4:5     2_Lane   2.7GBps       6Bit PANDA-LM156LF1L02
    //1080P               2_Lane     2.7GBps   8Bit                       PANDA-LC133LF4L01
    //1080P   1920:160:48:32:  1080:31:3:5    edp1.2  2_Lane/2.7GBps/8Bit   PANDA-LC116LF1L01

    LCD_info.H_Active =  1920 ;
    LCD_info.H_Black =  160; 
    LCD_info.H_Sync_Offset =  48; 
    LCD_info.H_Sync_Pulse_Width =   32; 
    LCD_info.V_Active = 1080; 
    LCD_info.V_Black =  31; 
    LCD_info.V_Sync_Offset = 3;
    LCD_info.V_Sync_Pulse_Width = 5;
    g_Lt9721_info.resolution =  0x08;
    g_Lt9721_info.H_Total = LCD_info.H_Active + LCD_info.H_Black;
    g_Lt9721_info.H_Start = LCD_info.H_Black - LCD_info.H_Sync_Offset;
    g_Lt9721_info.H_Width = LCD_info.H_Sync_Pulse_Width;
    g_Lt9721_info.H_Active = LCD_info.H_Active;
    g_Lt9721_info.V_Total = LCD_info.V_Active + LCD_info.V_Black;
    g_Lt9721_info.V_Start = LCD_info.V_Black - LCD_info.V_Sync_Offset;
    g_Lt9721_info.V_Width = LCD_info.V_Sync_Pulse_Width;
    g_Lt9721_info.V_Active = LCD_info.V_Active;
    //refer TFT_LCD spec pin assignment^M
    g_Lt9721_info.lane_num = _2_Lane_; //Two_Lane;//2;  // 1, 2, 4  ^M
    g_Lt9721_info.link_rate = PerLane27GBps;        // 1:2:3= 1.62:2.7:5.4^M
    //refer display color to define color_depth, Display color  RGB666 = 26* 26* 26, RGB888 = 28 *28 *28^M
    g_Lt9721_info.color_depth = RGB_8Bit; //2;  // RGB666:RGB888 = 1:2^M
}

static int ChipID(void)
{ 	
    unsigned char a,b;
    HDMI_WriteI2C_Byte(0xff,0x60);
    HDMI_ReadI2C_Byte(0x00);
    HDMI_ReadI2C_Byte(0x01);
	printf("LT8718  CHIP ID:");
    a=HDMI_ReadI2C_Byte(0x00);
    b=HDMI_ReadI2C_Byte(0x01);
    printf("%x %x\n", a, b);
	if((a != 0x16) || (b != 0x6)){
		printf("LT8718  CHIP ID ERROR\r\n");
		return  FALSE;
	}else{
		return  TRUE;
	}
}

static void BackLight(void)
{
    HDMI_WriteI2C_Byte(0xff,0x70); 
    HDMI_WriteI2C_Byte(0x44,0x0c);
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0xd1,0x0c);
    HDMI_WriteI2C_Byte(0xd3,0x00);    
    //调整亮度初始化寄存器
    HDMI_WriteI2C_Byte(0xd3,0x30);  //00    
    HDMI_WriteI2C_Byte(0xc8,0x20);  //00    
    //调整pwm的速率^M
    HDMI_WriteI2C_Byte(0xc9,0x00);  //00    
    HDMI_WriteI2C_Byte(0xca,0x27);  //00    
    HDMI_WriteI2C_Byte(0xcb,0x10);  //00
    //调整pwm的高电平占空比
    HDMI_WriteI2C_Byte(0xcc,0x00);  //00    
    HDMI_WriteI2C_Byte(0xcd,0x27);  //00    
    HDMI_WriteI2C_Byte(0xce,0x10);  //00    
}

static void RxPHY(void)
{
    HDMI_WriteI2C_Byte(0xff,0x70);
    HDMI_WriteI2C_Byte(0x13,0x03);
    HDMI_WriteI2C_Byte(0x14,0x24);//RGB mode Enable
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0x06,0x03);//Rx source from TTL
    HDMI_WriteI2C_Byte(0x53,0xc0);//sync pol adj---guoxianghao
}

static void RxPLL(void)
{
    HDMI_WriteI2C_Byte(0xff,0x70);
    HDMI_WriteI2C_Byte(0x16,0x40);//Pll ref clk from Pixel clk
    HDMI_WriteI2C_Byte(0x18,0x13);//Loop mode sel TTL       
    HDMI_WriteI2C_Byte(0x19,0x1e);//Enable Pll Lock
    HDMI_WriteI2C_Byte(0x1a,0xa4);//RGB clk from external pixel clk

#if DDR_EN      //   DDR MODE
    HDMI_WriteI2C_Byte(0x16,0x60);//Pll ref clk from Pixel cl
    HDMI_WriteI2C_Byte(0x18,0x13);//Loop mode sel TTL       
    HDMI_WriteI2C_Byte(0x1a,0x24);//RGB clk from external pixel clk
    HDMI_WriteI2C_Byte(0x19,0x1e);//Enable Pll Lock
#endif
}

static void Audio_IIS(void)
{
    HDMI_WriteI2C_Byte(0xff,0x88);
    HDMI_WriteI2C_Byte(0x1a,0x00);//Sdp enable
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0x06,0x23);//Video from mipi; Audio from external
    HDMI_WriteI2C_Byte(0xff,0x90);
    //HDMI_WriteI2C_Byte(0x07,0x80);
    HDMI_WriteI2C_Byte(0x08,0x8f);  
    HDMI_WriteI2C_Byte(0xff,0x8c);
    HDMI_WriteI2C_Byte(0x42,0x08);
    HDMI_WriteI2C_Byte(0x43,0x10);
    HDMI_WriteI2C_Byte(0x44,0x00);
    HDMI_WriteI2C_Byte(0x45,0x00);
    HDMI_WriteI2C_Byte(0x0e,0x09);
    HDMI_WriteI2C_Byte(0x4c,0x00);  
    HDMI_WriteI2C_Byte(0x50,0x01);  
    HDMI_WriteI2C_Byte(0x51,0xf8); 
}

static void TypecMode(void)
{
    HDMI_WriteI2C_Byte(0xff,0x70);
    HDMI_WriteI2C_Byte(0x48,0x00);//DP 4-lane only mode
}

static void TxPHY(void)
{
    HDMI_WriteI2C_Byte(0xff,0x70);
    HDMI_WriteI2C_Byte(0x21,0x0d);
    HDMI_WriteI2C_Byte(0x21,0x0f);//Enable DP TX
    //====Lane Manager========
    HDMI_WriteI2C_Byte(0x22,0x77);//Enable Lane0 and Lane1; Enable Tap0 and Tap1
    HDMI_WriteI2C_Byte(0x23,0x77);//Disable Lane2 and Lane3; Diable Tap0 and Tap1
    HDMI_WriteI2C_Byte(0x24,0x80);//Lane0 Swing: 16mA x 25ohm = 400 mV
    HDMI_WriteI2C_Byte(0x25,0x00);//Lane0 Pre-emphasis 0 mV
    HDMI_WriteI2C_Byte(0x26,0x80);//Lane1 Swing: 16mA x 25ohm = 400 mV
    HDMI_WriteI2C_Byte(0x27,0x00);//Lane1 Pre-emphasis 0 mV
    HDMI_WriteI2C_Byte(0x28,0x80);//Lane2 Swing: 16mA x 25ohm = 400 mV
    HDMI_WriteI2C_Byte(0x29,0x00);//Lane2 Pre-emphasis 0 mV
    HDMI_WriteI2C_Byte(0x2a,0x80);//Lane3 Swing: 16mA x 25ohm = 400 mV
    HDMI_WriteI2C_Byte(0x2b,0x00);//Lane3 Pre-emphasis 0 mV
    HDMI_WriteI2C_Byte(0x2c,0xb0);
    HDMI_WriteI2C_Byte(0x2c,0xf0);//Tx Rterm calibration reset
    //=====AUX PHY=============
    HDMI_WriteI2C_Byte(0x2f,0x70);//Enable AUX PHY
    HDMI_WriteI2C_Byte(0x30,0x24);//Pull-up register sel 100K 
    HDMI_WriteI2C_Byte(0x31,0xFC);//AUX + CC
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0x30,0x0e);//Aux_clk divider 15; clk_frq: 30M/15 = 2M
}

static void TxPLL(u8 LinkRate)
{
    /***********2.7G: LinkRate 1, 1.62G: LinkRate 0,***************/
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0x40,0x22);
    if (PerLane162GBps== LinkRate) {
		HDMI_WriteI2C_Byte(0x41,0x20);
		HDMI_WriteI2C_Byte(0x42,0x99);
		HDMI_WriteI2C_Byte(0x43,0x99);
    } else if (PerLane27GBps== LinkRate) {
		HDMI_WriteI2C_Byte(0x41,0x36);
		HDMI_WriteI2C_Byte(0x42,0x00);
		HDMI_WriteI2C_Byte(0x43,0x80);
    }
    //Analog
    HDMI_WriteI2C_Byte(0xff,0x70);
    HDMI_WriteI2C_Byte(0x1c,0x18);
    HDMI_WriteI2C_Byte(0x1d,0x42);
    HDMI_WriteI2C_Byte(0x1e,0x00);
    HDMI_WriteI2C_Byte(0x1e,0x01);
    if (PerLane27GBps== LinkRate) {
		HDMI_WriteI2C_Byte(0x1f,0x11);
    }

    //Digital
    HDMI_WriteI2C_Byte(0xff,0x60);
    HDMI_WriteI2C_Byte(0x1e,0xbf); 
    HDMI_WriteI2C_Byte(0x1e,0xff);
    //Analog
    HDMI_WriteI2C_Byte(0xff,0x70);
    if (PerLane27GBps== LinkRate) {
		HDMI_WriteI2C_Byte(0x1f,0x13);
    } else if (PerLane162GBps== LinkRate) {
		HDMI_WriteI2C_Byte(0x1f,0x19);
		HDMI_WriteI2C_Byte(0x1f,0x1b);
    }

    //Digital
    HDMI_WriteI2C_Byte(0xff,0x80);  
    HDMI_WriteI2C_Byte(0x44,0x41);
    if (PerLane162GBps== LinkRate) {
		HDMI_WriteI2C_Byte(0x45,0x83);
		HDMI_WriteI2C_Byte(0x46,0x06);
		HDMI_WriteI2C_Byte(0x48,0x06);
    } else if(PerLane27GBps== LinkRate) {
		HDMI_WriteI2C_Byte(0x45,0x03);
		HDMI_WriteI2C_Byte(0x46,0x0a);
		HDMI_WriteI2C_Byte(0x48,0x0a);          
    }
    HDMI_WriteI2C_Byte(0x40,0x22);//0x62: ssc en; 0x22: ssc_dis
}

static void VideoProcessor(struct LT9721_PARA g_Lt9721_info)
{
    HDMI_WriteI2C_Byte(0xff,0x88);
    HDMI_WriteI2C_Byte(0x00,0x4a);//Rerverse 12bit pixel input 
    HDMI_WriteI2C_Byte(0x01,0x02);
    HDMI_WriteI2C_Byte(0x02,0x10);
    HDMI_WriteI2C_Byte(0x03,0x01);  
    HDMI_WriteI2C_Byte(0x04,0xff);//Idle number

    //=========MSA===============
    //1080p
    //h_totel 2200
    HDMI_WriteI2C_Byte(0x05,0x08);//Htotal[15:8]
    HDMI_WriteI2C_Byte(0x06,0x98);//Htotal[7:0]
    //hs_time+h_back_porch  44+148=192
    HDMI_WriteI2C_Byte(0x07,0x00);//Hstart[15:8]
    HDMI_WriteI2C_Byte(0x08,0xc0);//Hstart[7:0]
    //hs_time 44
    HDMI_WriteI2C_Byte(0x09,0x00);//Hsync polarity; HsyncWidth[14:8]
    HDMI_WriteI2C_Byte(0x0a,0x2c);//HsyncWidth[7:0]
    //hactive 1920
    HDMI_WriteI2C_Byte(0x0b,0x07);//Hactive[15:8]
    HDMI_WriteI2C_Byte(0x0c,0x80);//Hactive[7:0]
    //vtotal 1125
    HDMI_WriteI2C_Byte(0x0d,0x04);//Vtotal[15:8]
    HDMI_WriteI2C_Byte(0x0e,0x65);//Vtotal[7:0]
    //i  
    HDMI_WriteI2C_Byte(0x0f,0x02);
    HDMI_WriteI2C_Byte(0x10,0x33);
    //Vs_time+V_back_porch  36+5=41
    HDMI_WriteI2C_Byte(0x11,0x00);//Vstart[15:8]
    HDMI_WriteI2C_Byte(0x12,0x29);//Vstart[7:0]
    //Vs_time 5
    HDMI_WriteI2C_Byte(0x13,0x00);//Vsync polarity; VsyncWidth[14:8]
    HDMI_WriteI2C_Byte(0x14,0x05);//VsyncWidth[7:0]
    //V_active 1080
    HDMI_WriteI2C_Byte(0x15,0x04);//Vactive[15:8]
    HDMI_WriteI2C_Byte(0x16,0x38);//Vactive[7:0]

    /*
       0X1A 0X1B 0X1C These three parameters need to be calculated based
       on the number of lane bars.
       The value of total_byte_line = (hwidth/lane_cnt)*BPP/8.
       for example:RGB888-1080P-2lanes:(1920/2)*24/8=2880.
     */
    HDMI_WriteI2C_Byte(0x1a,0x00);//Sdp; Lane_Byte[19:16]
    HDMI_WriteI2C_Byte(0x1b,0x0b);//Lane_Byte[15:8]
    HDMI_WriteI2C_Byte(0x1c,0x40);//Lane_Byte[7:0]

    HDMI_WriteI2C_Byte(0x17,0x08);//Format: RGB; Depth: 8bit
    HDMI_WriteI2C_Byte(0x18,0x20);//MISC0 Value: 8bit
    HDMI_WriteI2C_Byte(0x19,0x00);//MISC1 value

    HDMI_WriteI2C_Byte(0x1d,0x36);//Pixels_Onetime; Pixels_Holdtime
    HDMI_WriteI2C_Byte(0x1e,0x30);//VIDEO_EDY control: Hardware; FIFO_Empty[4:3]
    HDMI_WriteI2C_Byte(0x1f,0x4e);//FIFO_Empty[2:0]; FIFO_Full[4:0]
    HDMI_WriteI2C_Byte(0x20,0x66);//Out_HighByte; Out_LowByte
    HDMI_WriteI2C_Byte(0x21,0x1b);//Tu_Size Value control: Hardware
    HDMI_WriteI2C_Byte(0x22,0x09);//VB_ID in Idle
    HDMI_WriteI2C_Byte(0x23,0xff);
    //HDMI_WriteI2C_Byte(0x25,0x47);//Pttern Image; Pattern Data;
    //HDMI_WriteI2C_Byte(0x26,0xff);//Pattern data value
    //HDMI_WriteI2C_Byte(0x27,0x01);//Video Pattern: Color ramps
    HDMI_WriteI2C_Byte(0x4b,0xf2);//Source sel from pre-pattern
    HDMI_WriteI2C_Byte(0x4c,0x00);
    HDMI_WriteI2C_Byte(0x4d,0x00);
}

static void MainLink(void)
{
    //TPS control
    HDMI_WriteI2C_Byte(0xff,0x84);
    HDMI_WriteI2C_Byte(0x00,0x00);
    //=====Tx Lane Swap============
    HDMI_WriteI2C_Byte(0x15,0x8d);//ref to Demo EVB
    //=====Polarity Swap===========
    HDMI_WriteI2C_Byte(0x16,0xcf);  
}

static void TTL_RGB_MODE_INPUT_SETTING(void)
{
    HDMI_WriteI2C_Byte(0xff,0x88);                     
    HDMI_WriteI2C_Byte(0x1e,0x20);
    HDMI_WriteI2C_Byte(0xff,0x80);  
    HDMI_WriteI2C_Byte(0x76,0x40);  //clk 采样极性  
    HDMI_WriteI2C_Byte(0x52,0x50);
    HDMI_WriteI2C_Byte(0xff,0x88);  
    HDMI_WriteI2C_Byte(0x1a,0x30);
    HDMI_WriteI2C_Byte(0x4b,0x92); //0x90-->0x92---guoxianghao
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0x74,0x28); //dit
#if DDR_EN
    HDMI_WriteI2C_Byte(0xff,0x70);
    HDMI_WriteI2C_Byte(0x1b,0x06); //dit
#endif
    delay(25000);
}

static int DP_DET(void)
{
    HDMI_WriteI2C_Byte(0xff,0x80);  
    if((HDMI_ReadI2C_Byte(0xb0) & 0x04) == 0x04) {       
		delay(30000);
		if((HDMI_ReadI2C_Byte(0xb0) & 0x04) == 0x04) { 
			return 1;
		}
    }
	return 0;
}


void HDMI_Format(void)
{
    u16 LaneByteH = 0x0000;
    u16 LaneByteL = 0x0000;
    u16 LaneByte = 0x0000;

    HDMI_WriteI2C_Byte(0xff,0x88);	
    LaneByteH = HDMI_ReadI2C_Byte(0x33);
    LaneByteL = HDMI_ReadI2C_Byte(0x34);

	HDMI_WriteI2C_Byte(0x1a,0x30);
	HDMI_WriteI2C_Byte(0x4b,0xe0);

    LaneByte |= LaneByteH;
    LaneByte <<= 8;
    LaneByte |= LaneByteL;
    LaneByte = LaneByte*3/2;
    //LaneByte = LaneByte*9/8;
    HDMI_WriteI2C_Byte(0x1b,LaneByte>>8);//Lane_Byte[15:8]
    HDMI_WriteI2C_Byte(0x1c,(LaneByte));//Lane_Byte[7:0]

	HDMI_WriteI2C_Byte(0x17,0x08);//Format: RGB; Depth: 8bit
	HDMI_WriteI2C_Byte(0x18,0x20);//MISC0 Value: 8bit
	HDMI_WriteI2C_Byte(0x1d,0x36);//Pixels_Onetime; Pixels_Holdtime //before：0x59
	HDMI_WriteI2C_Byte(0x1f,0x4e);//FIFO_Empty[2:0]; FIFO_Full[4:0]
	HDMI_WriteI2C_Byte(0x20,0x66);//Out_HighByte; Out_LowByte
}

void DP_OUT_VIDEO_OPEN(void)
{
    delay(1500);
    HDMI_Format( );
    HDMI_WriteI2C_Byte(0xff,0x88);     
    HDMI_WriteI2C_Byte(0x1e,0x30);     
}

void DriveWriteFuntion(u8 Data)
{
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0x36,0x03);//Aux write mode; Aux length
    HDMI_WriteI2C_Byte(0x33,0x03);   //35:34:33 DPCD address 0x000103
    HDMI_WriteI2C_Byte(0x34,0x01);
    HDMI_WriteI2C_Byte(0x35,0x00);
    HDMI_WriteI2C_Byte(0x37,Data);
    HDMI_WriteI2C_Byte(0x37,Data);
    HDMI_WriteI2C_Byte(0x37,Data);
    HDMI_WriteI2C_Byte(0x37,Data);
    HDMI_WriteI2C_Byte(0x38,0x00);//Aux send enable
}

#if 0
static void ReadSinkAttribute(void)
{
    u8 i;
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0x36,0x8e);//Aux read 15 bytes
    HDMI_WriteI2C_Byte(0x33,0);
    HDMI_WriteI2C_Byte(0x34,0);  //0x02
    HDMI_WriteI2C_Byte(0x35,0);
    HDMI_WriteI2C_Byte(0x38,0x00);//Aux send enable
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0x36,0x8e);//Aux read 15 bytes
    HDMI_WriteI2C_Byte(0x33,0);
    HDMI_WriteI2C_Byte(0x34,0);  //0x02
    HDMI_WriteI2C_Byte(0x35,0);
    HDMI_WriteI2C_Byte(0x38,0x00);//Aux send enable
    delay(1500);

    for(i=0; i<15; i++)
    {
		SRC_CAP[i] = HDMI_ReadI2C_Byte(0x2d);
    }
    printf(" Sink Attribute(000h~00eh):");
    for(i=0; i<15; i++)
    {
		printf("%x ", *(SRC_CAP+i));
    }
    printf("\n");
}
#endif

u8 DpcdReadFuntion(u32 Address)
{
    u8 DpcdValue = 0x00;
    u8 AddressH = 0x0f & (Address>>16);
    u8 AddressM = 0xff & (Address>>8);
    u8 AddressL = 0xff &  Address    ;   
    u8 DpcdStatus = 0x00;
    HDMI_WriteI2C_Byte(0xff,0x80);
    HDMI_WriteI2C_Byte(0x36,0x80);//Aux read mode; Aux length
    HDMI_WriteI2C_Byte(0x33,AddressL);
    HDMI_WriteI2C_Byte(0x34,AddressM);
    HDMI_WriteI2C_Byte(0x35,AddressH);    
    HDMI_WriteI2C_Byte(0x38,0x00);//Aux send enable
    delay(1500);
    DpcdValue = HDMI_ReadI2C_Byte(0x2d);
    //bit7~4 AUX-CMD, bit3 AUX-CH reply detecter, bit2 receive ACK of AUX, bit1 receive NACK of AUX, bit0 receive DEFER of AUX
    //DpcdStatus = HDMI_ReadI2C_Byte(0x25);  
    return DpcdValue;
}
void DpcdWriteFuntion(u32 Address, u8 Data)
{
    u8 AddressH = 0x0f & (Address>>16);
    u8 AddressM = 0xff & (Address>>8);
    u8 AddressL = 0xff &  Address    ;
    HDMI_WriteI2C_Byte(0xff,0x80);  //select IIC bank	
    HDMI_WriteI2C_Byte(0x33,AddressL);
    HDMI_WriteI2C_Byte(0x34,AddressM);
    HDMI_WriteI2C_Byte(0x35,AddressH);
    HDMI_WriteI2C_Byte(0x36,0x00);//bit7:Aux write/read mode 0/1; bit4~0:Aux length	
    HDMI_WriteI2C_Byte(0x37,Data);	
    HDMI_WriteI2C_Byte(0x38,0x00);//Aux send enable
}

void LinkConfiguration(struct LT9721_PARA g_Lt9721_info)
{
    //=======Internal Configure
    HDMI_WriteI2C_Byte(0xff,0x80);
    // //06	1.62G ;  0A   2.7G	; 14  5.4G
    HDMI_WriteI2C_Byte(0x02,g_Lt9721_info.link_rate);
    HDMI_WriteI2C_Byte(0x03,0xc0|(g_Lt9721_info.lane_num));//4		
    HDMI_WriteI2C_Byte(0x04,0x10);//Enhanced fram
    HDMI_WriteI2C_Byte(0x05,0x00);//Pattern type	

    //=======Dpcd Configure
    DpcdWriteFuntion(0x00600,0x02); //00600h : set power down mode
    DpcdWriteFuntion(0x00600,0x01); //00600h : set normal power mode

    DpcdWriteFuntion(0x00100,g_Lt9721_info.link_rate);

    DpcdWriteFuntion(0x00101,0x80|(g_Lt9721_info.lane_num));//4 //lanes; Enhanced	1, 2, 4
    DpcdWriteFuntion(0x00107,0x00);//10:ssc enable; 00:ssc disable
    DpcdWriteFuntion(0x00108,0x01); //8B_10B Encode
}

void TPS1_Configure(void)
{
    HDMI_WriteI2C_Byte(0xff,0x84);
    HDMI_WriteI2C_Byte(0x14,0x81);//TPS1_EN =1
    DpcdWriteFuntion(0x00102,0x21); //Notice RX that TX start to send TSP1;
    DriveWriteFuntion(0x00);
    delay(2000);
}
void TPS2_Configure(u8 LaneNum)
{
    HDMI_WriteI2C_Byte(0xff,0x80);
#if 1
    if (_2_Lane_== LaneNum)
    {
	HDMI_WriteI2C_Byte(0x03,0x42);
    }
    else if (_1_Lane_== LaneNum)
    {
	HDMI_WriteI2C_Byte(0x03,0x41);   //lanes        Enable Scemble
    }
    else if (_4_Lane_== LaneNum)
    {
	HDMI_WriteI2C_Byte(0x03,0x44);   //
    }
#else
    HDMI_WriteI2C_Byte(0x03,(0x40|LaneNum)); 
#endif
    HDMI_WriteI2C_Byte(0xff,0x84);
    HDMI_WriteI2C_Byte(0x14,0x84);//TPS2_EN =1
    DpcdWriteFuntion(0x00102,0x22); //Notice RX that TX start to send TSP1;
    delay(500);
}


int  TPS_Status(u8 TPS)
{
    u8 Lane0_1Status = 0x00;
    u8 Lane2_3Status = 0x00;
    Lane0_1Status = DpcdReadFuntion(0x00202);
    Lane2_3Status = DpcdReadFuntion(0x00203);
    if(TPS==TPS1)
		printf("TPS1 \n");
    else
		printf("TPS2 \n");

    printf("Link Training Status(202h~203h):");
    printf("%x ",Lane0_1Status);
    printf("%x ",Lane2_3Status);

    if(TPS==TPS1) {
		if( (LaneCount==0x01) && (Lane0_1Status==0x01) ) {
		    return TRUE;
		}
		if( (LaneCount==0x02) && (Lane0_1Status==0x11) ) {
		    return TRUE;
		}
		if( (LaneCount==0x04) && (Lane0_1Status==0x11) && (Lane2_3Status==0x11) ) {
		    return TRUE;
		}
    }

    if(TPS==TPS2) {
		if( (LaneCount==0x01) && (Lane0_1Status==0x07) ) {
		    return TRUE;
		}
		if( (LaneCount==0x02) && (Lane0_1Status==0x77) ) {
		    return TRUE;
		}
		if( (LaneCount==0x04) && (Lane0_1Status==0x77) && (Lane2_3Status==0x77) ) {
		    return TRUE;
		}
    }
    return FALSE;
}

u8 ReadAdjustRequest(u8 TPS)
{
    u8 Lane0_1Request = 0x00;
    u8 Lane2_3Request = 0x00;
    LoopCounter++;
    Lane0_1Request = DpcdReadFuntion(0x00206);
    Lane2_3Request = DpcdReadFuntion(0x00207);

    printf(" Iteration Counter is: ");
    printf("%x ", IterationCounter);
    printf("Lane request (206h~207h):");
    printf("%x", Lane0_1Request);
    printf("%x", Lane2_3Request);


    if(TPS1Count>10) {
		return 0x05;
    }
    if( (TPS==TPS2) && (LoopCounter==5) ) {
		return MaxLoop;
    }
    if( (Lane0_1Request&0x03)==0x03 ) {
		return MaxSwing;
    }
    if(IterationCounter==5) {
		return MaxCounter;
    }
    HDMI_WriteI2C_Byte(0xff,0x70);
    switch(Lane0_1Request)
    {
	case 0x00:			
	    HDMI_WriteI2C_Byte(0x24,0x36);//Lane0 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x25,0x00);//Lane0 Pre-emphasis 0 dB
	    HDMI_WriteI2C_Byte(0x26,0x36);//Lane1 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x27,0x00);//Lane1 Pre-emphasis 0 dB
	    HDMI_WriteI2C_Byte(0x28,0x36);//Lane2 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x29,0x00);//Lane2 Pre-emphasis 0 dB
	    HDMI_WriteI2C_Byte(0x2a,0x36);//Lane3 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x2b,0x00);//Lane3 Pre-emphasis 0 dB
	    DriveWriteFuntion( (SwingLevel0|Pre_emphasisLevel0) );
	    IterationCounter++;
	    break;
	case 0x44:	
	    HDMI_WriteI2C_Byte(0x24,0x44);//Lane0 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x25,0x11);//Lane0 Pre-emphasis 3.5 dB
	    HDMI_WriteI2C_Byte(0x26,0x44);//Lane1 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x27,0x11);//Lane1 Pre-emphasis 3.5 dB
	    HDMI_WriteI2C_Byte(0x28,0x44);//Lane2 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x29,0x11);//Lane2 Pre-emphasis 3.5 dB
	    HDMI_WriteI2C_Byte(0x2a,0x44);//Lane3 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x2b,0x11);//Lane3 Pre-emphasis 3.5 dB
	    DriveWriteFuntion( (SwingLevel0|Pre_emphasisLevel1) );	
	    break;	
	case 0x88:	
	    HDMI_WriteI2C_Byte(0x24,0x51);//Lane0 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x25,0x22);//Lane0 Pre-emphasis 6 dB
	    HDMI_WriteI2C_Byte(0x26,0x51);//Lane1 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x27,0x22);//Lane1 Pre-emphasis 6 dB
	    HDMI_WriteI2C_Byte(0x28,0x51);//Lane2 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x29,0x22);//Lane2 Pre-emphasis 6 dB
	    HDMI_WriteI2C_Byte(0x2a,0x51);//Lane3 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x2b,0x22);//Lane3 Pre-emphasis 6 dB
	    DriveWriteFuntion( (SwingLevel0|Pre_emphasisLevel2) );	
	    break;	
	case 0xCC:	
	    HDMI_WriteI2C_Byte(0x24,0x6c);//Lane0 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x25,0x44);//Lane0 Pre-emphasis 9.5 dB
	    HDMI_WriteI2C_Byte(0x26,0x6c);//Lane1 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x27,0x44);//Lane1 Pre-emphasis 9.5 dB
	    HDMI_WriteI2C_Byte(0x28,0x6c);//Lane2 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x29,0x44);//Lane2 Pre-emphasis 9.5 dB
	    HDMI_WriteI2C_Byte(0x2a,0x6c);//Lane3 Swing: 16mA x 25ohm = 400 mV
	    HDMI_WriteI2C_Byte(0x2b,0x44);//Lane3 Pre-emphasis 9.5 dB
	    DriveWriteFuntion( (SwingLevel0|Pre_emphasisLevel3) );	
	    break;
	case 0x11:	
	    HDMI_WriteI2C_Byte(0x24,0x51);//Lane0 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x25,0x00);//Lane0 Pre-emphasis 0 dB
	    HDMI_WriteI2C_Byte(0x26,0x51);//Lane1 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x27,0x00);//Lane1 Pre-emphasis 0 dB
	    HDMI_WriteI2C_Byte(0x28,0x51);//Lane2 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x29,0x00);//Lane2 Pre-emphasis 0 dB
	    HDMI_WriteI2C_Byte(0x2a,0x51);//Lane3 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x2b,0x00);//Lane3 Pre-emphasis 0 dB
	    DriveWriteFuntion( (SwingLevel1|Pre_emphasisLevel0) );	
	    break;
	case 0x55:	
	    HDMI_WriteI2C_Byte(0x24,0x66);//Lane0 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x25,0x19);//Lane0 Pre-emphasis 3.5 dB
	    HDMI_WriteI2C_Byte(0x26,0x66);//Lane1 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x27,0x19);//Lane1 Pre-emphasis 3.5 dB
	    HDMI_WriteI2C_Byte(0x28,0x66);//Lane2 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x29,0x19);//Lane2 Pre-emphasis 3.5 dB
	    HDMI_WriteI2C_Byte(0x2a,0x66);//Lane3 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x2b,0x19);//Lane3 Pre-emphasis 3.5 dB
	    DriveWriteFuntion( (SwingLevel1|Pre_emphasisLevel1) );	
	    break;
	case 0x99:	
	    HDMI_WriteI2C_Byte(0x24,0x7a);//Lane0 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x25,0x33);//Lane0 Pre-emphasis 6 dB
	    HDMI_WriteI2C_Byte(0x26,0x7a);//Lane1 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x27,0x33);//Lane1 Pre-emphasis 6 dB
	    HDMI_WriteI2C_Byte(0x28,0x7a);//Lane2 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x29,0x33);//Lane2 Pre-emphasis 6 dB
	    HDMI_WriteI2C_Byte(0x2a,0x7a);//Lane3 Swing: 24mA x 25ohm = 600 mV
	    HDMI_WriteI2C_Byte(0x2b,0x33);//Lane3 Pre-emphasis 6 dB
	    DriveWriteFuntion( (SwingLevel1|Pre_emphasisLevel2) );	
	    break;
	case 0x22:	
	    HDMI_WriteI2C_Byte(0x24,0x6c);//Lane0 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x25,0x00);//Lane0 Pre-emphasis 0 dB
	    HDMI_WriteI2C_Byte(0x26,0x6c);//Lane1 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x27,0x00);//Lane1 Pre-emphasis 0 dB
	    HDMI_WriteI2C_Byte(0x28,0x6c);//Lane2 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x29,0x00);//Lane2 Pre-emphasis 0 dB
	    HDMI_WriteI2C_Byte(0x2a,0x6c);//Lane3 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x2b,0x00);//Lane3 Pre-emphasis 0 dB
	    DriveWriteFuntion( (SwingLevel2|Pre_emphasisLevel0) );
	    DriveWriteFuntion( (SwingLevel2|Pre_emphasisLevel0) );
	    DriveWriteFuntion( (SwingLevel2|Pre_emphasisLevel0) );
	    break;	
	case 0x66:	
	    HDMI_WriteI2C_Byte(0x24,0x88);//Lane0 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x25,0x22);//Lane0 Pre-emphasis 3.5 dB
	    HDMI_WriteI2C_Byte(0x26,0x88);//Lane1 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x27,0x22);//Lane1 Pre-emphasis 3.5 dB
	    HDMI_WriteI2C_Byte(0x28,0x88);//Lane2 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x29,0x22);//Lane2 Pre-emphasis 3.5 dB
	    HDMI_WriteI2C_Byte(0x2a,0x88);//Lane3 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x2b,0x22);//Lane3 Pre-emphasis 3.5 dB
	    DriveWriteFuntion( (SwingLevel2|Pre_emphasisLevel1) );
	    break;
	case 0xaa:	
	    HDMI_WriteI2C_Byte(0x24,0xff);//Lane0 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x25,0x6a);//Lane0 Pre-emphasis 6 dB
	    HDMI_WriteI2C_Byte(0x26,0xff);//Lane1 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x27,0x6a);//Lane1 Pre-emphasis 6 dB
	    HDMI_WriteI2C_Byte(0x28,0xff);//Lane2 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x29,0x6a);//Lane2 Pre-emphasis 6 dB
	    HDMI_WriteI2C_Byte(0x2a,0xff);//Lane3 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x2b,0x6a);//Lane3 Pre-emphasis 6 dB
	    DriveWriteFuntion( (SwingLevel2|Pre_emphasisLevel2) );
	    break;	
	case 0x33:	
	    HDMI_WriteI2C_Byte(0x24,0xa3);//Lane0 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x25,0x00);//Lane0 Pre-emphasis 9.5 dB
	    HDMI_WriteI2C_Byte(0x26,0xa3);//Lane1 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x27,0x00);//Lane1 Pre-emphasis 9.5 dB
	    HDMI_WriteI2C_Byte(0x28,0xa3);//Lane2 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x29,0x00);//Lane2 Pre-emphasis 9.5 dB
	    HDMI_WriteI2C_Byte(0x2a,0xa3);//Lane3 Swing: 32mA x 25ohm = 800 mV
	    HDMI_WriteI2C_Byte(0x2b,0x00);//Lane3 Pre-emphasis 9.5 dB
	    DriveWriteFuntion( (SwingLevel2|Pre_emphasisLevel3) );
	    break;
	default : break;
    }
    return 0x00;
}

void vdDpTxSwingInit( u8 swing)
{
    HDMI_WriteI2C_Byte(0xff,0x70);
    HDMI_WriteI2C_Byte(0x21,0x0d);
    HDMI_WriteI2C_Byte(0x21,0x0f);//Enable DP TX
    //====Lane Manager========
    HDMI_WriteI2C_Byte(0x22,0x77);//Enable Lane0 and Lane1; Enable Tap0 and Tap1
    HDMI_WriteI2C_Byte(0x23,0x77);//Disable Lane2 and Lane3; Diable Tap0 and Tap1
    HDMI_WriteI2C_Byte(0x24,swing);//Lane0 Swing: 16mA x 25ohm = 400 mV
    HDMI_WriteI2C_Byte(0x25,0x00);//Lane0 Pre-emphasis 0 mV
    HDMI_WriteI2C_Byte(0x26,swing);//Lane1 Swing: 16mA x 25ohm = 400 mV
    HDMI_WriteI2C_Byte(0x27,0x00);//Lane1 Pre-emphasis 0 mV
    HDMI_WriteI2C_Byte(0x28,swing);//Lane2 Swing: 16mA x 25ohm = 400 mV
    HDMI_WriteI2C_Byte(0x29,0x00);//Lane2 Pre-emphasis 0 mV
    HDMI_WriteI2C_Byte(0x2a,swing);//Lane3 Swing: 16mA x 25ohm = 400 mV
    HDMI_WriteI2C_Byte(0x2b,0x00);//Lane3 Pre-emphasis 0 mV
}

void EndTraining(void)
{
    DpcdWriteFuntion(0x00102,0x00);	
    delay(5000); 
    HDMI_WriteI2C_Byte(0xff,0x84);                     
    HDMI_WriteI2C_Byte(0x14,0x80);
    HDMI_WriteI2C_Byte(0x14,0xc0);//Enable Mainstream
}
static void AuxTraining(struct LT9721_PARA g_Lt9721_info)
{
    TPS1Count=0;
    LaneCount= g_Lt9721_info.lane_num;
    IterationCounter=0;
    HDMI_WriteI2C_Byte(0xff,0x60);
    HDMI_WriteI2C_Byte(0x07,0xc7);
    //step1: 
    //ReadSinkAttribute();
    //step3:config link
    LinkConfiguration(g_Lt9721_info);

    HDMI_WriteI2C_Byte(0xff,0x60); 
    HDMI_WriteI2C_Byte(0x1f,0xf0);  
    HDMI_WriteI2C_Byte(0x1f,0xff);

    TPS1_Configure();

    while(!TPS_Status(TPS1))
    {
		if( ReadAdjustRequest(TPS1)!=0x00 ) {
		    break;
		}
		TPS1Count++;
		delay(1000);
    }

    IterationCounter = 0;
    LoopCounter=0;
    TPS2_Configure(g_Lt9721_info.lane_num);
    while(!TPS_Status(TPS2))
    {
		if( ReadAdjustRequest(TPS2)!=0x00 ) {
		    break;
		}
		delay(1000);
    }
    vdDpTxSwingInit(0x80);
    HDMI_WriteI2C_Byte(0xff,0x60);     // 
    HDMI_WriteI2C_Byte(0x07,0xff);     //
    delay(5000);
    EndTraining();
}

static void Initial(void)
{
    BackLight();
    RxPHY();
    RxPLL();
    Audio_IIS( );
    TypecMode();   
    TxPHY();          
    TxPLL(g_Lt9721_info.link_rate);
    VideoProcessor(g_Lt9721_info);
    MainLink();
    HDMI_WriteI2C_Byte(0xff,0x70);
    HDMI_WriteI2C_Byte(0x21,0x0d);
    HDMI_WriteI2C_Byte(0x21,0x0f);//Enable DP TX
								
    TTL_RGB_MODE_INPUT_SETTING( );
    if(DP_DET()) {
		if(!TX_HPD) {
			printf(" DP hdp HIGHT! ");
			TX_HPD=1;
			AuxTraining(g_Lt9721_info);
			EdidRead();
			DP_OUT_VIDEO_OPEN( );
		}
    } else {
		TX_HPD=0;
		printf(" DP hdp LOW! ");
    }
}

void lt8718_init(u8 val)
{
	i2c_val = val;
    gpio_i2c_init(val);
    ParameterInit();
    if(ChipID()){
    	Initial();
	}
}

