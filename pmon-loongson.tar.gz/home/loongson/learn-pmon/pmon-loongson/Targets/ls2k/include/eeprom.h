int mac_read(unsigned int reg_addr, unsigned char *buf, int count);
int mac_write(unsigned int reg_addr, unsigned char *buf, int count);

