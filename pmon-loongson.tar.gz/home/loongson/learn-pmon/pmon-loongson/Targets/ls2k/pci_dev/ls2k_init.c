#include "target/ls2k_config.h"
#include "target/ls2k.h"

#include "ls2k.c"

#ifdef LOONGSON_2K2000
unsigned long long dc_base_addr;

void hdmi_codec_init(void)
{
	/* HDMI AUDIO codec init */
	unsigned long long reg_base;
	unsigned int valrbak = 0;

	valrbak = readl(HDA1_PCICMD);
	readl(HDA1_REG_ADDR) = 0x70000000;
	readl(HDA1_PCICMD) = 0x146;
	reg_base = readl(HDA1_REG_ADDR) & (~0xf) | PHYS_TO_UNCACHED(0xe0000000000);

	readl(PHYS_TO_UNCACHED(reg_base) + 0x2404) = 1;
	readl(PHYS_TO_UNCACHED(reg_base) + 0x2400) = -1;
	/* tmp eld for hdmi codec test */
#if 0
	readb(PHYS_TO_UNCACHED(reg_base) + 0x2200) = 0x10;
	readb(PHYS_TO_UNCACHED(reg_base) + 0x2202) = 0x5;
	readb(PHYS_TO_UNCACHED(reg_base) + 0x2205) = 0x10;
	readb(PHYS_TO_UNCACHED(reg_base) + 0x2207) = 0x1;
	readb(PHYS_TO_UNCACHED(reg_base) + 0x2214) = 0x9;
	readb(PHYS_TO_UNCACHED(reg_base) + 0x2215) = 0x7;
	readb(PHYS_TO_UNCACHED(reg_base) + 0x2216) = 0x7;
#endif
	readl(PHYS_TO_UNCACHED(reg_base) + 0x2200) = 0x00050010;
	readl(PHYS_TO_UNCACHED(reg_base) + 0x2204) = 0x01001000;
	readl(PHYS_TO_UNCACHED(reg_base) + 0x2214) = 0x70709;
	readb(PHYS_TO_UNCACHED(reg_base) + 0x2254) = 1;

	readl(PHYS_TO_UNCACHED(reg_base) + 0x2300) = 0x00050010;
	readl(PHYS_TO_UNCACHED(reg_base) + 0x2304) = 0x01001000;
	readl(PHYS_TO_UNCACHED(reg_base) + 0x2314) = 0x70709;
	readb(PHYS_TO_UNCACHED(reg_base) + 0x2354) = 1;

	if(valrbak != 0 ) {
		readl(HDA1_REG_ADDR) = 0;
		readl(HDA1_PCICMD) = valrbak;
	}
	/* enable HDMI hotplug codec f09 command need it */
	readl(PHYS_TO_UNCACHED(dc_base_addr) + 0x1570) |= (1 << 29);
}

void hdmi_phy_config (unsigned long base)
{
	int count;
	//enable HDMI
	//writel((base + HDMI_CTRL), 0x4f); //set video preamble length = 4,and set VideoLGBDisable
	//writel((base + HDMI_CTRL), 0x383); //video preamble length = 8
	readl(base + HDMI_CTRL) = 0x387; //video preamble length = 8
	//writel((base + HDMI_CTRL), 0x3); //video preamble length = 8

	//HMDI zone idle
	readl(base + HDMI_ZONE_IDLE) =  0x00400040;

	//Audio N
	readl(base + AUDIO_N) = 6272; // 44.1KHz * 4, dynamic update N && CTS value
	//writel((base + AUDIO_N), 25088 | 0x80000000); // 148.5MHz, 44.1KHz * 4, static

	//Audio CTS
	//writel((base + AUDIO_CTS), 28000); // 25.2MHZ, 176.4KHz, static fixed CTS mode

	//Set CTS Value Fixed
	//readl(base + AUDIO_CTS) |=  0x20000000;

	//Enable Send CTS
	readl(base + AUDIO_CTS) = 0x80000000;

	//Update CTS Value
	//readl(base + AUDIO_CTS) |=  0x40000000;

	//Audio CTS dynamic
	//readl(base + AUDIO_CTS) &= 0x7fffffff;

	//Audio AIF
	readl(base + AUDIO_INFO_FRAME) = 0x11; //enable AIF,set freq,and set CC = 1, CA = 0

	//Update AIF
	readl(base + AUDIO_INFO_FRAME) |=  0x4;

	//Audio Sample Packet
	readl(base + AUDIO_SAMPLE) = 0x1;

	readl(base + PHY_PLL) = ((0x8 << 1) | (0x28 << 6) | (0x1 << 13) | 0x0);
	readl(base + PHY_PLL) = ((0x8 << 1) | (0x28 << 6) | (0x1 << 13) | 0x1);

	/* wait pll lock */
	count = 0;
	while(!(readl(base + PHY_PLL) & 0x10000)) {
		count++;
		if (count >= 1000) {
			pr_info("hdmi phy pll lock failed\n");
			break;
		}
	}
	readl(base + HDMI_PHY) = 0xf03;

	readl(base + HDMI_PHY_CAL) = 0x4f000ff0;
	readl(base + AVI_INFOFRAME_CTRL0) |= 0x5;
}

void hdmi_init(void)
{
	unsigned int valrbak = 0;

	valrbak = readl(DC_PCICMD);
	readl(DC_REG_ADDR) = 0x60000000;
	readl(DC_PCICMD) = 0x146;

	dc_base_addr = ((readl(DC_REG_ADDR) & (~0xf)) | PHYS_TO_UNCACHED(0xe0000000000));
	hdmi_codec_init();

	hdmi_phy_config(dc_base_addr + 0x1250);
	hdmi_phy_config(dc_base_addr + 0x1240);

	readl(dc_base_addr + 0x1bb0) = ((0x63 << 8) | (0x3 << 2)); //4.02k, 75ohm or two 150ohm parallel

	if(valrbak != 0 ) {
		readl(DC_REG_ADDR) = 0;
		readl(DC_PCICMD) = valrbak;
	}

}
#endif

void ls2k_init(void)
{
	int status;
	pr_info("Ls2k init begain\n");

	ls2k_resource_cfg();
	ls2k_clear_pcie_portirq();
	pr_info("Ls2K Chipset initialize done.\n");
}

