#include <include/stdio.h>
#include <sys/types.h>
#include "cpu.h"
#include "target/ls2k.h"
#ifdef LS_STR
extern void asm_wait_for_kernel(void);

uint64_t mem_read64(unsigned long offset)
{
    return readq(STR_STORE_BASE + offset);
}

void check_str()
{
    uint64_t str_sp, str_ra;
	uint32_t system_s;
	struct acpi_fadt *fadt;

	system_s = readl(LS2K_ACPI_PM1_CNT_REG);
	tgt_printf("Sleep type: %x - system is ", (system_s >> 10) & 0x7);
	if (((system_s >> 10) & 0x7) != SLEEP_TYPE_S3) {
		tgt_printf("normal boot.\n");
		return;
	}
	tgt_printf("S3 boot.\n");
#ifdef DTB
    str_ra = mem_read64(0x40);
    str_sp = mem_read64(0x48);

	tgt_fpudisable();
	/* misc:0x1008,0000 -- 0x100f,ffff */
	/* acpi offset 0x50000 of misc */
	/* LS2K_ACPI_PM1_CNT_REG is cmos reg which storage s3 flag, now clear this flag */
	readl(LS2K_ACPI_PM1_CNT_REG) &= (~(0x7 << 10));
	ls2k_pcie_irq_fixup();

    printf("Jump to kernel....\n");
    //used sp
    __asm__ __volatile__(
	    "or	$r3, %0, $r0		\n"
	    "or	$r1, %1, $r0		\n"
	    "jirl	$r0, $r1, 0		\n"
	    : /* No outputs */
	    :"r"(str_sp), "r"(str_ra)
	    );
#else
	wakeup_ap(asm_wait_for_kernel, NULL);
	tgt_fpudisable();
	/* misc:0x1008,0000 -- 0x100f,ffff */
	/* acpi offset 0x50000 of misc */
	/* LS2K_ACPI_PM1_CNT_REG is cmos reg which storage s3 flag, now clear this flag */
	readl(LS2K_ACPI_PM1_CNT_REG) &= (~(0x7 << 10));
	ls2k_pcie_irq_fixup();

	fadt = acpi_find_fadt();
	acpi_resume(fadt);
#endif
}
#endif
