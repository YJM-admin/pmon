#include <sys/linux/types.h>
#include <pmon.h>
#include <stdio.h>
#include <machine/pio.h>
#include "target/ls7a.h"

#define GPIO_OEN 0x800
#define GPIO_O	 0x900
#define GPIO_I   0xa00

void ls7a_gpio_output(unsigned int pn, unsigned char value)
{
	unsigned long long ls7a_gpio_base = LS7A_GPIO_REG_BASE;

	outb(ls7a_gpio_base + GPIO_OEN + pn, 0x00);
	
	if(value)
		outb(ls7a_gpio_base + GPIO_O + pn, 0x01);
	else
		outb(ls7a_gpio_base + GPIO_O + pn, 0x00);
}


unsigned char ls7a_gpio_input(unsigned int pn)
{
	unsigned char value;

	unsigned long long ls7a_gpio_base = LS7A_GPIO_REG_BASE;

	outb(ls7a_gpio_base + GPIO_OEN + pn, 0x01);
	
	value = inb(ls7a_gpio_base + GPIO_I + pn);

	return value;
}

int ls7agpio_test(int argc,char **argv)
{
	int gpio,value;

	if(argc<3) 
		goto err;
	
	gpio=strtoul(argv[1],0,0);
    if(!strcmp(argv[2],"out")) {
		if(argc < 4)
			goto err;
		value=strtoul(argv[3],0,0);
		ls7a_gpio_output(gpio,value);
		printf("ls7a-gpio%d output value: %d\n",gpio,value);
	} else if(!strcmp(argv[2],"in")) {
		value = ls7a_gpio_input(gpio);
		printf("ls7a-gpio%d input value: %d\n",gpio,value);
	} else{
		goto err;
	}
	return 0;
err:
	printf("ls7a test gpio3:\n");
	printf("\tls7agpio 3 in\n");
	printf("\tls7agpio 3 out 1\n");
	return -1;
}

static const Cmd Cmds[] =
{
	{"ls7a"},
	{"ls7agpio", "", NULL, "ls7a gpio test", ls7agpio_test, 1, 5, 0},
	{0, 0}
};

static void init_cmd __P((void)) __attribute__ ((constructor));

void
init_cmd()
{
	cmdlist_expand(Cmds, 1);
}
