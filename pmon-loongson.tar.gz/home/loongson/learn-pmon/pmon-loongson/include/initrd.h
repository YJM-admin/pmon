#ifndef __GRUB_LIKE_CMD_INITRD__
#define __GRUB_LIKE_CMD_INITRD__

int initrd_execed(void);
unsigned long get_initrd_start(void);
unsigned int get_initrd_size(void);

struct linux_efi_initrd {
	unsigned long	base;
	unsigned long	size;
};

#endif
