/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2008 RuggedCom, Inc.
 * Richard Retanubun <RichardRetanubun@RuggedCom.com>
 */

/*
 * See also linux/fs/partitions/efi.h
 *
 * EFI GUID Partition Table
 * Per Intel EFI Specification v1.02
 * http://developer.intel.com/technology/efi/efi.htm
*/

#ifndef _DISK_PART_EFI_H
#define _DISK_PART_EFI_H

#include <efi.h>

#define MSDOS_MBR_SIGNATURE 0xAA55

#define PARTITION_SYSTEM_GUID \
	EFI_GUID( 0xC12A7328, 0xF81F, 0x11d2, \
		0xBA, 0x4B, 0x00, 0xA0, 0xC9, 0x3E, 0xC9, 0x3B)

/* linux/include/efi.h */
typedef u16 efi_char16_t;
typedef unsigned short __le16;
typedef unsigned int __le32;
typedef unsigned long __le64;

#endif	/* _DISK_PART_EFI_H */
