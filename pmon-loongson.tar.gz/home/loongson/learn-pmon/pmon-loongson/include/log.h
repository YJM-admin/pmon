/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Logging support
 *
 * Copyright (c) 2017 Google, Inc
 * Written by Simon Glass <sjg@chromium.org>
 */

#ifndef __LOG_H
#define __LOG_H

#include <stdio.h>
#include <efi.h>
#include <sys/types.h>
#include <linux/list.h>

#define BIT(a) (1 << a)

/**
 * enum log_level_t - Log levels supported, ranging from most to least important
 */
enum log_level_t {
	/** @LOGL_EMERG: pmon is unstable */
	LOGL_EMERG = 0,
	/** @LOGL_ALERT: Action must be taken immediately */
	LOGL_ALERT,
	/** @LOGL_CRIT: Critical conditions */
	LOGL_CRIT,
	/** @LOGL_ERR: Error that prevents something from working */
	LOGL_ERR,
	/** @LOGL_WARNING: Warning may prevent optimal operation */
	LOGL_WARNING,
	/** @LOGL_NOTICE: Normal but significant condition, printf() */
	LOGL_NOTICE,
	/** @LOGL_INFO: General information message */
	LOGL_INFO,
	/** @LOGL_DEBUG: Basic debug-level message */
	LOGL_DEBUG,
	/** @LOGL_DEBUG_CONTENT: Debug message showing full message content */
	LOGL_DEBUG_CONTENT,
	/** @LOGL_DEBUG_IO: Debug message showing hardware I/O access */
	LOGL_DEBUG_IO,

	/** @LOGL_COUNT: Total number of valid log levels */
	LOGL_COUNT,
	/** @LOGL_NONE: Used to indicate that there is no valid log level */
	LOGL_NONE,

	/** @LOGL_LEVEL_MASK: Mask for valid log levels */
	LOGL_LEVEL_MASK = 0xf,
	/** @LOGL_FORCE_DEBUG: Mask to force output due to LOG_DEBUG */
	LOGL_FORCE_DEBUG = 0x10,

	/** @LOGL_FIRST: The first, most-important log level */
	LOGL_FIRST = LOGL_EMERG,
	/** @LOGL_MAX: The last, least-important log level */
	LOGL_MAX = LOGL_DEBUG_IO,
	/** @LOGL_CONT: Use same log level as in previous call */
	LOGL_CONT = -1,
};

/**
 * enum log_category_t - Log categories supported.
 *
 * Log categories between %LOGC_FIRST and %LOGC_NONE correspond to uclasses
 * (i.e. &enum uclass_id), but there are also some more generic categories.
 *
 * Remember to update log_cat_name[] after adding a new category.
 */
enum log_category_t {
	/** @LOGC_FIRST: First log category */
	LOGC_FIRST = 0,	/* First part mirrors UCLASS_... */

	/** @LOGC_NONE: Default log category */
	LOGC_NONE,	/* First number is after all uclasses */
	/** @LOGC_ARCH: Related to arch-specific code */
	LOGC_ARCH,
	/** @LOGC_BOARD: Related to board-specific code */
	LOGC_BOARD,
	/** @LOGC_CORE: Related to core features (non-driver-model) */
	LOGC_CORE,
	/** @LOGC_DM: Core driver-model */
	LOGC_DM,
	/** @LOGC_DT: Device-tree */
	LOGC_DT,
	/** @LOGC_EFI: EFI implementation */
	LOGC_EFI,
	/** @LOGC_ALLOC: Memory allocation */
	LOGC_ALLOC,
	/** @LOGC_SANDBOX: Related to the sandbox board */
	LOGC_SANDBOX,
	/** @LOGC_BLOBLIST: Bloblist */
	LOGC_BLOBLIST,
	/** @LOGC_DEVRES: Device resources (``devres_...`` functions) */
	LOGC_DEVRES,
	/** @LOGC_ACPI: Advanced Configuration and Power Interface (ACPI) */
	LOGC_ACPI,
	/** @LOGC_BOOT: Related to boot process / boot image processing */
	LOGC_BOOT,
	/** @LOGC_EVENT: Related to event and event handling */
	LOGC_EVENT,
	/** @LOGC_COUNT: Number of log categories */
	LOGC_COUNT,
	/** @LOGC_END: Sentinel value for lists of log categories */
	LOGC_END,
	/** @LOGC_CONT: Use same category as in previous call */
	LOGC_CONT = -1,
};

/**
 * _log() - Internal function to emit a new log record
 *
 * @cat: Category of log record (indicating which subsystem generated it)
 * @level: Level of log record (indicating its severity)
 * @file: File name of file where log record was generated
 * @line: Line number in file where log record was generated
 * @func: Function where log record was generated
 * @fmt: printf() format string for log record
 * @...: Optional parameters, according to the format string @fmt
 * Return: 0 if log record was emitted, -ve on error
 */
int _log(enum log_category_t cat, enum log_level_t level, const char *file,
	 int line, const char *func, const char *fmt, ...)
		__attribute__ ((format (__printf__, 6, 7)));

static inline int _log_nop(enum log_category_t cat, enum log_level_t level,
			   const char *file, int line, const char *func,
			   const char *fmt, ...)
		__attribute__ ((format (__printf__, 6, 7)));

static inline int _log_nop(enum log_category_t cat, enum log_level_t level,
			   const char *file, int line, const char *func,
			   const char *fmt, ...)
{
	return 0;
}

/**
 * _log_buffer - Internal function to print data buffer in hex and ascii form
 *
 * @cat: Category of log record (indicating which subsystem generated it)
 * @level: Level of log record (indicating its severity)
 * @file: File name of file where log record was generated
 * @line: Line number in file where log record was generated
 * @func: Function where log record was generated
 * @addr:	Starting address to display at start of line
 * @data:	pointer to data buffer
 * @width:	data value width.  May be 1, 2, or 4.
 * @count:	number of values to display
 * @linelen:	Number of values to print per line; specify 0 for default length
 */
int _log_buffer(enum log_category_t cat, enum log_level_t level,
		const char *file, int line, const char *func, ulong addr,
		const void *data, uint width, uint count, uint linelen);

/* Define this at the top of a file to add a prefix to debug messages */
#ifndef pr_fmt
#define pr_fmt(fmt) fmt
#endif

/* Use a default category if this file does not supply one */
#ifndef LOG_CATEGORY
#define LOG_CATEGORY LOGC_NONE
#endif

/*
 * This header may be including when CONFIG_LOG is disabled, in which case
 * CONFIG_LOG_MAX_LEVEL is not defined. Add a check for this.
 */
#define _LOG_MAX_LEVEL LOGL_INFO

#define log_emer(_fmt...)	log(LOG_CATEGORY, LOGL_EMERG, ##_fmt)
#define log_alert(_fmt...)	log(LOG_CATEGORY, LOGL_ALERT, ##_fmt)
#define log_crit(_fmt...)	log(LOG_CATEGORY, LOGL_CRIT, ##_fmt)
#define log_err(_fmt...)	log(LOG_CATEGORY, LOGL_ERR, ##_fmt)
#define log_warning(_fmt...)	log(LOG_CATEGORY, LOGL_WARNING, ##_fmt)
#define log_notice(_fmt...)	log(LOG_CATEGORY, LOGL_NOTICE, ##_fmt)
#define log_info(_fmt...)	log(LOG_CATEGORY, LOGL_INFO, ##_fmt)
#define log_debug(_fmt...)	log(LOG_CATEGORY, LOGL_DEBUG, ##_fmt)
#define log_content(_fmt...)	log(LOG_CATEGORY, LOGL_DEBUG_CONTENT, ##_fmt)
#define log_io(_fmt...)		log(LOG_CATEGORY, LOGL_DEBUG_IO, ##_fmt)
#define log_cont(_fmt...)	log(LOGC_CONT, LOGL_CONT, ##_fmt)

#ifdef LOG_DEBUG
#define _LOG_DEBUG	LOGL_FORCE_DEBUG
#else
#define _LOG_DEBUG	0
#endif

/* Note: _LOG_DEBUG != 0 avoids a warning with clang */
#define log(_cat, _level, _fmt, _args...) ({ \
	int _l = _level; \
	if (_LOG_DEBUG != 0 || _l <= LOGL_INFO || \
	    (_DEBUG && _l == LOGL_DEBUG)) \
		printf(_fmt, ##_args); \
	})

#define log_buffer(_cat, _level, _addr, _data, _width, _count, _linelen)  ({ \
	int _l = _level; \
	if (_LOG_DEBUG != 0 || _l <= LOGL_INFO || \
	    (_DEBUG && _l == LOGL_DEBUG)) \
		print_buffer(_addr, _data, _width, _count, _linelen); \
	})

#define log_nop(_cat, _level, _fmt, _args...) ({ \
	int _l = _level; \
	_log_nop((enum log_category_t)(_cat), _l, __FILE__, __LINE__, \
		      __func__, pr_fmt(_fmt), ##_args); \
})

#ifdef DEBUG
#define _DEBUG	1
#else
#define _DEBUG	0
#endif

#ifdef CONFIG_SPL_BUILD
#define _SPL_BUILD	1
#else
#define _SPL_BUILD	0
#endif

/*
 * Output a debug text when condition "cond" is met. The "cond" should be
 * computed by a preprocessor in the best case, allowing for the best
 * optimization.
 */
#define debug_cond(cond, fmt, args...)		\
({						\
	if (cond)				\
		printf(pr_fmt(fmt), ##args);	\
})

/* Show a message if DEBUG is defined in a file */
#define debug(fmt, args...)			\
	debug_cond(_DEBUG, fmt, ##args)

/* Show a message if not in SPL */
#define warn_non_spl(fmt, args...)			\
	debug_cond(!_SPL_BUILD, fmt, ##args)

/*
 * An assertion is run-time check done in debug mode only. If DEBUG is not
 * defined then it is skipped. If DEBUG is defined and the assertion fails,
 * then it calls panic*( which may or may not reset/halt pmon (see
 * CONFIG_PANIC_HANG), It is hoped that all failing assertions are found
 * before release, and after release it is hoped that they don't matter. But
 * in any case these failing assertions cannot be fixed with a reset (which
 * may just do the same assertion again).
 */
void __assert_fail(const char *assertion, const char *file, unsigned int line,
		   const char *function);

/**
 * assert() - assert expression is true
 *
 * If the expression x evaluates to false and _DEBUG evaluates to true, a panic
 * message is written and the system stalls. The value of _DEBUG is set to true
 * if DEBUG is defined before including common.h.
 *
 * The expression x is always executed irrespective of the value of _DEBUG.
 *
 * @x:		expression to test
 */
#define assert(x) \
	({ if (!(x) && _DEBUG) \
		__assert_fail(#x, __FILE__, __LINE__, __func__); })

/*
 * This one actually gets compiled in even without DEBUG. It doesn't include the
 * full pathname as it may be huge. Only use this when the user should be
 * warning, similar to BUG_ON() in linux.
 *
 * Return: true if assertion succeeded (condition is true), else false
 */
#define assert_noisy(x) \
	({ bool _val = (x); \
	if (!_val) \
		__assert_fail(#x, "?", __LINE__, __func__); \
	_val; \
	})

#endif
