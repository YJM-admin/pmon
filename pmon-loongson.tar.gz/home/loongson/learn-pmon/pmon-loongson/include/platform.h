/*	$Id: platform.h, v 1.1.1.1 2024/09/20 11:59:06 root Exp $ */

/*
 * Copyright (c) 2001 Opsycon AB  (www.opsycon.se)
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by Opsycon AB, Sweden.
 * 4. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */
/*
 * PMON Written for LSI LOGIC Corp. by Phil Bunce. Released to public
 * domain by LSI LOGIC.
 *              Phil Bunce, 100 Dolores St. Ste 242, Carmel CA 93923
 *
 * PMON Ported/rewritten for PowerPC and MIPS by Opsycon AB. New version
 * released under the BSD copyright above.
 */

#ifndef __PLATFORM_H__
#define __PLATFORM_H__

#if defined(LOONGSON_3A6000) || defined(LOONGSON_3C6000)
#define THREAD_PER_CORE         2
#else
#define THREAD_PER_CORE         1
#endif
#define NODES_PER_PACKAGE       1

#define IOMMU_NUM_PER_BRIDGE    1
#define TOT_BRIDGE_NUM          TOT_7A_NUM
#define MAX_IOMMU_NUM           (TOT_BRIDGE_NUM * IOMMU_NUM_PER_BRIDGE)

#ifndef VGA_BASE
#define VGA_BASE                0x1e000000
#endif //VGA_BASE

#ifndef INTERLEAVE_OFFSET
#ifdef LOONGSON_3D5000
#define INTERLEAVE_OFFSET       12
#define INTERLEAVE_OFFSET       13
#else
#define INTERLEAVE_OFFSET       8
#endif
#endif //INTERLEAVE_OFFSET

//#define LS132_CORE

//#define SUPER_IO_ENABLE

#endif //__PLATFORM_H__
