#ifndef EFI_UNICODE_
#define EFI_UNICODE_

#define EFI_COUT_MODE_2 2
#define EFI_MAX_COUT_MODE 3

#define CHAR_NULL             0x0000
#define CHAR_BACKSPACE        0x0008
#define CHAR_TAB              0x0009
#define CHAR_LINEFEED         0x000A
#define CHAR_CARRIAGE_RETURN  0x000D

#define BOXDRAW_HORIZONTAL                  0x2500
#define BOXDRAW_VERTICAL                    0x2502
#define BOXDRAW_DOWN_RIGHT                  0x250c
#define BOXDRAW_DOWN_LEFT                   0x2510
#define BOXDRAW_UP_RIGHT                    0x2514
#define BOXDRAW_UP_LEFT                     0x2518
#define BOXDRAW_VERTICAL_RIGHT              0x251c
#define BOXDRAW_VERTICAL_LEFT               0x2524
#define BOXDRAW_DOWN_HORIZONTAL             0x252c
#define BOXDRAW_UP_HORIZONTAL               0x2534
#define BOXDRAW_VERTICAL_HORIZONTAL         0x253c
#define BOXDRAW_DOUBLE_HORIZONTAL           0x2550
#define BOXDRAW_DOUBLE_VERTICAL             0x2551
#define BOXDRAW_DOWN_RIGHT_DOUBLE           0x2552
#define BOXDRAW_DOWN_DOUBLE_RIGHT           0x2553
#define BOXDRAW_DOUBLE_DOWN_RIGHT           0x2554
#define BOXDRAW_DOWN_LEFT_DOUBLE            0x2555
#define BOXDRAW_DOWN_DOUBLE_LEFT            0x2556
#define BOXDRAW_DOUBLE_DOWN_LEFT            0x2557
#define BOXDRAW_UP_RIGHT_DOUBLE             0x2558
#define BOXDRAW_UP_DOUBLE_RIGHT             0x2559
#define BOXDRAW_DOUBLE_UP_RIGHT             0x255a
#define BOXDRAW_UP_LEFT_DOUBLE              0x255b
#define BOXDRAW_UP_DOUBLE_LEFT              0x255c
#define BOXDRAW_DOUBLE_UP_LEFT              0x255d
#define BOXDRAW_VERTICAL_RIGHT_DOUBLE       0x255e
#define BOXDRAW_VERTICAL_DOUBLE_RIGHT       0x255f
#define BOXDRAW_DOUBLE_VERTICAL_RIGHT       0x2560
#define BOXDRAW_VERTICAL_LEFT_DOUBLE        0x2561
#define BOXDRAW_VERTICAL_DOUBLE_LEFT        0x2562
#define BOXDRAW_DOUBLE_VERTICAL_LEFT        0x2563
#define BOXDRAW_DOWN_HORIZONTAL_DOUBLE      0x2564
#define BOXDRAW_DOWN_DOUBLE_HORIZONTAL      0x2565
#define BOXDRAW_DOUBLE_DOWN_HORIZONTAL      0x2566
#define BOXDRAW_UP_HORIZONTAL_DOUBLE        0x2567
#define BOXDRAW_UP_DOUBLE_HORIZONTAL        0x2568
#define BOXDRAW_DOUBLE_UP_HORIZONTAL        0x2569
#define BOXDRAW_VERTICAL_HORIZONTAL_DOUBLE  0x256a
#define BOXDRAW_VERTICAL_DOUBLE_HORIZONTAL  0x256b
#define BOXDRAW_DOUBLE_VERTICAL_HORIZONTAL  0x256c

#define BLOCKELEMENT_FULL_BLOCK   0x2588
#define BLOCKELEMENT_LIGHT_SHADE  0x2591

#define GEOMETRICSHAPE_UP_TRIANGLE    0x25b2
#define GEOMETRICSHAPE_RIGHT_TRIANGLE 0x25ba
#define GEOMETRICSHAPE_DOWN_TRIANGLE  0x25bc
#define GEOMETRICSHAPE_LEFT_TRIANGLE  0x25c4

#define ARROW_LEFT  0x2190
#define ARROW_UP    0x2191
#define ARROW_RIGHT 0x2192
#define ARROW_DOWN  0x2193

typedef struct {
  u16  Unicode;
  char   PcAnsi;
  char   Ascii;
} UNICODE_TO_CHAR;

//
// This list is used to define the valid extend chars.
// It also provides a mapping from Unicode to PCANSI or
// ASCII. The ASCII mapping we just made up.
//
//
UNICODE_TO_CHAR  UnicodeToPcAnsiOrAscii[] = {
  { BOXDRAW_HORIZONTAL,                 0xc4, L'-' },
  { BOXDRAW_VERTICAL,                   0xb3, L'|' },
  { BOXDRAW_DOWN_RIGHT,                 0xda, L'/' },
  { BOXDRAW_DOWN_LEFT,                  0xbf, L'\\' },
  { BOXDRAW_UP_RIGHT,                   0xc0, L'\\' },
  { BOXDRAW_UP_LEFT,                    0xd9, L'/' },
  { BOXDRAW_VERTICAL_RIGHT,             0xc3, L'|' },
  { BOXDRAW_VERTICAL_LEFT,              0xb4, L'|' },
  { BOXDRAW_DOWN_HORIZONTAL,            0xc2, L'+' },
  { BOXDRAW_UP_HORIZONTAL,              0xc1, L'+' },
  { BOXDRAW_VERTICAL_HORIZONTAL,        0xc5, L'+' },
  { BOXDRAW_DOUBLE_HORIZONTAL,          0xcd, L'-' },
  { BOXDRAW_DOUBLE_VERTICAL,            0xba, L'|' },
  { BOXDRAW_DOWN_RIGHT_DOUBLE,          0xd5, L'/' },
  { BOXDRAW_DOWN_DOUBLE_RIGHT,          0xd6, L'/' },
  { BOXDRAW_DOUBLE_DOWN_RIGHT,          0xc9, L'/' },
  { BOXDRAW_DOWN_LEFT_DOUBLE,           0xb8, L'\\' },
  { BOXDRAW_DOWN_DOUBLE_LEFT,           0xb7, L'\\' },
  { BOXDRAW_DOUBLE_DOWN_LEFT,           0xbb, L'\\' },
  { BOXDRAW_UP_RIGHT_DOUBLE,            0xd4, L'\\' },
  { BOXDRAW_UP_DOUBLE_RIGHT,            0xd3, L'\\' },
  { BOXDRAW_DOUBLE_UP_RIGHT,            0xc8, L'\\' },
  { BOXDRAW_UP_LEFT_DOUBLE,             0xbe, L'/' },
  { BOXDRAW_UP_DOUBLE_LEFT,             0xbd, L'/' },
  { BOXDRAW_DOUBLE_UP_LEFT,             0xbc, L'/' },
  { BOXDRAW_VERTICAL_RIGHT_DOUBLE,      0xc6, L'|' },
  { BOXDRAW_VERTICAL_DOUBLE_RIGHT,      0xc7, L'|' },
  { BOXDRAW_DOUBLE_VERTICAL_RIGHT,      0xcc, L'|' },
  { BOXDRAW_VERTICAL_LEFT_DOUBLE,       0xb5, L'|' },
  { BOXDRAW_VERTICAL_DOUBLE_LEFT,       0xb6, L'|' },
  { BOXDRAW_DOUBLE_VERTICAL_LEFT,       0xb9, L'|' },
  { BOXDRAW_DOWN_HORIZONTAL_DOUBLE,     0xd1, L'+' },
  { BOXDRAW_DOWN_DOUBLE_HORIZONTAL,     0xd2, L'+' },
  { BOXDRAW_DOUBLE_DOWN_HORIZONTAL,     0xcb, L'+' },
  { BOXDRAW_UP_HORIZONTAL_DOUBLE,       0xcf, L'+' },
  { BOXDRAW_UP_DOUBLE_HORIZONTAL,       0xd0, L'+' },
  { BOXDRAW_DOUBLE_UP_HORIZONTAL,       0xca, L'+' },
  { BOXDRAW_VERTICAL_HORIZONTAL_DOUBLE, 0xd8, L'+' },
  { BOXDRAW_VERTICAL_DOUBLE_HORIZONTAL, 0xd7, L'+' },
  { BOXDRAW_DOUBLE_VERTICAL_HORIZONTAL, 0xce, L'+' },

  { BLOCKELEMENT_FULL_BLOCK,            0xdb, L'*' },
  { BLOCKELEMENT_LIGHT_SHADE,           0xb0, L'+' },

  { GEOMETRICSHAPE_UP_TRIANGLE,         '^', L'^' },
  { GEOMETRICSHAPE_RIGHT_TRIANGLE,      '>', L'>' },
  { GEOMETRICSHAPE_DOWN_TRIANGLE,       'v', L'v' },
  { GEOMETRICSHAPE_LEFT_TRIANGLE,       '<', L'<' },

  { ARROW_LEFT,                         '<', L'<' },
  { ARROW_UP,                           '^', L'^' },
  { ARROW_RIGHT,                        '>', L'>' },
  { ARROW_DOWN,                         'v', L'v' },

  { 0x0000,                             0x00, L'\0' }
};

#endif
